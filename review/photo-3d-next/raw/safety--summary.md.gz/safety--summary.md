# Suite run

- 5 of 5 files, 56 tests: 56 passed, 0 failed, 0 skipped.
- Time in files (one after another): 14 min. Wall time of this run: 14 min (1 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| lv7 | 367 | 11 |
| live | 165 | 13 |
| smd-moving | 154 | 16 |
| live3 | 113 | 11 |
| live5 | 24 | 5 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `lv7:109` the mirror on a camera (a generated mannequin) › plain: steadier than before, frame to fra | 147 |
| `lv7:160` the mirror on a camera (a generated mannequin) › hologram: nothing drawn over the face, an | 120 |
| `live3:497` the splat mirror, r3 › a big Start camera over the picture, the back camera, a recording t | 32 |
| `lv7:577` screenshots at phone and desktop size: the landscape growing | 27 |
| `lv7:438` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new  | 25 |
| `live:129` before a tap › no toy asks for a device or loads the depth model until its button is tappe | 21 |
| `live3:430` the splat mirror, r3 › the still picture holds still face on: nudging the view a hair does | 19 |
| `live:241` the camera › a shared screen plays on the Screen toy, which switches itself on | 18 |
| `smd-moving:251` the speed › the Toy tab's Speed slider speeds the clip up and slows it down | 17 |
| `lv7:392` the Chladni plate › a tap bows the plate (the bow shows while it moves the sand) and nothi | 17 |
| `live:222` the camera › Photo to 3D's live view takes the picture as a photo in 3D | 16 |
| `live:449` the new toys' screenshots on a computer | 15 |
| `smd-moving:217` the speed › a video's sound comes back with the loop, even when frames are slow | 15 |
| `live:182` the camera › the mirror shows the camera in depth; Stop ends every track and puts the stil | 15 |
| `live:423` steady noise › clap to tap stays still through steady noise; switching it off stops the mi | 14 |
| `lv7:269` the Song landscape grows with the song › Live opens on an empty plain, the land grows as t | 14 |
| `lv7:495` the Chladni plate › the microphone: no bow ever, and no new plate, through a run of notes | 12 |
| `smd-moving:143` the speed › machine on a slow device plays at its source's speed | 12 |
| `live:314` a sung G3 › the song landscape turns live, and its rows fill in | 11 |
| `smd-moving:143` the speed › bridge on a slow device plays at its source's speed | 11 |
| `live5:79` a video plays with its own sound: the frames follow its clock, pause and scrub take both | 11 |
| `live:154` before a tap › the Screen toy's share button hides where getDisplayMedia is missing | 11 |
| `smd-moving:143` the speed › dragon on a slow device plays at its source's speed | 11 |
| `live3:588` Moving photo to 3D › the sample plays its frames in relief, a tap pauses it, and each spla | 10 |
| `live:364` a clap › the echo meter measures the clap's RT60 within 10% | 10 |
