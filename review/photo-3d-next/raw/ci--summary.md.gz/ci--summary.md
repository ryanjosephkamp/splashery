<!-- splashery-ci -->

Aggregated locally from all 16 completed GitHub Actions test-shard artifacts.
## ❌ Test suite on GitHub Actions (`762fb4f`)

- 393 of 393 spec files, 3351 tests: 3349 passed, 1 failed, 1 skipped.
- 16 shards; the longest took 36 min; the whole run about 1 h 20 min so far. [The run](https://github.com/ryanjosephkamp/splashery/actions/runs/38980331170) has the reports and failure screenshots (kept 7 days).

### Failed

| Test | Alone | Error |
| --- | --- | --- |
| `shr:202` 390x844 › the preview sheet after Stop plays the take; Discard asks first and frees it; Save still saves | failed | failed: Error: expect(received).toBe(expected) // Object.is equality |

A failure that passed alone is likely a flake (a busy runner); it still counts. One that failed alone too is real.

<details><summary>Time per shard</summary>

| Shard | Files | Time |
| --- | ---: | ---: |
| 1/16 | 16 | 36 min |
| 2/16 | 25 | 17 min |
| 3/16 | 24 | 18 min |
| 4/16 | 25 | 18 min |
| 5/16 | 24 | 17 min |
| 6/16 | 25 | 25 min |
| 7/16 | 25 | 12 min |
| 8/16 | 26 | 21 min |
| 9/16 | 25 | 15 min |
| 10/16 | 25 | 23 min |
| 11/16 | 25 | 23 min |
| 12/16 | 25 | 20 min |
| 13/16 | 25 | 22 min |
| 14/16 | 26 | 17 min |
| 15/16 | 26 | 14 min |
| 16/16 | 26 | 12 min |

</details>

<details><summary>Slowest files</summary>

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-pics | 2143 | 51 |
| smoke | 892 | 62 |
| cdx-qr-themes | 810 | 59 |
| ui2 | 759 | 11 |
| scr2 | 678 | 6 |
| qrs-toys | 643 | 4 |
| cdx-mp2-r4-raster | 557 | 7 |
| kit | 548 | 10 |
| cdx-mp2-r4 | 486 | 13 |
| cdx-mir | 469 | 11 |
| psv3 | 446 | 20 |
| lv7 | 439 | 11 |
| bk | 403 | 36 |
| qr5 | 392 | 5 |
| wd | 364 | 16 |
| cdx-mp2 | 353 | 16 |
| shp | 340 | 8 |
| fx4-engine | 337 | 4 |
| qr | 334 | 12 |
| wdr3 | 333 | 7 |

</details>
