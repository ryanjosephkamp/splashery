# Suite run

- 1 of 1 files, 1 tests: 1 passed, 0 failed, 0 skipped.
- Time in files (one after another): 26 s. Wall time of this run: 26 s (1 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| shr | 26 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `shr:217` 390x844 › the preview sheet after Stop plays the take; Discard asks first and frees it; Sa | 24 |
