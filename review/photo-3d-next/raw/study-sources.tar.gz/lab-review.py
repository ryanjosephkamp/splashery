# MIT; made by Ryan with Codex (GPT-6). Scientific display of measured inverse depth.
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
r=Path('/workspace/splashery/.cache/photo-3d-next')
items=json.loads((r/'depth-balanced.json').read_text())[:32]
cases=[x for x in items if x['category']=='j']
models=['da2','distill','da3-small','moge-small','da3-base','da3-mono-large','moge-large']
fig,axes=plt.subplots(len(cases),len(models)+1,figsize=(20,10),layout='constrained')
map_=plt.get_cmap('viridis').copy();map_.set_bad('#ff00ff')
for y,item in enumerate(cases):
 axes[y,0].imshow(Image.open(item['file']));axes[y,0].set_title(item['id'],fontsize=7)
 for x,name in enumerate(models,1):
  folder=r/('production-'+name);meta=json.loads((folder/(item['id']+'.json')).read_text())
  d=np.fromfile(folder/(item['id']+'.f32'),dtype='<f4').reshape(meta['h'],meta['w']);finite=d[np.isfinite(d)]
  if finite.size:
   lo,hi=np.quantile(finite,[.02,.98]);axes[y,x].imshow(d,cmap=map_,vmin=lo,vmax=max(hi,lo+1e-9))
  axes[y,x].set_title(name,fontsize=8)
 for axis in axes[y]:axis.set_axis_off()
fig.suptitle('Depth lab J: AI-made Studio inputs and model inverse-depth outputs. Each panel independently scaled (2-98%); yellow is nearer, purple is farther, and magenta is unknown.\nQualitative expect-line review; fictional scenes have no measured geometry, and no model pass/fail is implied.',fontsize=10)
fig.savefig(r/'lab-j-review.jpg',dpi=120,pil_kwargs={'quality':85});print('Saved five predetermined J examples for all seven models')
