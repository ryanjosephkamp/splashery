# MIT; made by Ryan with Codex (GPT-6). Same-camera noise diagnostic only.
import importlib.util,json,sys
from pathlib import Path
import bpy
from mathutils import Matrix
root=Path('/workspace/splashery');cache=root/'.cache/photo-3d-next'
spec=importlib.util.spec_from_file_location('adapter',root/'tools/p3d-next-truth.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
records=json.loads((cache/'targets-correct/targets.json').read_text())['records'];r=next(r for r in records if r['scene']=='room' and r['profile']=='phone' and r['camera']['yaw']==20 and r['camera']['pitch']==0)
cam,_,_=a.generator.build(1,'room');p=r['pose'];w,h=p['width'],p['height'];cam.matrix_world=Matrix(p['camera_to_world'])@Matrix.Diagonal([1,-1,-1,1]);cam.data.lens=p['K'][0][0]*cam.data.sensor_width/w
s=bpy.context.scene;s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.render.threads=2;s.cycles.seed=57;s.cycles.samples=8

s.cycles.use_denoising=True;s.cycles.denoiser='OPENIMAGEDENOISE';s.cycles.denoising_input_passes='RGB_ALBEDO_NORMAL';s.cycles.denoising_prefilter='ACCURATE';s.cycles.samples=16
for seed in [56,57]:
 s.cycles.seed=seed;s.render.filepath=str(cache/('guided-room-'+str(seed)+'.jpg'));bpy.context.view_layer.update();bpy.ops.render.render(write_still=True)
