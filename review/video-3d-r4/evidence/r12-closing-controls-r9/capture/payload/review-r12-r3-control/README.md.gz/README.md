# R12 review queue R3: prepared, unbound, not launched

MIT code. Made by Ryan with Codex (GPT-6). This queue does not establish benchmark acceptance or recover timings. Root owns final authorization and launch. No process inspection, signals, browser, GPU, native job, repository edit, or source ownership occurred during preparation.

R1's saved root observation records watcher 393769 / startTicks 3173768 as Z with raw exit 256 at 14:02:09.794830 UTC. Its error log shows an empty-command binding validation failure. Root's attempted R2 takeover failed its first live assertion before any signal or receipt write. R1 and R2 code and their frozen static evidence are preserved; this preparation makes no root-retirement claim. Exact negative evidence is in `negative-r1/`.

R3 retains all 262 actual R1 historical identities and all five explicit timed roles: main-native, r12-coordinator, r12-samples, r11-remaining, postmerge-samples. The original four root PID/startTicks identities must stay identical to R1. The fifth role binds the postmerge sample controller, not only its Node child. Root must supply all actual command/startTicks/descendant fields; an empty or unbound declaration cannot run.

Root must also supply `extraQuietBlockers` and `extraQuietInventoryComplete: true` in its fresh R3 receipt. Each extra row has actual `root`, keyed `descendants`, `completeObservedDescendants: true`, `capturedAt`, `reason`, and `readOnly: true`. An explicit empty list is valid only as root's actual complete initial observation. No process ownership is inferred from this inventory.

During the authorized quiet loop, R3 performs read-only global discovery on every refresh: live Chrome/Chromium browser/helper executables and ffmpeg/ffprobe are blockers; crashpad-only executables are excluded. Any unresolved active observation blocks quiet, including processes whose empty/denied command prevents classification. Discovered identities persist after reparenting. Global discovery stops before the owned review is spawned. Only the separately bound new render subtree can ever enter deadline cleanup; the quiet watch refuses all signaling.

Process observations read stat, command, then stat again, retrying at most three times. A generation change retries; a confirmed missing or terminal process is ended. Stable active empty/denied command or unstable reads remain unresolved, not fabricated bindings. Pending child observations survive root exit and retry. Global enumeration failures also remain retryable blockers. The quiet gate refreshes before planning and after planning immediately before launch.

The review paths/parameters remain unchanged: immutable tools `/workspace/splashery-v3d-bench-tools-r12`, main-master-r1, candidate-r12-paired-master-v1, shared fresh output `/workspace/v3d-r4-media/review-r12-r1`, main4174/candidate4183, phone390x844, 5seconds,12fps,90000ms/case. Candidate is frozen64ec, served source6d362ff52101541719cc6b639d48b394630113fa61b3467ddbecb78dbe8742b8, paired provenanceb9cf187314d545233fda59b861bb8dfb7eeacdb722a7064a38e4442281984524. Postmerge4184 must not replace it.

The first up to ten actual verified phone pairs are selected in manifest order, explicitly unranked. Missing/failed rows remain inventory entries. Strict reference, artifact, source and exact saved-RGBA replay gates are unchanged. A single render is reserved before spawning; partial output is preserved and never automatically retried. No render before16:15UTC or while any bound/global process or unresolved observation remains. Own render TERM begins16:31:25, KILL16:31:29, absolute stop16:31:30.

## Root finalization

Use `root-receipt-template.json` and `root-receipt.schema.json` for a NEW actual generation `R12-review-r3` authorization. All actual fields remain null in the prepared declaration/template. Preserve original historical root identities and add complete fifth-role/extra inventories.

For the real already-ended R1, use `takeover-observed-ended-template.json` and `takeover-receipt.schema.json`, kind `observed-ended`. Fill actual `priorWatcher` original PID/command and actual observed Z startTicks; `watcherObservation` is the actual full kernel observation. Bind SHA-256 of the original queue launch, error log, root exit observation, original R1 declaration/root receipt, and final R1 quiet-state bytes. `retiredByRoot:false`, `rootRetirementClaim:false`, `signalsSentByRoot:[]`, `retiredAt:null`, `onlyPriorWatcherRetired:false` are mandatory honest semantics. The exact saved negative files must agree with those fields. Root must explicitly confirm ended/no reservation/no output/no timed-work signals. Never claim a root retirement that did not happen.

The separate `root-retired` compatibility variant preserves every old true-flag requirement and timestamp. It is tested but does not describe this observed-ended event.

The field/flag names `r1RetiredQuietStateSha256`, `retiredR1QuietStateSha256`, `--r1-retired-quiet-state`, and local `r1-quiet-at-retirement.json` are legacy storage names. For observed-ended they mean the actual last ended-watcher quiet bytes, not a retirement claim.

After root has prepared three real receipt files, root may run:

```sh
python3 /workspace/v3d-r4-media/queue-r12-review-r3.py --finalize-root-receipt /ABS/actual-root-receipt.json --takeover-receipt /ABS/actual-observed-ended-receipt.json --r1-retired-quiet-state /workspace/v3d-r4-media/review-r12-r1-control/quiet-state.json
python3 /workspace/v3d-r4-media/queue-r12-review-r3.py --check
```

Finalization/check perform file validation only, not process inspection or launch. Root separately authorizes detached `--run`; preparation did neither. Do not rerun the preparation-only test suite after finalization: it intentionally refuses authorized/live configuration. A new `--run` checks the prior watcher identity and every quiet binding using actual process observations.

## CPU evidence

`cpu-tests.log`: 80/80 passed,9.883seconds. All46 inherited controls and102 assertion calls are unchanged after path/generation normalization;34 additive controls cover races, pending orphan identities, global discovery/retry, truthful takeover, and ownership boundaries. The initial77-control run and earlier80-control run also passed; the latter source/log are archived before broadening executable-name matching to include Chrome sandbox/beta helpers. No tests launched browsers/GPU/native jobs or read live process identities. Authentic copied CPU planner media retained their licenses and temporary fixture copies were removed.

`frozen-input-verification-initial.json` preserves an initially overbroad verification rejection: R1's prepared declaration and plan files were intentionally updated before/during the original authorized watcher. The corrected receipt distinguishes those mutable historical files from unchanged source/static receipts. It does not relabel the R1 watcher failure as passing.
