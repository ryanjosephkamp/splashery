# Recorded causes addendum

This is additive CPU presentation outside the frozen reporting kit. It changes no raw row, status, score, source snapshot, or existing proof. It launches no browser, GPU job, native work, process inspection, or signal.

The renderer reads a captured report.json.gz and checks its decompressed SHA against the adjacent snapshot-freeze.json. It requires all40 distinct clip/profile cases. For every failed, explained, or missing outcome, it prints shortened actual reason, explanation.diagnostic and advice fields, with full original artifact links. Missing native rows have no invented native cause. Main, strict paired master, paired raw and unpaired raw stay separate. Finished rows remain in the original full report, not this failure-only table.

The recorded phase is shown separately. Some original timeout messages retain a setup label while their row records evaluation; neither field is rewritten or used to infer a different outcome. Ellipses explicitly mark shortening; original full text remains available. A displayed status that differs from its original row is rejected.

For the final source snapshot, use a fresh addendum output:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/v3d-r4-media/causes-addendum-r1/render-causes.mjs --report=/workspace/v3d-r4-media/final-r12-report-preparation-r1/snapshot-1615/report.json.gz --out=/workspace/v3d-r4-media/causes-r12-final-r1 --raw-base=.
```

Root may publish the generated failures-causes.md, receipt.json and source-report.json.gz alongside the final snapshot's copied files. Then the relative raw links resolve inside that packet. This is an additive publication file set; do not mutate the original frozen outside snapshot. A different publication folder needs an explicit relative/root-site raw-base. Workspace/file/javascript URLs are refused. No published URL is invented.

The preserved partial demonstration in `partial-example-with-phase/` renders the14:32:14.301UTC report into81failure/pending table rows. These include separate versions/raw attempts and are not81distinct native cases. Its raw-base points to the existing local partial snapshot, so do not publish that demonstration as the final report. The earlier `partial-example/` is preserved before adding the explicit phase column.

Nine CPU controls pass: real status/identity preservation, all40cases, no invented missing causes, shortened original text, phase versus stale timeout labels, paired/unpaired separation, no promotion from artifacts, safe relative links and exclusion of finished outcomes from the failure-only table. Unit fixtures are in-memory tests and never actual R12 output. Both final reporting kit and its earlier partial capture remain unchanged.

MIT code. Made by Ryan with Codex (GPT-6). Recorded source facts and copied machine data retain their original attribution and licenses.
