# R12 review R2 — prepared; R1 remains active

MIT. Made by Ryan with Codex (GPT-6). This is a fresh outside-only queue/planner/test/control fork. It does not authorize, launch, retire, or signal anything. Root owns actual process identities, R1 retirement, the fifth postmerge sample controller, final receipts, and detached R2 launch. No repository, frozen runtime/tool, or R1 file was edited. Preparation uses CPU fixtures only and never inspects a live PID.

Changed bindings are `queue-r12-review-r2.py`, `plan-r12-review-r2.mjs`, `test-queue-r12-review-r2.py`, and `review-r12-r2-control/`. The shared review output deliberately remains **review-r12-r1**. The untouched tool remains `/workspace/splashery-v3d-bench-tools-r12/tools/v3d-review.mjs`. Main4174/candidate4183, 390×844,5seconds,12fps,90000ms per case, first10available verified phone pairs in manifest order, explicit unranked `--ids`, no retry, and mandatory exact saved held-out RGBA reproduction remain unchanged. No poses/images are fitted or aligned.

The candidate is still frozen64ec9ad5b7a90b590b289f6a02f0bbd50138db08, paired provenance **b9cf187314d545233fda59b861bb8dfb7eeacdb722a7064a38e4442281984524**, served-source **6d362ff52101541719cc6b639d48b394630113fa61b3467ddbecb78dbe8742b8**. These known targets came from the actual immutable R1 declaration; they are enforced even by optional CPU planning. The separate postmerge sample job is a quiet-window blocker, not a substitution of postmerge viewer source for frozen native/replay source64ec.

## Mandatory five-role binding and R1 takeover

The root receipt requires exactly these five roles, each with its actual PID/startTicks/original command, all observed descendants, and `completeObservedDescendants:true`:

1. main-native
2. r12-coordinator
3. r12-samples
4. r11-remaining
5. postmerge-samples

The fifth root must be the actual **run-postmerge-samples-r1.py controller**, with all of its descendants. Binding only its native sample Node is refused. The original four root identities must equal the original R1 root receipt. Missing/extra roles, duplicate exact identities, wrong descendant keys, or incomplete inventories are refused. PID reuse with different startTicks is distinct; a still-live fifth identity keeps the quiet gate closed even if an older root reused its PID. Title/exec changes do not release a live identity.

The pending declaration has null authorization, timedRoots, takeover, receipt hashes, and actual source-binding fields. Root must fill actual receipts; the templates are not authorizations. No fifth PID or startTicks was inferred or filled during preparation.

R2 also requires root's actual R1-only takeover receipt. **Only root retires R1 watcher393769**, after verifying its exact PID/startTicks/command. No R1 render reservation/log/result or shared output may exist. Root must affirm that only this watcher was retired and no timed-work root was signaled as part of takeover. R2 itself never stops R1, a native job, or the postmerge sample job.

`r1-history/` preserves exact historical preparation snapshots of the original R1 declaration, root receipt, quiet state, and preparation freeze. The quiet snapshot contains262observed identities at that capture; it is not a retirement receipt. The final retired R1 quiet state must retain every previously observed identity and match the actual final bytes still in R1 control. Root binds that final snapshot by SHA256. R2 seeds its watch with **all** of those historical identities plus the complete five-role receipt, retaining descendants after roots exit and supporting PID reuse. R1 source/authorization/quiet bytes and reservation absence are checked again before rendering. Thus a stale, truncated, or changed handoff cannot silently discard known work.

## Root's future steps, after the actual fifth job exists

1. Keep R1 active until root is ready for a real handoff. Capture the actual fifth controller and descendants from its root-owned launch/proof receipts. Fill a five-role receipt using `root-receipt-template.json` and `root-receipt.schema.json`; use generation `R12-review-r2` and the same frozen64ec provenance/source values above. All identities must be real observations, never CPU fixture/template values.
2. Root verifies R1 has not reserved/rendered, retires **only** its exact watcher, records that it ended, and preserves the last complete R1 `quiet-state.json` byte-for-byte. Fill `takeover-receipt-template.json` using `takeover-receipt.schema.json`. It must bind the original R1 declaration/root-receipt SHA256 and final retired quiet-state SHA256. R1's current last quiet bytes must match that final copied file; do not use this preparation's earlier quiet snapshot as the final handoff.
3. Finalize and perform the CPU-only check. These modes read actual receipts/files but do not inspect live PIDs, launch, or signal:

```sh
python3 /workspace/v3d-r4-media/queue-r12-review-r2.py \
  --finalize-root-receipt=/ABS/ACTUAL-FIVE-ROLE-RECEIPT.json \
  --takeover-receipt=/ABS/ACTUAL-R1-ONLY-RETIREMENT.json \
  --r1-retired-quiet-state=/ABS/ACTUAL-FINAL-R1-QUIET-STATE.json
python3 /workspace/v3d-r4-media/queue-r12-review-r2.py --check
```

Finalization preserves the pending declaration and copies the actual three receipts unchanged. It binds R2 code/tests, the unchanged review+five protocol files/manifest, the full passing CPU log, and all required historical handoff bytes. All46controls must pass. An incomplete fifth role, missing takeover, wrong source, existing R1 reservation/output, stale history, or source/hash inconsistency refuses authorization. No receipt is fabricated here.

4. Only root may issue a detached `--run` launch with its own launch receipt. R2 checks the exact bound R1 watcher is no longer live before it starts watching the timed roots, and again before rendering. It never sends that watcher a signal. Do not restart R1 after takeover.

```sh
python3 /workspace/v3d-r4-media/queue-r12-review-r2.py --run
```

Optional `--plan` remains CPU-only and uses actual masters/artifacts; it can record available verified pairs without root process inspection or rendering. Every later plan must preserve prior row/artifact bindings. A missing master yields no inferred successes. Root may use this after preparation; no R2 plan/render was launched by this helper.

## Quiet window and deadline

Rendering starts only at or after **16:15UTC on October15,2026**, after all five roots plus every initially/newly observed descendant has ceased. R2 does not infer an external exit cause or stop timed work for movies. One-second polling retains descendant history after root exit. Inspection failures fail closed. The same unchanged single-invocation reservation, fresh-output refusal, no automatic retry, and exact replay gates apply.

New captures stop at16:31:25; only the newly owned render subtree receives bounded TERM then. Surviving owned render identities receive KILL at16:31:29, leaving a scheduling margin before the **16:31:30absolute stop**. R1/benchmark/sample roots never enter this owned-render cleanup watch. Partial media remains evidence, not a completed capture or benchmark pass. If the quiet window is late or fewer10verified pairs exist, that limitation stays explicit.

## CPU evidence and source preservation

All31R1test functions and all72assertion calls are preserved after path normalization. Their names/assertions are unchanged; the existing fresh-output test mocks the new takeover/history boundaries so it remains isolated and never inspects R1. Fifteen additive controls cover fifth/extra-role requirements, controller-root ownership, duplicate/reused identities, missing/unretired/wrong/active predecessor, title changes, surviving history, actual final quiet bytes, stale history, original-root substitution, shared reservation/output, and frozen-source preservation. All fake identities exist only in memory inside explicit unit tests.

The suite runs only with a pending declaration and refuses finalized/live configuration. Root should preserve `cpu-tests.log` and use `--check` after finalization. `inherited-assertions-verification.json` records the AST comparison. Earlier control logs are retained; final results and all code/history/template hashes are in `preparation-freeze.json`. R1 code and immutable static control bytes are checked unchanged; its actively updated quiet state is preserved as a historical byte snapshot, never stopped or edited here.

Rule check: none.
