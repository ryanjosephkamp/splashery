# Video to 3D on real clips: task 88

This audit is in progress. The acceptance goal has not been established. Codex started the bounded
12-hour run on October 15, 2026, at 04:32:25 UTC; the limit is 16:32:25 UTC. The frozen baseline is
`main` at `95da2ddb`. Code lives on `codex/video-3d-r4`; footage, bakes, receipts, and review media
live on `codex/video-3d-r4-clips`, which must never be merged.

Revision 12 is frozen at `64ec9ad5b7a90b590b289f6a02f0bbd50138db08`, including a normal merge of
main through `0fe28c69`. Its fresh native corpus checks are running. Revision 12 preserved all 74
sample views exactly, as did revision 11. The tables below retain revision 10's final recorded
cohort until the latest cohort has its own complete rows. No cohort establishes the requested gates.

The branch subsequently merged main `cb8a8315` normally as `2773a1c4`. The Video to 3D modules,
pack, and splatjs bytes still match frozen revision 12 exactly. A separate sample replay on the
merged shared framework is running from source fingerprint
`5a27ac17adddd2f86b69c3295e8c4e3f747109b94f46c78a733ec5e7f7d450c8`. It does not replace or relabel
the running corpus cohort. The new byte audit checks all 285 original specs: 266 match task-start
main exactly, nineteen match normally merged main exactly, and none was modified by this task. This
is a byte audit, not a passing-suite claim.

## Revision 12: validation-constrained environment color

The new opt-in retains the environment-color direction learned from training targets and reduces its
magnitude when the full color regresses an internal validation camera. For a proposed color `B` and
magnitude `s`, each camera's change in squared error is
`denominator * dot(B, B) * s² - 2 * dot(B, numerator) * s`. The intersection of its nonregressing
intervals bounds the magnitude, with 1% interior slack. The final color must still improve training
MSE by at least 1% and increase no individual validation camera's MSE. A harmful direction, an empty
validation target, or insufficient training improvement keeps the black background.

Validation targets select magnitude, so this is validation-constrained fitting, not an independent
validation proof. Benchmark-held-out frames never enter the fit. Each eligible camera is rendered at
most once; the opt-in can read additional validation cameras after a regression where the legacy
path stopped early. Gaussian parameters and optimizer state do not change. The default engine path
retains its original full-color acceptance and rejection behavior.

Eight analytic CPU controls and five actual-GPU fixtures passed. The GPU cases retain the default
rejection, accept a bounded color, retain an already valid full fit, reject a harmful direction, and
reject improvement below 1%. All preserve exact Gaussian bytes and execute no optimizer steps.
Affected browser checks passed 66 cases; another 17 passed after enabling the product option. These
are controlled checks, not corpus quality or speed results. The new native source has its own
378-path served fingerprint and separate paired and unpaired provenance. Prior native jobs finish
naturally before their corresponding new lane starts.

The first scored revision-12 plant phone result does not establish the combined goal: SSIM 0.635632
versus main's 0.668773, sharpness 14.050 times main's, first view 118.82 versus 97.41 seconds, and
bake 604.99 versus 693.97 seconds. The constrained fit was accepted at magnitude 0.209108 of the
training proposal, but that internal result did not establish held-out improvement. The cat-track
app bake completed; its evaluation retained a harness error because no independent source frame fell
inside one held-out camera interval. It has no quality score. Neither the frame disjointness guard
nor its error classification was relaxed.

Revision 12's completed sample replay preserved all 74 held-out views across twelve sample/profile
cases, pixel for pixel against main, with no recorded browser errors. The actual process identity
was observed exited with kernel exit code zero. This checks existing sample bakes and production
viewer behavior; it does not retrain the samples or establish corpus acceptance.

The first revision-11 plant phone result was a negative: SSIM 0.547267 versus main's 0.668773,
sharpness about 8.03 times main's, first view 113.25 versus 97.41 seconds, and bake 606.93 versus
693.97 seconds. Sampled aggregate browser RSS was 1,719,971,840 bytes versus main's 1,448,763,392;
this is not GPU RAM. Its full environment fit failed internal validation. Two selected training
frames and the camera solution also differed from revision 10, so the SSIM regression cannot be
attributed to tile size from this comparison. The result remains recorded and misses acceptance.

Revision 11 completed all six existing samples at both profiles: all 74 rendered views match main
exactly, without recorded browser errors. A local 258-case run was interrupted when execution tools
reconnected, after 238 passing cases. The entire affected final spec file was repeated unchanged and
passed all 14 cases. Together with the separately retained calibration run, all 258 selected cases
have observations, including four calibration failures and one existing skip. This cross-run
coverage is not a completed single-suite pass, and no failed assertion is waived.

## Corpus and licenses

[The manifest](../../tools/v3d-corpus.json) freezes 20 distinct real source uploads, their accepted
5–12-second spans, authors, licenses, transformations, and SHA-256 checksums. The set was completed
before candidate quality measurements. The accepted clips total 26,807,550 bytes. No generated
footage, synthetic camera movement, exposure changes, stabilization, or sharpening was added.
Preparation trims, removes audio, scales to 480 pixels high, and encodes H.264 at 24 fps.

Coverage includes pets, plants, statues, a church interior, a lens chamber, an indoor scene, a
residential street, genuine camera translation and orbits, a still camera, shaky movement, a fast
pan, and unaltered low light. No people are the subject. Eight frames per accepted span were
inspected for identifiable people and brands; source, license, and inspection receipts are retained
with the media. Each derivative retains its source's license and attribution.

This is an exploratory corpus, not a representative survey of phone recordings. Useful translation
comes largely from aerial footage. A ground-level phone orbit around a small tabletop object and a
busy pedestrian street are absent; source hardware is usually unknown. These limitations must stay
visible when interpreting the results.

## What changed

- The phone's 1,200-step run can now refine before its iteration budget ends; the old first
  refinement threshold was 1,500 steps. A run limited by elapsed time can still stop before the new
  iteration threshold.
- Conservative surface initialization replaces some jittered sparse clones with oriented points
  inside local sparse triangles. A second recorded camera must support their color. It uses the
  existing seed ceiling; it is an initialization prior, not a dense depth reconstruction.
- New video training uses coordinate-median seed bounds while retaining every sparse point. On the
  cached plant solve, one point about 1,447 units away inflated the mean-centered P90 radius from
  about 0.454 to 2.482. The new opt-in stabilizes scale bounds and position learning rates; legacy
  initialization remains byte-identical when omitted. Seven CPU tests passed, including captured
  original parameter hashes. This is not evidence of a native quality gain.
- New custom bakes retain fitted surfaces through the viewer's photometric cleanup path. Existing
  baked samples keep their own metadata and tiers.
- New bakes carry their black training background into the viewer. The fitted view restores the
  prior camera clear color when disposed, while subsequent host color choices remain authoritative.
  Existing samples without the new metadata retain their existing background behavior.
- Preview buffers fit the actual training and preview sizes. The phone's GPU fence-ring depth is
  reduced from four to two, and a final batch cannot exceed the requested iteration count. Revision
  7 also bounds software-adapter submissions to two steps and one outstanding fence; physical phones
  retain two fences. Camera refinement yields to the UI. Native training sizes, iteration budgets,
  and optimizer settings are unchanged. Existing session wall-time counters are summarized in new
  bake metadata to diagnose encoding, fencing, and metric readbacks.
- Training photographs wait for the seek's presented frame and retain its actual media timestamp. A
  paused same-frame seek can briefly advance the muted local video to recover an actual
  presentation, then pauses again; it never invents a timestamp. The fast suitability survey retains
  its calibrated seeked-frame sampling and its existing 4.5-second deadline.
- An exact serial tile sort is selected on software adapters. The original parallel shader and
  hardware default are unchanged. Browser checks cover unsigned depth/id order, ties, empty and
  single-entry tiles, the 2,048-entry boundary, large padding, and canaries. Complete entry,
  gradient, output, and loss bytes match; three real optimizer steps export identical finite PLYs. A
  small fixed-input timing probe supports this experiment, without establishing end-to-end gains.
  Software adapters also select the engine's existing direct gradient path. Two reversed-order
  probes on the same real 15,000-point, 320×180 input preserved complete parameter, image, loss, and
  tile-list bytes after six steps. Direct-path warm steps took 2.43 versus 3.61 seconds and 3.22
  versus 4.76 seconds under overlapping load. The probes used a 45,000-splat allocation ceiling,
  rather than the native phone's 30,000; they establish neither native bake timing nor
  physical-device gains. The browser regression additionally checks exact raster, gradient, PLY, and
  three-step parameter parity across both sorts and both gradient paths.
- Dark input receives specific lighting advice. Camera solving, decoding, GPU setup, finishing, and
  export have finite deadlines and recovery advice. Training requests Finish after eight minutes on
  the phone setting or 15 minutes on other settings; in-flight work, finishing, export, and other
  stages add time before a bake completes. Absolute elapsed-time checks also reject work that
  returns after its deadline while blocking JavaScript's timer queue. They cannot make a blocked
  thread display its explanation punctually. The progress estimate respects the remaining training
  limit and explains when finishing begins.
- Sessions terminate worker pools and discard GPU initialization resources that arrive after
  disposal. Phone pause and resume share one asynchronous frame loop, and Finish joins it before the
  final readback. The separate `Engine:` commits preserve existing initialization when the new seed
  ceiling is omitted. Late continuations after recovery or disposal now check the originating
  trainer before readback, view updates, metrics, and GPU fences.

The cleanup-only diagnostic was insufficient: on the original cat probe it increased SSIM from
0.31271 to 0.32528 but reduced Laplacian variance from 0.00007991 to 0.00004755. It cannot establish
the clarity goal. The surface initializer produced 2,636 supported points from 614 sparse points in
about 467 ms in a separate real-clip diagnostic; that is an initialization measurement, not a
held-out quality result.

## Measurement protocol

`tools/v3d-bench.mjs` uses the actual toy file input and native Auto settings: phone at 390×844 with
a mobile user agent, and desktop at 1440×900. It does not substitute a cached bake, reduce the
training settings, or press Finish now for acceptance. The smallest native span setting that covers
the whole clip is selected. The phone uses the real `phone` tier; desktop uses `high`.

The first-view timer ends after the progressive 3D preview's submitted GPU work completes. Bake time
includes input assessment and the normal toy completion. Memory is sampled aggregate RSS of the
complete browser process tree, with shared pages potentially counted more than once; it is not GPU
RAM. A host watchdog bounds setup, baking, evaluation, and browser teardown. A watchdog expiration
is an incomplete measurement, never a clear product rejection.

Every fourth baseline camera interval supplies a held-out source frame near its midpoint. All
planned training seek attempts are excluded. An independent decoder presents exact source frames and
reproduces the training extraction canvas and JPEG encoder. Every selected training JPEG must match
that decoder; each held-out JPEG must be distinct from every training JPEG. Repeated encoding must
be deterministic. FFmpeg selects the exact verified source index for the scoring reference. The
production viewer interpolates the recorded camera path; no image fitting, mask, crop to a favorable
region, post-sharpening, or camera alignment is applied. The sole crop is the existing panorama
guard, frozen from baseline for both revisions.

PSNR, Gaussian-window luminance SSIM, and Laplacian variance reuse task 55's arithmetic. Both
profiles require the ratio of corpus median rendered Laplacian variances to reach 1.5 and the
difference in corpus median SSIM to reach 0.03. Only paired successful baseline clips receive image
scores. Explained rejections have no image score; a candidate cannot earn a gain by dropping a
baseline success. Raw partial scores remain visible, but missing outcomes, mismatched references, or
incomplete evidence block an acceptance claim.

The runner fingerprints actual served source bytes, browser binary and arguments, tools, settings,
manifest, input bytes, and reference evidence. Resume rejects changes. Incremental baseline appends
are allowed; each candidate row binds its exact immutable baseline row, model, evaluation, and PNG
receipts. Retries archive previous evidence. The six-sample check freezes every held-out view at
both tiers and requires exact rendered-pixel preservation; it verifies existing bakes and viewer
behavior, rather than retraining their original captures.

Split profile collections can be joined without launching a browser:

```sh
node tools/v3d-bench-join.mjs tools/v3d-corpus.json \
  /workspace/v3d-r4-media/main-joined-snapshot-01 \
  /workspace/v3d-r4-media/main-r1 \
  /workspace/v3d-r4-media/main-desktop-r1
```

The destination must be fresh, outside product checkouts, and separate from every source. The tool
requires matching manifest, full cohort, and exact provenance; it preserves each captured row, its
complete case directory, and the original captured `run.json` bytes. Source runners may append rows
while the tool copies, but every captured row and case must remain unchanged. Unlisted or
in-progress cases and unrelated archived attempts are excluded. `join.json` records the byte
inventories and coverage; missing outcomes and failures stay visible. A join does not establish
quality, acceptance, or isolated timing gains. Existing per-row candidate reference bindings remain
valid because their row and artifact fingerprints are preserved.

## Environment and limits

The workspace has no physical GPU. It provides a four-core CPU-time quota and software WebGPU
through Chromium 151.0.7922.173 and SwiftShader. These are emulated profile measurements, not
physical-phone measurements. The runner also supports native GPU launches for reproduction on
hardware. Start-time system load averages are recorded for each attempt; they do not measure ongoing
concurrency or CPU-quota throttling. Main, candidate, and regression work overlapped, so these
timings cannot establish an isolated no-slower result. The regression suite runs with Node.js
22.15.0, Chrome for Testing 141.0.7390.37, Inter 4.1, Xvfb, and Mesa llvmpipe, following the
existing tests' runtime requirements. Tool notices are in [LICENSES.md](../../LICENSES.md).

The initial six-clip diagnostic predates the strict protocol. Its memory sampler counted only the
browser parent, so its RSS numbers are invalid. Those artifacts are retained as diagnostics and
excluded from acceptance. The fresh run is `main-r1`; candidate iterations retain their own output
directories and source fingerprints.

The `candidate-r2` cat-plays phone attempt produced its first preview at 109.5 seconds but failed
while finishing at 617.2 seconds, without a model or held-out image scores. Main produced its first
preview at 69.6 seconds and completed at 875.8 seconds. The failed candidate cannot count as a speed
improvement, and the overlapping software-GPU runs do not establish isolated timing gains. A CPU
reproduction confirmed that pause and resume could overlap asynchronous training frames and that
Finish could read metrics and emit completion before those frames settled. This scheduler defect was
corrected before `candidate-r3`; its contribution to the particular r2 timeout was not isolated. The
earlier candidate artifacts remain separate from the current run.

The `candidate-r3` cat-plays result finished in 614.7 seconds, compared with main's 875.8, but its
SSIM gain of 0.01134 and sharpness ratio of 0.432 both missed the goal. Narrower, denser surface
seeds in `candidate-r4` raised sharpness to 3.346 times main's and SSIM by 0.00442 on this one clip.
Its first preview was slower (162.3 versus 69.6 seconds), and bake time was 645.7 seconds. These are
partial, overlapping software-GPU measurements, not a corpus acceptance result. Earlier candidates
remain preserved as negative evidence.

The public product branch also includes subsequent `main` through `d33f9421`. The benchmark baseline
remains pinned to the task-start revision, and candidate source fingerprints identify precisely
which runtime each result measured.

The integrated-main `candidate-r5` cat run finished in 707.5 seconds with SSIM +0.00195 and
sharpness 3.242 times main's; its first preview took 236.4 seconds. The separate `candidate-r6`
experiment used a plane-intersection Jacobian to correct foreshortened surface footprints. Its cat
result finished in 690.9 seconds, but sharpness fell to 0.741 times main's and SSIM rose only
0.00251. That experiment has not established a quality gain and is not the draft's default runtime.
The apparent sharpness improvement in r4/r5 includes visible thin streaks, rather than only
recovered texture. The CPU diagnostic validates covariance arithmetic, not a reconstruction-quality
result.

## Results

<!-- task88-live-results-start -->

Last refreshed 2026-10-15 12:14:43 UTC. Main: 32/40 recorded outcomes; candidate
(candidate-r10-paired-master-v1): 15/40. A pending or incomplete case cannot count as an acceptance
pass. Times are seconds; memory is sampled aggregate browser RSS in MiB. Arrows read main → this
round.

### Phone

| Clip              | Outcome                   |  First 3D (s) |       Bake (s) |       RSS (MiB) |              SSIM | Sharpness × main |
| ----------------- | ------------------------- | ------------: | -------------: | --------------: | ----------------: | ---------------: |
| cat-track         | explained → explained     |         — → — |   39.3 → 128.6 | 1152.8 → 1063.8 |             — → — |                — |
| cat-plays         | finished → explained      |      69.6 → — |  875.8 → 117.8 | 1401.1 → 1063.1 |       0.31284 → — |                — |
| buddha            | explained → explained     |         — → — |   82.2 → 142.9 | 1141.5 → 1061.8 |             — → — |                — |
| chameleon-flowers | finished → finished       |  97.4 → 111.1 |  694.0 → 602.8 | 1381.6 → 1086.2 | 0.66877 → 0.68886 |            4.972 |
| dianthus          | finished → finished       | 110.3 → 164.0 | 1260.2 → 655.2 | 1322.5 → 1132.5 | 0.27009 → 0.42264 |            4.031 |
| pisac             | harness-error → pending   |     124.7 → — |     1737.7 → — |      1351.0 → — |             — → — |                — |
| sleeping-dog      | explained → explained     |         — → — |  209.1 → 154.5 | 1101.0 → 1073.2 |             — → — |                — |
| palace-statue     | timeout → pending         |     211.9 → — |     1757.0 → — |      1309.2 → — |             — → — |                — |
| oa-street         | explained → explained     |         — → — |  140.8 → 177.5 | 1078.5 → 1083.3 |             — → — |                — |
| ullard            | finished → finished       | 182.0 → 119.5 | 1335.9 → 611.0 | 1364.2 → 1103.0 | 0.45704 → 0.43298 |            5.901 |
| snaefell          | finished → finished       | 188.0 → 177.3 | 1144.4 → 661.9 | 1394.0 → 1113.0 | 0.63768 → 0.62179 |            1.323 |
| fremantle-orbit   | finished → finished       | 194.4 → 128.3 | 1329.1 → 612.2 | 1335.5 → 1077.7 | 0.71662 → 0.76879 |            1.363 |
| ihasalu-orbit     | finished → finished       | 163.7 → 131.0 | 1358.3 → 622.4 | 1321.7 → 1110.3 | 0.48304 → 0.65046 |            1.065 |
| fresnel-lens      | finished → explained      |     129.8 → — | 1440.8 → 125.8 | 1337.1 → 1049.3 |       0.65549 → — |                — |
| saint-denis       | finished → finished       | 216.7 → 164.5 | 1374.9 → 647.6 | 1354.4 → 1104.0 | 0.25429 → 0.29720 |            4.665 |
| horse-statue      | explained → harness-error |     — → 108.4 |  106.7 → 596.6 | 1082.7 → 1082.0 |             — → — |                — |
| royal-sovereign   | finished → pending        |      92.6 → — |     1479.9 → — |      1350.7 → — |       0.60075 → — |                — |
| viljandi-ruins    | finished → pending        |     185.8 → — |     1685.0 → — |      1325.3 → — |       0.53227 → — |                — |
| kakerdi-bog       | finished → pending        |     176.3 → — |     1523.1 → — |      1334.1 → — |       0.34732 → — |                — |
| fjoloy            | harness-error → pending   |         — → — |      103.4 → — |      1040.8 → — |             — → — |                — |

### Desktop

| Clip              | Outcome               | First 3D (s) |      Bake (s) |       RSS (MiB) |  SSIM | Sharpness × main |
| ----------------- | --------------------- | -----------: | ------------: | --------------: | ----: | ---------------: |
| cat-track         | timeout → pending     |        — → — |    1748.4 → — |      1845.1 → — | — → — |                — |
| cat-plays         | explained → explained |        — → — | 1023.9 → 17.2 | 1314.9 → 1155.9 | — → — |                — |
| buddha            | timeout → pending     |        — → — |    1680.9 → — |      1754.5 → — | — → — |                — |
| chameleon-flowers | timeout → pending     |        — → — |    1737.3 → — |      2046.2 → — | — → — |                — |
| dianthus          | timeout → pending     |        — → — |    1759.3 → — |      1903.0 → — | — → — |                — |
| pisac             | timeout → pending     |        — → — |    1754.5 → — |      1722.4 → — | — → — |                — |
| sleeping-dog      | timeout → pending     |        — → — |    1750.5 → — |      1462.0 → — | — → — |                — |
| palace-statue     | timeout → pending     |        — → — |    1736.3 → — |      1598.2 → — | — → — |                — |
| oa-street         | timeout → pending     |        — → — |    1759.7 → — |      2058.9 → — | — → — |                — |
| ullard            | timeout → pending     |        — → — |    1746.4 → — |      1858.5 → — | — → — |                — |
| snaefell          | timeout → pending     |        — → — |    1741.9 → — |      1526.9 → — | — → — |                — |
| fremantle-orbit   | timeout → pending     |        — → — |    1752.5 → — |      2078.1 → — | — → — |                — |
| ihasalu-orbit     | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| fresnel-lens      | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| saint-denis       | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| horse-statue      | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| royal-sovereign   | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| viljandi-ruins    | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| kakerdi-bog       | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |
| fjoloy            | pending → pending     |        — → — |         — → — |           — → — | — → — |                — |

### Explanations and incomplete attempts

- main, cat-track / phone: **explained**. The camera path could not be worked out: the frames show
  the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, cat-track / desktop: **timeout**. Error: cat-track/desktop (setup) exceeded its host
  deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, cat-plays / desktop: **explained**. The camera path could not be worked out: the frames show
  the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, buddha / phone: **explained**. The camera path could not be worked out: the frames show the
  scene from too nearly the same place, or share too little. Try a stretch where the camera moves
  more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, buddha / desktop: **timeout**. Error: buddha/desktop (setup) exceeded its host deadline of
  1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, chameleon-flowers / desktop: **timeout**. Error: chameleon-flowers/desktop (setup) exceeded
  its host deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, dianthus / desktop: **timeout**. Error: dianthus/desktop (setup) exceeded its host deadline
  of 1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, pisac / phone: **harness-error**. Error: pisac/phone (setup) exceeded its host deadline of
  1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, pisac / desktop: **timeout**. Error: pisac/desktop (setup) exceeded its host deadline of
  1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, sleeping-dog / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, sleeping-dog / desktop: **timeout**. Error: sleeping-dog/desktop (setup) exceeded its host
  deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, palace-statue / phone: **timeout**. Error: palace-statue/phone (setup) exceeded its host
  deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, palace-statue / desktop: **timeout**. Error: palace-statue/desktop (setup) exceeded its host
  deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, oa-street / phone: **explained**. The camera path could not be worked out: the frames show
  the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, oa-street / desktop: **timeout**. Error: oa-street/desktop (setup) exceeded its host
  deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, ullard / desktop: **timeout**. Error: ullard/desktop (setup) exceeded its host deadline of
  1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, snaefell / desktop: **timeout**. Error: snaefell/desktop (setup) exceeded its host deadline
  of 1800000 ms. at Timeout.<anonymous> (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at
  listOnTimeout (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, fremantle-orbit / desktop: **timeout**. Error: fremantle-orbit/desktop (setup) exceeded its
  host deadline of 1800000 ms. at Timeout.<anonymous>
  (file:///workspace/splashery/tools/v3d-bench.mjs:191:25) at listOnTimeout
  (node:internal/timers:635:17) at process.processTimers (node:internal/timers:571:7)
- main, horse-statue / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- main, fjoloy / phone: **harness-error**. Uncaught page errors: Cannot read properties of null
  (reading '0'); Cannot read properties of null (reading '0'); Cannot read properties of null
  (reading '0')
- this round, cat-track / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, cat-plays / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, cat-plays / desktop: **explained**. The decoded video frame took too long. Try a
  shorter MP4 (H.264) clip.
- this round, buddha / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, sleeping-dog / phone: **explained**. The camera path could not be worked out: the
  frames show the scene from too nearly the same place, or share too little. Try a stretch where the
  camera moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, oa-street / phone: **explained**. The camera path could not be worked out: the frames
  show the scene from too nearly the same place, or share too little. Try a stretch where the camera
  moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, fresnel-lens / phone: **explained**. The camera path could not be worked out: the
  frames show the scene from too nearly the same place, or share too little. Try a stretch where the
  camera moves more (a walk, an orbit, a low flight), or a longer stretch at fewer frames a second.
- this round, horse-statue / phone: **harness-error**. page.evaluate: Error: A training JPEG could
  not be matched to an independently presented source frame. at sourceFrameReceipts (eval at
  evaluate (:290:30), <anonymous>:95:15) at async <anonymous>:316:30 at withHostDeadline.timeoutMs
  (/workspace/splashery-v3d-bench-tools-r10/tools/v3d-bench.mjs:788:48) at async withHostDeadline
  (/workspace/splashery-v3d-bench-tools-r10/tools/v3d-bench.mjs:187:12) at async main
  (/workspace/splashery-v3d-bench-tools-r10/tools/v3d-bench.mjs:527:9) at async
  file:///workspace/splashery-v3d-bench-tools-r10/tools/v3d-bench.mjs:973:3

<!-- task88-live-results-end -->

## Samples and regressions

No existing test, skip condition, or threshold was weakened. The draft PR has the `full-suite`
label. The first public head, `c0c92447`, completed all 16 CI shards: eight passed and eight failed.
Its [merged report](https://github.com/ryanjosephkamp/splashery/actions/runs/38694998728) records
2,538 tests: 2,525 passed, 12 failed, and one existing private-fixture skip. Six failures passed
unchanged isolated reruns; they still count as failures. Recorded failures include chromosome
motion, PDF text and bytes, effect pause/resume, camera-depth stability, site credits, and a
blank-video check. The site failure identified the task's added license heading; regenerating the
credit page and service-worker version fixed it, and the unchanged credit assertion passed locally.
The blank-video presentation stall prompted the bounded recovery above. Every other failure remains
open pending unchanged reruns and baseline investigation. The local scheduler stopped after its
current files finished, preserving all raw reports. Those 12 completed files contain 194 passed
tests and six failures: one Picture QR timeout, four Moving photo playback-timing failures, and one
QR Damage lab timeout. These failures occurred during overlapping software rendering and remain
failures until verified reruns; they were not waived. Focused checks include actual WebGPU training
and PLY export, exact seed ceilings, worker abort and error cleanup, late resource ownership,
presented-frame extraction, benchmark provenance, reference binding, and independent source-frame
overlap detection. Final counts and any failures will be recorded here after the runs finish.

An execution-service interruption around 08:00 UTC stopped foreground servers and four unrecorded
in-progress cases. Their partial artifacts and logs are archived separately. Restored servers were
verified against every previously captured source byte; no interrupted attempt was promoted to a
completed row. Fresh main continuation shards retain identical provenance while leaving the old
failures immutable. Detached controllers and servers continue the remaining coverage.

Revision 8 freezes the exact software sort and presented-frame recovery. Its first completed cat
phone bake took 558.3 seconds, with first view at 83.6 seconds, SSIM 0.31149835, and Laplacian
variance 0.00010551061. Against main, sharpness is 1.5241 times as high, but SSIM falls by 0.00134
and first view is slower. This is negative acceptance evidence. Both profile collections continue;
their frozen served-source fingerprint is
`8104905b149d658e8cd469e7ad2cc2788ed0933f36b57c81d2096c5c3d5bf918`.

Subsequent review fixed stale video-play ownership and evaluation work reaching a recovered trainer.
Their new regressions failed before the changes, then passed: four presentation checks and three CPU
evaluation checks. These changes do not rewrite the frozen revision-8 experiment.

A saved revision-8 Dianthus model exposed a training/viewer mismatch: training composites against
black, while the default page clears white. A replay first reproduced all four original white
held-out PNGs exactly, then changed only the camera clear color. Mean SSIM rose from 0.112766 to
0.472900; Laplacian variance became 0.00257345, or 4.3756 times main's on this clip. A second replay
used the actual production metadata and flight path, with no manual color override: all four PNGs
matched the black controls byte for byte, and leaving for another toy restored white. Five new
ownership checks and the existing Replay lifecycle assertion passed. These are causal diagnostics on
a stored model, not replacement native benchmark rows. Fresh revision-9 collection is required.

The repaired eight-binding structural-loss path also completed a fixed-seed, real-input probe with
15,000 splats and 120 steps per variant, without GPU errors. Weight 0.2 raised the two-view mean
SSIM from 0.642722 to 0.650017 and mean Laplacian variance from 0.00000928 to 0.00002100. Batch time
increased from 336.7 to 472.2 seconds under overlapping load. Geometry came from the cached solve;
this is neither independent novel-view validation nor a native timing comparison. Structural loss
remains off by default because this single-input gain does not justify its measured cost.

The next integrated local run passed 49 tests, retained the existing private-fixture skip, and
failed four unchanged fast-feedback assertions: Edinburgh, Adjara, Põltsamaa, and the quick real
video check. The three sample checks exceeded the unchanged 4.5-second survey deadline during
overlapping work. These remain failures. The new deadline, progress, and pause checks passed all 10
tests; a separate lifecycle check verifies that Finish now retains its GPU hold while leaving the
toy releases it before cleanup settles. The expanded software-path suite passed all three tests. A
real busy-loop deadline reproduction also led to a deterministic elapsed-clock regression; an
initial timing-sensitive version of that new test is retained among failed local attempts.

The main six-sample baseline contains all 74 held-out views across both profiles, without browser
errors. The revision-5 candidate completed all 74 held-out views across all 12 sample/profile pairs:
every rendered pixel was preserved, without browser errors. Both complete image sets and their
source notices are on the media branch. This verifies existing bakes and viewer behavior, not new
training. Later runtime and upstream integration still require their own appropriate checks.

The revision-7 focused run passed 52 tests, retained one existing private-fixture skip, and failed
four unchanged calibration checks during overlapping software rendering. The presentation-recovery
probe passed the real blank clip and its new timestamp/cancellation test; three calibration checks
still exceeded the unchanged survey deadline in the next loaded run. These are retained failures,
not waived checks. The evidence tools passed 31 tests, including new candidate-shard reference
verification. The exact software-sort suite passed all three real-GPU tests after correcting a
parser-field typo in its newly added test; the first failed test run is retained.

## Revision 9: measured gains, regressions, and error handling

The complete revision-9 sample check preserved every pixel in all 74 held-out views across the six
samples and both profiles, without browser errors. It used the frozen `b7099b1c` runtime; subsequent
fixes still require their own integrated verification.

The native Dianthus phone run finished in 641.5 seconds, with SSIM 0.472708 and Laplacian variance
0.00242934, compared with main's SSIM 0.270086 and variance 0.000588139. The native plant run
finished in 607.5 seconds, but SSIM fell from main's 0.668773 to 0.504333 despite variance rising
7.185 times. Its first view also took 121.6 seconds versus main's 97.4 seconds. Sharp edges around
uncovered regions do not satisfy the combined quality goal. Both outcomes remain in the strict
record; the corpus goals are not established.

The revision-9 cat phone attempt failed camera initialization even though main and revision 8
finished. A separate diagnostic selected the same 16 JPEG bytes as the successful revision-8 run;
the existing relaxed solve then registered all 16 cameras and 669 points. The native failed attempt
did not retain its full solver inputs, so this diagnostic does not establish its cause or replace
its failed outcome.

An `Engine:` change now stops and emits a training error when encoding, refinement, or a queued GPU
fence fails. It prevents a stalled scheduler from later reporting completion. Three new CPU
regressions and the existing real-WebGPU training case passed together. A separate matcher change
keeps the shader, all image pairs, integer distances, and matches unchanged while bounding optional
chunk sizes and cleaning up canceled work. Eight CPU checks and one real-WebGPU parity check passed;
the latter compared raw distance tables and independent CPU matches across four chunk sizes with no
GPU errors. The product uses four-pair chunks only on software adapters; native timing gains have
not yet been measured.

The fitted training background now survives routine exposure or accent refreshes while a genuine
host background choice remains authoritative. Ten CPU ownership checks passed. Retrying a file also
clears both the old diagnostic text and the public error state while the next run is pending; the
new regression failed before the fix, then both training-hold cases and the existing progress case
passed together. Failed local setup attempts are retained separately from these passing runs.

A training-only constant-background experiment proposed a brown plant color, but the unchanged
confidence rule rejected it: only five of seven fitting frames passed, below the required 80%. The
older cache also lacks receipts proving identity with revision 9's selected frames. This color
remains diagnostic, and no low-texture background prior is enabled.

The full GitHub Actions run on `b7099b1c` completed all 323 spec files: 2,781 of 2,789 tests passed,
seven failed, and one existing test was skipped. Four failures passed when rerun alone; they remain
failures. The PDF, paused sound, and pause/resume failures are recorded as known on main. No tests
or thresholds were removed or relaxed.

The benchmark failure revealed an extraction race: a callback for the initial frame reported time
zero, but drawing after `seeked` captured the requested 0.333-second picture. Extraction now rejects
presentations from before the completed seek, preserving the actual timestamp of a fresh picture.
The overlap fixture now deliberately repeats the independently decoded JPEG's source index and adds
timestamp, hash, and index binding assertions; its original rejection assertion remains. The real
decoder fixture and nine CPU ordering/recovery controls passed. The real blank-video check passed,
while the unchanged real-video suitability check still failed its quick sampling deadline during
overlapping work. This failure remains recorded.

## Revision 10: a conservative learned environment

Revision 10 fits three constant environment-color parameters after geometry training. For a black
render `C`, transmittance `T`, and training target `Y`, each channel solves
`B = clamp(sum(T * (Y - C)) / sum(T * T), 0, 1)`. This uses every valid pixel in eligible training
cameras, with no region selection, detail synthesis, or external held-out image input. It is a model
parameter fit, distinct from the rejected low-texture color heuristic. The implementation also
accounts for each camera's photometric gain and bias. It guarantees nonincreasing fixed-model
training MSE, not SSIM or new geometry.

The first cached-input experiment reduced pooled training SSE from 69,708.15 to 56,726.59 and
improved two-view mean SSIM from 0.631690 to 0.642347, without changing a Gaussian parameter byte.
Nevertheless, one validation view lost PSNR, so the predeclared gate rejected that result. The cache
has no per-frame source receipts and is not independent novel-view evidence. Both images and the
rejection remain recorded.

The engine implementation is opt-in and reads the actual packed, undistorted GPU targets after
low-memory CPU copies have been released. It excludes the existing holdout, evaluation cameras, blur
exclusions, and cameras outside the training loss. A candidate must reduce pooled training MSE by at
least 1% and increase MSE on none of the existing internal validation cameras; otherwise the display
stays black. Internal validation cameras never enter the fit. Raw training PSNR and the black
training background remain identified separately from an accepted `renderBackground`.

Nine independent CPU math checks, four ownership/cancellation checks, a real-WebGPU accepted and
rejected validation case, and the existing resource/training-error checks passed: 35 tests in the
combined run. The GPU fixture verified exact model parameter bytes, camera exclusions, invalid pixel
handling, and fitting from packed targets after CPU RGB cleanup. A later four-test check also
verifies that direct preview rendering cannot race the fit. The product background, progress,
deadline, and training-hold run passed all 18 tests. Fresh native corpus measurements are required
to determine quality and bake-time effects; no acceptance gain is claimed from these checks.

A second fixed-step structural-loss comparison used the native phone allocation ceiling and
direct-gradient path. At 80 steps, weight 0.2 raised two-view mean SSIM only from 0.631690 to
0.634712; weight 0.8 reached 0.637491. Both cost more batch time under overlapping load. Structural
loss remains off. Its configurations and negative results remain separate from native measurements.

The frozen revision-10 source is `1cbccf108294437a2b6ae8b07dead9c56d3f3609`, with served-source
fingerprint `3566b4e1ce4f21382ddab94dfea45443f97aa1c6ae558f3b4026d1d12e9485d7` over 378 paths. Its
complete sample recheck preserved all 74 held-out views across all six samples and both profiles,
without browser errors. This checks the existing bakes and viewer, rather than retraining samples.

The fresh plant phone result has SSIM 0.688856 versus main's 0.668773, with 4.971 times main's
sharpness. Bake time is 602.8 versus 694.0 seconds, while the first 3D view is slower: 111.1 versus
97.4 seconds. The learned color `[0.591038, 0.466980, 0.362629]` passed the fixed training and
internal validation gates. These are whole-revision observations, not a controlled attribution of
every change to the background fit.

The Dianthus phone fit was rejected because its internal validation MSE increased from 0.002876 to
0.002919, and the display stayed black. The native result has SSIM 0.422636 versus main's 0.270086,
with 4.031 times main's sharpness. Bake time is 655.2 versus 1,260.2 seconds, while the first view
is 164.0 versus 110.3 seconds. These raw completed shards remain available before the next strict
aggregation. Cat-play still receives a camera-path rejection even though main finished it. Complete
corpus coverage and the phone speed target remain unproven.

## Rejected faster decoder

An original MIT AVC sample-table parser matched FFprobe's offsets, sizes, PTS, DTS, durations, key
flags, and configuration bytes for 4,008 samples across 17 corpus files. Three files retained
explicit complex-edit-list rejections. With GPU rendering disabled, a WebCodecs prototype reproduced
all 102 predeclared source frames' RGBA and JPEG bytes exactly, including ordinary nonsquare pixels.
Those CPU-only results did not transfer to the benchmark's browser configuration.

Under the actual Chromium 151 SwiftShader flags, both direct VideoFrame drawing and a serial local
video-track bridge changed source pixels. All 12 bridge callback timestamps matched the source PTS,
yet none of the 12 bridge images matched exactly. The real-source differences included one-channel
levels, which were not waived. A separate native plant attempt hit its 12-second fast-path deadline;
an outside-only longer diagnostic also rejected pixel parity. The optimization and its new,
uncommitted tests were archived outside the product. No original test was removed or changed, no
pixel tolerance was introduced, and revision 10 keeps the existing extraction path. The prepared
revision-11 coordinator was never launched.

The API and container references were opened during this investigation:
[VideoDecoder](https://developer.mozilla.org/en-US/docs/Web/API/VideoDecoder),
[VideoFrame](https://developer.mozilla.org/en-US/docs/Web/API/VideoFrame),
[decoder configuration](https://developer.mozilla.org/en-US/docs/Web/API/VideoDecoder/configure),
and [ISO BMFF byte streams](https://www.w3.org/TR/mse-byte-stream-format-isobmff/). Chromium's
documented-in-source SD/HD fallback was checked in
[ffmpeg_common.cc](https://chromium.googlesource.com/chromium/src/+/refs/heads/main/media/ffmpeg/ffmpeg_common.cc).
The negative browser evidence, failed experimental fixtures, and complete resource cleanup receipts
are retained separately from native corpus rows.

## Revision 11: preserve completed models and bound raster work

Optional environment fitting can fail after training has already produced a usable model. A failed
or overdue fit now releases its readback lock and exports that trained model on black. Device loss,
training failure, and export failure still prevent success. Eight controlled browser cases passed,
including the reproduced failure on the preceding source, late completion, and exact exported model
bytes. These controls simulate finishing I/O; they are not native bake measurements.

An opt-in eight-pixel raster tile reduces irrelevant splat intersections on software adapters. Two
cached-input probes used opposite execution orders and preserved full parameters, gradients, output,
loss, and Adam state. Four complete phone-sized optimizer steps took about 1.61 times less combined
time than the sixteen-pixel grid under shared load. That observation used the old entry allocation
and does not establish end-to-end speed for the capacity-safe product implementation.

The smaller grid is selected only when the entire worst-case padded entry list fits both device
buffer limits: declared raster tiles multiplied by the next power of two of the splat ceiling. The
scan covers at most 16,384 tiles. Setup and subsequent draws check captured splat limits, allocated
tile capacity, and allocated pixel capacity; changing the caller's options cannot enlarge those
bounds. Devices or views that cannot meet them select the existing sixteen-pixel grid. Image-wide
SSIM and supersampling kernels retain sixteen-wide dispatches. Testing also exposed and fixed an
existing missing camera-gradient binding in the supersampling backward pass.

The full square phone allocation can reserve 400 MiB for entries instead of 96 MiB. The measured
software device offers a 1 GiB single-buffer limit. Devices with smaller limits retain the prior
allocation and renderer. Fresh native timing and sampled memory are required before claiming a
benefit from this larger allocation. Native image sizes, frame counts, splat ceilings, iteration
budgets, and elapsed-time limits remain unchanged.

The integrated browser checks passed all 24 cases. Independent frozen shader-program expectations
protect the default pipelines. Six real GPU fixtures compare complete state after four optimizer
steps, including partial tiles, invalid pixels, clipped splats, both sorters, structural loss,
supersampling, 2,049 whole-view opaque splats, and capacity fallback. Every checked buffer matched
exactly, with zero GPU errors. The dense case must increase its entry allocation; dropping
contributions cannot satisfy the test. Earlier preparation failures and the supersampling error
remain in their original receipts.

The source freeze covers 378 served paths with SHA-256
`065978f64c7d586b46591356192df441e669243e8478e8e84a46b0eda4cc600b`. Both native lanes wait for every
observed predecessor process to finish naturally. Revision 10's final reconciliation retains 15
paired rows and 11 unpaired raw attempts, including a horse-statue JPEG verification failure. Those
failures are not converted to toy explanations or successful quality rows.

Two additional all-corpus decoder experiments remain excluded. Strict HTML playback completed four
of seventeen supported cases; thirteen missed a required presentation timestamp. A playback/seek
hybrid fully verified sixteen cases and 255 selected JPEGs, but retained four nonresults. In one
clip, matching JPEG bytes still lacked matching independent presentation time. The hybrid is
rejected as a whole; its negatives are not repaired by relaxed timestamp tolerance or retries.

## Full-suite results

The run on `11c90d51` retains all sixteen original shard logs. Fifteen reported summaries contain
2,658 passes, eight failures, and one existing skip; Suite 13 was canceled without a summary. Those
partial totals do not establish full-suite coverage. Alone rechecks never waive original failures.
The full run on `c4752253` tested GitHub merge `b16c549b7ace5b49634957e4e0a390a4989002be`: all 337
spec files completed, with 2,878 passes, ten failures, and one existing skip. All sixteen original
logs and all ten failed or timed-out assertions are retained. The failures were `img-engine:85`,
`hh5-math:104`, `cdx-mir:329`, `ops-text:41`, `sndc-engine:27`, `ui3:50`, `man7a:67`,
`chs-engine:11`, `fx4-engine:79`, and `man5:201`. No Video to 3D spec appears in this failure list.
This run predates the subsequent normal merge of `cb8a8315`, which requires separate verification.
The all-specs gate remains unmet.

The full run for head `d2a90b31` tested GitHub's merge commit
`acdc31904da79a1472d3e4454e2463e7fe9ec62b`, combining that head with main `0fe28c69`. All 332 spec
files completed: 2,834 tests passed, 13 failed, and one existing test was skipped. All sixteen raw
shard logs and the derived summary are retained. The failures were `ui3:50`, `ui3:129`, `man5:201`,
`cdx-mir:329`, `hh4-space:147`, `hh4-weather:141`, `phy:64`, `scr2-engine:10`, `fx4-engine:79`,
`hh5-gems:119`, `img-engine:85`, `smoke:881`, and `sndc-engine:27`. The two WebGPU cases timed out.
Alone rechecks do not waive any original failure.

The local 284-case run on `ca84185a` finished with 281 passes, two calibration decode-deadline
failures, and one existing skip. Its failure screenshots, traces, and original log are retained. A
separate calibration run on revision 11 had seven passes, four decode-deadline failures, and the
same existing skip under overlapping workload. Those failures remain open. The fresh broader
revision-11 regression run was interrupted after 238 passes. The unchanged final spec passed all
fourteen cases when repeated; the separately retained calibration failures remain failures. This
cross-run coverage is not a completed passing suite. No deadline, threshold, assertion, or skip has
been weakened. The all-specs gate is not established.

The full run on `d12824036892077e891d031a33bb71c712d8babd` completed all 327 spec files and 2,812
tests: 2,799 passed, 12 failed, and one existing private-fixture test was skipped. These totals come
from all 16 original shard logs; alone rechecks do not replace failures. No Video to 3D spec appears
in this run's failure list. The learned-environment commits followed that source and still require
their own full-suite run.

The failures were `smoke:878`, `smoke:1050`, `ui3:50`, `ops-text:41`, `qrc-picture:119`, `man5:201`,
`hh3-engine2:122`, `spg:138`, `cdx-mir:329`, `math:368`, `phy:64`, and `hh4-landmarks:116`. The PDF
text, generated PDF, and embed-guide checks also failed alone; several others passed alone but still
count as failures. Earlier full-suite and local failures remain in their original receipts. The
requirement that every existing spec pass is not established.

## Review media

A source-bound queue is authorized for one revision-12 batch only after 16:15 UTC and after every
bound timed-work identity and observed descendant has ceased. It retains the unchanged exact
held-out replay guards and requests up to ten verified phone pairs in manifest order, independent of
quality scores. Baseline failures prevent honest full-corpus best/worst ranking, so these
comparisons remain unranked. The requested panes are 390 by 844 pixels, with five source seconds at
12 fps. Only actual capture receipts can establish completed movies. The queue cannot signal timed
bakes; its own rendering stops before 16:31:30 UTC.

The first idle watcher exited with a process-identity validation error before any render reservation
or capture. Root observed its exited identity and retained the error log and all 262 bindings from
its last successful observation. An attempted root takeover stopped at its initial assertion before
sending any signal. A replacement guard is being prepared to retain this history, include the
separate post-merge sample controller, and fail closed on unresolved process observations. No
benchmark or held-out replay guard is relaxed to recover a movie.

The
[media branch](https://github.com/ryanjosephkamp/splashery/tree/codex/video-3d-r4-clips/review/video-3d-r4)
retains source attribution beside the clips. Its first unranked r3 comparison reproduced all eight
saved held-out PNGs exactly before capturing 11 real views at 2 fps over five source seconds,
followed by a half-second final hold. Both models remain visibly blurred; it is not a ten-clip
acceptance result. A replay must reproduce every saved held-out render exactly before synchronized
phone-size comparison video is accepted. The two reconstructions use the same recorded video times
in their own coordinate frames. Five best and five worst clips will be identified from completed
measurements; missing paired reconstructions will be disclosed, rather than filled with invented 3D.

## Supplemental evaluation of stored timeout models

A bake can save its PLY, camera metadata, and hash-bound independent source-frame receipts before
its host deadline interrupts scoring. `tools/v3d-bench-supplement.mjs` snapshots that complete raw
case and captured run before any replay. It accepts only evaluation-stage host-deadline errors,
checks every available original binding, and leaves the strict row and censored timing unchanged. An
optional independently saved snapshot also checks the currently stored metadata bytes.

`model.json` was not hashed in the original benchmark row. The supplementary snapshot newly binds
its exact bytes and uses its stored poses unchanged; this is not historical metadata-byte
verification. Every training JPEG and held-out JPEG must again match the original independent pixel
receipts, and source references use the frozen exact FFmpeg frame indices. Any original saved render
PNG must reproduce exactly. A case without original render PNGs is explicitly a new read-only
evaluation, not verification of an original capture.

Prepare the CPU-only immutable snapshot separately from a replay:

```sh
node tools/v3d-bench-supplement.mjs prepare tools/v3d-corpus.json \
  /workspace/v3d-r4-media/corpus /workspace/v3d-r4-media/main-r1 \
  /workspace/v3d-r4-media/supplement-main-r1-pisac-phone-r1 \
  --id=pisac --profile=phone --cleanup=main

# Run separately from timed bakes, with the same frozen served source.
node tools/v3d-bench-supplement.mjs render \
  /workspace/v3d-r4-media/supplement-main-r1-pisac-phone-r1 \
  --url=http://127.0.0.1:4174/ --timeout=600000
```

The derived report is a supplemental quality diagnostic. It cannot recover censored timing, turn an
original harness error into a pass, fill missing strict cohort outcomes, or bypass the existing
comparison and review gates. A supplementary movie would require its own explicit diagnostic label
and the same source/provenance and pixel checks. Preparing or unit-testing this tool is not evidence
that a real browser replay succeeded.

The Pisac phone replay completed with SSIM 0.55978164, Laplacian variance 0.00012631448, and PSNR
15.2923 dB. All 16 training JPEG receipts and four held-out source receipts were independently
reproduced. The original row remains an evaluation-stage harness error with censored timing; there
were no original render PNGs to verify. These are supplemental scores, excluded from strict
acceptance. The images still show substantial blur and color artifacts.

## Rejected geometry and depth experiments

Revision 6 replaced the surface initializer's approximate world-space footprint with the exact local
perspective Jacobian and rejected highly grazing planes. An independent projected-covariance check
passed, but actual held-out results regressed: cat sharpness was 0.7412 times main's, with SSIM up
only 0.00251; plant sharpness was about 0.659 times main's, with SSIM down 0.05380. This footprint
experiment is excluded from the product default. Correct covariance alone did not establish better
reconstruction.

A separate four-frame probe ran the already-vendored depth model through its dedicated worker. Every
anchor failed the fixed minimum sparse-depth-spread gate before robust affine calibration or
third-camera RGB validation. It proposed zero points and measured no quality gain. This does not
prove that calibration is mathematically impossible; it provides no evidence to integrate this model
into Video to 3D. The probe's raw inference times, model and WASM byte receipts, fixed
configuration, output maps, and failures are retained separately from timed corpus bakes.

A deterministic plane-fit probe accepted no plane: its largest refined support was 43 of 614 points,
below the fixed 20% gate. It proposed no dense points. The same investigation identified the distant
point's disproportionate effect on the seed radius; changing the bounds does not turn the rejected
plane into accepted geometry.

The first structural-loss experiment was invalid: its backward shader required nine storage bindings
on the default eight-binding device. The failed run and all errors are retained; its structural-loss
scores cannot be used. An `Engine:` fix removes the unused camera-gradient binding for this path. A
real browser regression now trains and exports at the default limit, with improved fit and exact
shared/direct parameters after 20 steps. The completed fixed-input probes above measured small SSIM
gains and substantial additional cost; structural loss remains disabled in the product.
