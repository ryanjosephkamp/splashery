# Native outcome table addendum

This additive CPU tool reads an immutable captured report.json.gz, verifies its decompressed SHA against snapshot-freeze.json, and copies the original strict-comparison.json.gz unchanged after checking its recorded hash and contents. It changes neither frozen reporting kit, original rows, statuses, source data, nor strict gates. No browser, GPU job, native work, process inspection, signal, repository or protocol edit occurs.

The primary table has20rows each for phone and desktop. It first uses an actual original strict paired-master row, including a failed row. If no strict row exists, it selects the latest captured raw reservation and labels it raw paired or unpaired raw. Reservation ordinals are checked against actual available timestamps. Duplicate/contradictory chronology fails closed. A later pending attempt stays pending; an older successful row cannot replace it. A completed unpaired raw outcome is shown as finished rather than missing, but never enters strict comparison.

First3D and bake timing are shown as main → R12 only for original successful, accounted outcomes. Failed/rejected/pending timings are censored. Original recorded values remain in compressed machine data and the full source report. RSS is an original recorded peak in MiB, not an acceptance gate. Main SSIM and R12 absolute SSIM have separate columns. Raw/unpaired SSIM uses its own heldout frames and does not establish a comparable gain.

The per-case sharpness ratio requires original strict paired successful/accounted rows, complete independent heldout receipts, exact original baseline result/evaluation references, identical scored source times/reference hashes, and finite comparable scores. No ratio is computed for raw paired, unpaired raw, failed/mismatched/incomplete references, or missing scores. Ratios are diagnostic and do not establish a complete-corpus gate.

## Final capture command

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/v3d-r4-media/native-outcome-table-addendum-r1/generate.mjs --report=/workspace/v3d-r4-media/final-r12-report-preparation-r1/snapshot-1615/report.json.gz --out=/workspace/v3d-r4-media/native-outcomes-r12-final-r1 --raw-base=.
```

Root may copy native-outcomes.md, receipt.json, table-data.json.gz, source-report.json.gz and strict-comparison.json.gz alongside its final publication snapshot. The default relative raw links then resolve inside the copied packet. If the table is published elsewhere, supply the actual relative/root-site base for that final snapshot. No absolute workspace path is presented as a published URL. Do not mutate the original frozen snapshot. Full earlier attempts remain in source-report.json.gz and the separate recorded-causes addendum.

The generated table-data.json.gz is lossless gzip; receipt.json binds both stored and restored SHA-256. Source-report.json.gz and strict-comparison.json.gz are exact-byte copies. The original strict comparator outcome is never recomputed from presentation-selected raw rows.

## Preserved actual demonstration

`partial-1432-demo/` uses only the existing14:32:14.301UTC snapshot. It is partial evidence, not a later native capture or final result. It contains40rows: phone9strict,3raw-paired,8unattempted; desktop1strict,10unpaired-raw,9unattempted. Pending reservations remain pending. Its relative links point to the local preserved source snapshot, so generate a fresh final output for publication.

Twelve focused CPU controls passed, including an in-memory genuine raw-success presentation case, latest-pending retention, failed-strict priority, score-independent selection, ambiguous chronology rejection, original status/identity checks, timing censorship, actual strict-pair ratio eligibility, raw/mismatched/failed-reference gain rejection, complete40row inventory and unchanged gates. Unit fixtures are clearly in-memory tests and never actual R12 output. The actual demonstration uses no fabricated rows.

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node --test /workspace/v3d-r4-media/native-outcome-table-addendum-r1/test.mjs
```

MIT code. Made by Ryan with Codex (GPT-6). Original recorded source facts retain their attribution/licenses. The original reporting freeze282b68a06de7ea96bd7fce9389d5d3420196001287e08fbff6867025d1621858 and causes freeze d18cca30f810b22da44e1c07b16a66434d772bbcf6f52335ea9ac448979b11b1 remain unchanged.
