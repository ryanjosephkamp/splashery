# Native R12 outcomes: all20 clips at both profiles

Source report captured 2026-10-15T14:31:42.618Z to 2026-10-15T14:32:14.301Z; native source 64ec9ad5b7a90b590b289f6a02f0bbd50138db08.

The table prefers an existing original strict paired-master row, including failed rows. Otherwise it displays the latest captured raw reservation, labeled raw paired or unpaired raw. A later pending attempt remains pending; an older favorable result never replaces it. Every attempt remains preserved in the original report and causes addendum.

Raw/unpaired absolute SSIM uses its own heldout frames and is not a comparable gain. Sharpness ratios appear only for source-verified strict paired successes with identical references. No raw row is promoted into strict gates. Incomplete/rejected timing is censored; RSS is an original recorded peak, not an acceptance gate. Main → R12 timing uses seconds; RSS uses MiB.

4-core CPU quota; SwiftShader software GPU; overlapping local jobs. Phone/desktop are viewport profiles, not physical-device measurements.

## phone

| Clip | Main outcome | R12 mode / original outcome | First3D s main → R12 | Bake s main → R12 | RSS MiB main → R12 | Main SSIM | R12 absolute SSIM | Strict sharpness ratio | Original R12 evidence |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| cat-track | explained | strict paired / harness-error | censored → censored | censored → censored | 1152.8 → 1597.9 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/cat-track-phone/result.json.gz) |
| cat-plays | finished | strict paired / explained | 69.634 → censored | 875.78 → censored | 1401.1 → 1056.9 | 0.31284 | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/cat-plays-phone/result.json.gz) |
| buddha | explained | strict paired / explained | censored → censored | censored → censored | 1141.5 → 1089.4 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/buddha-phone/result.json.gz) |
| chameleon-flowers | finished | strict paired / finished | 97.407 → 118.82 | 693.97 → 604.99 | 1381.6 → 1625.3 | 0.66877 | 0.63563 | 14.050× | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/chameleon-flowers-phone/result.json.gz) |
| dianthus | finished | strict paired / finished | 110.30 → 105.63 | 1260.2 → 591.33 | 1322.5 → 1644.3 | 0.27009 | 0.42811 | 5.2607× | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/dianthus-phone/result.json.gz) |
| pisac | harness-error | unattempted / missing / missing | censored → censored | censored → censored | 1351.0 → — | — | — | — | No original row |
| sleeping-dog | explained | strict paired / explained | censored → censored | censored → censored | 1101.0 → 1077.3 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/sleeping-dog-phone/result.json.gz) |
| palace-statue | timeout | unattempted / missing / missing | censored → censored | censored → censored | 1309.2 → — | — | — | — | No original row |
| oa-street | explained | strict paired / explained | censored → censored | censored → censored | 1078.5 → 1070.2 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/oa-street-phone/result.json.gz) |
| ullard | finished | strict paired / finished | 182.00 → 95.883 | 1335.9 → 583.38 | 1364.2 → 1630.2 | 0.45704 | 0.47076 | 5.3993× | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/ullard-phone/result.json.gz) |
| snaefell | finished | strict paired / finished | 187.98 → 188.08 | 1144.4 → 677.09 | 1394.0 → 1662.0 | 0.63768 | 0.64001 | 3.8154× | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/snaefell-phone/result.json.gz) |
| fremantle-orbit | finished | raw paired / finished | 194.43 → 108.80 | 1329.1 → 591.44 | 1335.5 → 1576.3 | 0.71662 | 0.63986 | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/016-fremantle-orbit-phone-paired/fremantle-orbit-phone/result.json.gz) |
| ihasalu-orbit | finished | raw paired / finished | 163.67 → 100.58 | 1358.3 → 591.84 | 1321.7 → 1612.7 | 0.48304 | 0.63021 | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/019-ihasalu-orbit-phone-paired/ihasalu-orbit-phone/result.json.gz) |
| fresnel-lens | finished | raw paired / pending / no original native row | 129.77 → censored | 1440.8 → censored | 1337.1 → — | 0.65549 | — | — | No original row |
| saint-denis | finished | unattempted / missing / missing | 216.69 → censored | 1374.9 → censored | 1354.4 → — | 0.25429 | — | — | No original row |
| horse-statue | explained | unattempted / missing / missing | censored → censored | censored → censored | 1082.7 → — | — | — | — | No original row |
| royal-sovereign | finished | unattempted / missing / missing | 92.647 → censored | 1479.9 → censored | 1350.7 → — | 0.60075 | — | — | No original row |
| viljandi-ruins | finished | unattempted / missing / missing | 185.81 → censored | 1685.0 → censored | 1325.3 → — | 0.53227 | — | — | No original row |
| kakerdi-bog | finished | unattempted / missing / missing | 176.25 → censored | 1523.1 → censored | 1334.1 → — | 0.34732 | — | — | No original row |
| fjoloy | harness-error | unattempted / missing / missing | censored → censored | censored → censored | 1040.8 → — | — | — | — | No original row |

## desktop

| Clip | Main outcome | R12 mode / original outcome | First3D s main → R12 | Bake s main → R12 | RSS MiB main → R12 | Main SSIM | R12 absolute SSIM | Strict sharpness ratio | Original R12 evidence |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| cat-track | timeout | unpaired raw / explained | censored → censored | censored → censored | 1845.1 → 1501.6 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/006-cat-track-desktop-unpaired/cat-track-desktop/result.json.gz) |
| cat-plays | explained | strict paired / explained | censored → censored | censored → censored | 1314.9 → 1290.2 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/paired-master/cat-plays-desktop/result.json.gz) |
| buddha | timeout | unpaired raw / explained | censored → censored | censored → censored | 1754.5 → 1319.2 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/008-buddha-desktop-unpaired/buddha-desktop/result.json.gz) |
| chameleon-flowers | timeout | unpaired raw / explained | censored → censored | censored → censored | 2046.3 → 1464.7 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/009-chameleon-flowers-desktop-unpaired/chameleon-flowers-desktop/result.json.gz) |
| dianthus | timeout | unpaired raw / explained | censored → censored | censored → censored | 1903.0 → 1160.3 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/013-dianthus-desktop-unpaired/dianthus-desktop/result.json.gz) |
| pisac | timeout | unpaired raw / harness-error | censored → censored | censored → censored | 1722.4 → 1550.1 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/014-pisac-desktop-unpaired/pisac-desktop/result.json.gz) |
| sleeping-dog | timeout | unpaired raw / explained | censored → censored | censored → censored | 1462.0 → 1494.6 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/017-sleeping-dog-desktop-unpaired/sleeping-dog-desktop/result.json.gz) |
| palace-statue | timeout | unpaired raw / explained | censored → censored | censored → censored | 1598.2 → 1120.9 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/018-palace-statue-desktop-unpaired/palace-statue-desktop/result.json.gz) |
| oa-street | timeout | unpaired raw / explained | censored → censored | censored → censored | 2058.9 → 1157.4 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/020-oa-street-desktop-unpaired/oa-street-desktop/result.json.gz) |
| ullard | timeout | unpaired raw / explained | censored → censored | censored → censored | 1858.5 → 1471.4 | — | — | — | [original](../../final-r12-report-preparation-r1/snapshot-partial-verification-0001/evidence/raw/021-ullard-desktop-unpaired/ullard-desktop/result.json.gz) |
| snaefell | timeout | unpaired raw / pending / no original native row | censored → censored | censored → censored | 1526.9 → — | — | — | — | No original row |
| fremantle-orbit | timeout | unattempted / missing / missing | censored → censored | censored → censored | 2078.1 → — | — | — | — | No original row |
| ihasalu-orbit | timeout | unattempted / missing / missing | censored → censored | censored → censored | 1989.8 → — | — | — | — | No original row |
| fresnel-lens | timeout | unattempted / missing / missing | censored → censored | censored → censored | 1737.0 → — | — | — | — | No original row |
| saint-denis | timeout | unattempted / missing / missing | censored → censored | censored → censored | 2074.9 → — | — | — | — | No original row |
| horse-statue | timeout | unattempted / missing / missing | censored → censored | censored → censored | 1742.2 → — | — | — | — | No original row |
| royal-sovereign | missing | unattempted / missing / missing | censored → censored | censored → censored | — → — | — | — | — | No original row |
| viljandi-ruins | missing | unattempted / missing / missing | censored → censored | censored → censored | — → — | — | — | — | No original row |
| kakerdi-bog | missing | unattempted / missing / missing | censored → censored | censored → censored | — → — | — | — | — | No original row |
| fjoloy | missing | unattempted / missing / missing | censored → censored | censored → censored | — → — | — | — | — | No original row |

Strict comparator completion and gates are preserved unchanged in strict-comparison.json.gz. Per-case ratios do not establish corpus acceptance. Full original rows, failed timing values, all earlier attempts and heldout provenance remain in source-report.json.gz.
