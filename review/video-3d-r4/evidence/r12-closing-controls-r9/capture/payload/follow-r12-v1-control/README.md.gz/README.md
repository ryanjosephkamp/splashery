# R12 preparation — NOT launched

MIT. Made by Ryan with Codex (GPT-6). Outside-repository orchestration only. Root owns all source files, source freeze, predecessor retirement, final declaration, and native launch. No browser, GPU, signal, live-process identity inspection/capture, fake source freeze, provenance template, or acceptance result was produced during preparation. R11, R1/R2 parser evidence, and dashboard snapshots are untouched.

Fresh R12 paths: immutable tools `/workspace/splashery-v3d-bench-tools-r12`, future runtime URL `http://127.0.0.1:4183/`, root freeze receipt `/workspace/v3d-r4-media/runtime-r12-freeze.json`, control `follow-r12-v1-control`, shards `candidate-r12-v1-shards`, paired snapshots `candidate-r12-paired-snapshots-v1`, paired alias `candidate-r12-paired-master-v1`. Shards/master/snapshots are not created during preparation.

The prepared `declaration.json` deliberately has null source/product/tools/provenance fields and no captured predecessor PID. `templates/` is empty. No `prior-native-handoff.json` or `runtime-freeze.json` exists here. `prior-frozen-r11-identity.json` preserves only already frozen R11 source/provenance identities for reuse rejection; it contains no running process information.

Policy is unchanged: all20manifest IDs, both profiles, native Auto/default budgets, explicit SwiftShader GPU, same five protocol bytes and wrappers, same baseline provenance7c714d23fd839129b6abbf718460cd7bf5bad59c34988292a26e4c5046aa05e6, cutoff16:15UTC2026-10-15. Select accountable baseline first, then existing incomplete, then missing, in manifest order. Every existing case folder/reserved shard/outcome consumes its generation/case/profile/mode regardless of quality/status. No paired retry. An initially unpaired case has one predeclared paired repeat only when its immutable baseline row becomes accountable. R11/R10/R9/R8 rows are never imported into R12. Failures/unpaired evidence remain separate from strict paired joins.

Prepared tests use fake process identities exclusively and never enumerate live processes. Each lane waits independently for its root-observed old R11 native Node PID/startTicks and ALL observed descendants. Its sibling lane can continue. PID reuse/zombies do not block; process-title changes do not release an owned live identity. Root must retire only the prior Python coordinator, allow native children to finish naturally, and provide the complete actual retirement receipt. The R12 coordinator never signals predecessors. Its inherited16:15 collection cutoff handles only its own newly launched subtree and preserves any incomplete native outcome; it invents no benchmark status.

## Root finalization, after real freeze and handoff

1. Create the actual immutable tools checkout and runtime4183; save real `runtime-r12-freeze.json` with productCommit, URL, exact servedSource inventory, and protocolFiles, using the same schema as R11. Do not populate source/provenance placeholders from older runs.
2. Prepare new source/input/browser/protocol receipts without launching a browser. Use the unchanged native Node24 executable so its environment agrees with runner provenance:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node /workspace/v3d-r4-media/prepare-r12-provenance.mjs --product-commit=ACTUAL_40_HEX --tools-commit=ACTUAL_40_HEX > /workspace/v3d-r4-media/follow-r12-v1-control/provenance-preparation.log
```

This imports the frozen R12 protocol exports, verifies all20input bytes and all five old protocol bytes/wrappers, reads actual served HTTP bytes, and computes separate paired/unpaired provenance. It creates `templates/paired.json`, `templates/unpaired.json`, `runtime-freeze.json` and `provenance-preparation.json` once. Existing outputs cause refusal. It checks new source bytes and new product identity against frozen R11; there is no inferred R11 provenance reuse.

3. At retirement, root captures the exact old Python coordinator identity, marks its actual retirement, and captures each lane's exact old native plus ALL descendants. `root-handoff-template.json` documents the schema but cannot authorize launch. Save the REAL receipt as `prior-native-handoff.json`:

```json
{
  "generation": "R11",
  "capturedAt": "ACTUAL_UTC_TIMESTAMP",
  "coordinator": {
    "pid": "ACTUAL_INTEGER",
    "startTicks": "ACTUAL_DECIMAL_STRING",
    "command": ["python3", "/workspace/v3d-r4-media/follow-r11-v1.py"],
    "retiredByRoot": true,
    "retiredAt": "ACTUAL_UTC_TIMESTAMP"
  },
  "profiles": {
    "phone": {"native": "ACTUAL_BINDING_OR_NULL_IF_ROOT_OBSERVED_NONE", "descendants": {}},
    "desktop": {"native": "ACTUAL_BINDING_OR_NULL_IF_ROOT_OBSERVED_NONE", "descendants": {}}
  }
}
```

The illustrative quoted `ACTUAL_INTEGER` must be an actual JSON integer. Native/descendant binding schema is `{pid: integer, startTicks: decimal-string, command: original-string-array}`; descendants dictionary keys must equal each binding's PID. Do not use empty descendants when any are observed. A native command must identify R11's shard root and its correct `--profiles=` lane. Native null is allowed only when root observed no active native child; surviving descendants must still be bound. No concrete PID/startTicks is supplied by this preparation.

4. Finalize with explicitly read NEW identities and root authorization text. This step validates receipts but does not launch or signal:

```sh
python3 /workspace/v3d-r4-media/finalize-r12-declaration.py --product-commit=ACTUAL_40_HEX --tools-commit=ACTUAL_40_HEX --served-source=ACTUAL_64_HEX --paired-provenance=ACTUAL_64_HEX --unpaired-provenance=ACTUAL_64_HEX --authorization='ACTUAL ROOT LAUNCH AUTHORIZATION'
python3 /workspace/v3d-r4-media/follow-r12-v1.py --check
```

`finalize` requires passing CPU receipt and fresh unlaunched state, binds orchestration/receipt/protocol/template bytes, rejects an active old coordinator or incomplete/changed blocker handoff, and preserves the original pending declaration as `declaration-prepared.json`. It cannot fill source or identities by inference. `--check` is read-only with respect to native work; integrity state receipts can be written. Only after successful finalization/preflight may root launch the coordinator using its own detached-launch process/receipt. This preparation does not launch it.

## Verification

`python3 /workspace/v3d-r4-media/test-follow-r12-v1.py` passed32CPUtests in11.660s (cpu-tests-final.log), including score-independent ordering, no paired retry, once-only unpaired repeat, per-profile readiness, surviving descendants, PID reuse/title changes, reserved attempts, unknown-shard rejection, R11 source/provenance reuse rejection, missing freeze/retirement/source fields, mismatched profile/descendant keys, and copied real artifact corruption. The copied R8 fixture and identical frozen R9 protocol are CPU fixtures only and never become live R12 sources. New JS adapter/preparer pass Node syntax checks. No native source freezing or browser/GPU launch occurs in this suite.

Run these preparation tests only while the control directory is still pending; tests intentionally assert that no final source/handoff exists. Root can preserve this verified log for finalization instead of rerunning those pending-state assertions after finalization. Code and current pending receipts are frozen under `r12-orchestration-preparation-r1/freeze.json`; that is a preparation receipt, not a product freeze or run result. Source owner remains root.

The exact new productCommit, toolsCommit, servedSourceSha256, pairedProvenanceSha256, unpairedProvenanceSha256, authorization, priorCoordinator, and priorNativeBlockers remain null in declaration.json. Source/runtime freeze, per-mode templates, retirement handoff, and native process identities are root-owned future inputs. The already-frozen prior identity is R11 commit636a7605fd15f3aa1e41d43cc6b5ff35432750b6, served-source065978f64c7d586b46591356192df441e669243e8478e8e84a46b0eda4cc600b. handoff.schema.json describes the final receipt shape; runtime additionally enforces generation, lane command, PID-key agreement, unique identities, and receipt byte bindings. No launch receipt or acceptance result exists.

Rule check: none.
