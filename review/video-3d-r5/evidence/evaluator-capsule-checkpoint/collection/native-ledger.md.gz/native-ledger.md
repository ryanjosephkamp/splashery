# Protocol 5 decoded-picture native per-clip ledger

Protocol 5, decoded-picture candidate only; current native rows only, with explicitly archived harness attempts kept separately; all superseded candidate rows are excluded. Exact native rows retain their original outcomes and provenance. Independent unpaired outcomes, are indexed but cannot establish comparative gains. Partial medians are diagnostics. Acceptance must come from the unchanged production comparator on complete compatible evidence.

## phone

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | explained | explained | verified | — / — | — / — | — / — |
| cat-plays | finished | finished | verified | 0.311 / 0.324 | 54.1 / 38.6 | 680.0 / 523.9 |
| buddha | explained | explained | verified | — / — | — / — | — / — |
| chameleon-flowers | finished | finished | verified | 0.622 / 0.730 | 37.7 / 31.7 | 547.3 / 521.8 |
| dianthus | finished | finished | verified | 0.274 / 0.511 | 64.5 / 48.5 | 573.3 / 532.2 |
| pisac | finished | finished | verified | 0.563 / 0.615 | 45.1 / 29.5 | 594.7 / 512.9 |
| sleeping-dog | explained | explained | verified | — / — | — / — | — / — |
| palace-statue | finished | not recorded | not established | 0.252 / — | 44.9 / — | 671.3 / — |
| oa-street | not recorded | not recorded | not established | — / — | — / — | — / — |
| ullard | not recorded | not recorded | not established | — / — | — / — | — / — |
| snaefell | not recorded | not recorded | not established | — / — | — / — | — / — |
| fremantle-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| ihasalu-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| fresnel-lens | not recorded | not recorded | not established | — / — | — / — | — / — |
| saint-denis | not recorded | not recorded | not established | — / — | — / — | — / — |
| horse-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| royal-sovereign | not recorded | not recorded | not established | — / — | — / — | — / — |
| viljandi-ruins | not recorded | not recorded | not established | — / — | — / — | — / — |
| kakerdi-bog | not recorded | not recorded | not established | — / — | — / — | — / — |
| fjoloy | not recorded | not recorded | not established | — / — | — / — | — / — |

## desktop

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | timeout | harness-error | not established | — / — | — / — | — / — |
| cat-plays | explained | explained | verified | — / — | — / — | — / — |
| buddha | timeout | explained | not established | — / — | — / — | — / — |
| chameleon-flowers | timeout | explained | not established | — / — | — / — | — / — |
| dianthus | not recorded | not recorded | not established | — / — | — / — | — / — |
| pisac | not recorded | not recorded | not established | — / — | — / — | — / — |
| sleeping-dog | not recorded | not recorded | not established | — / — | — / — | — / — |
| palace-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| oa-street | not recorded | not recorded | not established | — / — | — / — | — / — |
| ullard | not recorded | not recorded | not established | — / — | — / — | — / — |
| snaefell | not recorded | not recorded | not established | — / — | — / — | — / — |
| fremantle-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| ihasalu-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| fresnel-lens | not recorded | not recorded | not established | — / — | — / — | — / — |
| saint-denis | not recorded | not recorded | not established | — / — | — / — | — / — |
| horse-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| royal-sovereign | not recorded | not recorded | not established | — / — | — / — | — / — |
| viljandi-ruins | not recorded | not recorded | not established | — / — | — / — | — / — |
| kakerdi-bog | not recorded | not recorded | not established | — / — | — / — | — / — |
| fjoloy | not recorded | not recorded | not established | — / — | — / — | — / — |

Nonfinished attempts have no completed-bake or first-view timing in this table. Their censored timing, visible explanation, advice, and original status remain in each raw row. Missing or unpaired measurements cannot establish an improvement.
