// Diagnostic index only. Native files and outcomes are never rewritten.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { accountedOutcome, fingerprint, median } from '/workspace/work/v3d-r5/evaluator-protocol5/tools/v3d-bench-metrics.mjs';
const root = '/workspace/work/v3d-r5/final-run';
const clips = JSON.parse(fs.readFileSync('/workspace/splashery/tools/v3d-corpus.json', 'utf8'));
const expected = new Map(clips.map(c => [c.id, c.sha256]));
const protocol = '154576a01c7a624fb63dfb034cd7bb5d94407691472c56554584f54ca34c69e9';
const sources = {main: '99cea09dd4f5367f78cfe4d1b5bed97cb87432c38222e6c81edf873be25da9fa', candidate: 'e3b91a511c9d0732102f599395ec9fdf57bc9920dae4f9362c0d262348abfa68'};
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
function files(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, {withFileTypes:true}).filter(e=>e.name!=='attempts').flatMap(e => e.isDirectory() ? files(path.join(dir,e.name)) : e.name==='run.json' ? [path.join(dir,e.name)] : []);
}
function collect(group, version) {
  const result=[];
  for (const file of files(path.join(root,'runs',group))) {
    const bytes=fs.readFileSync(file), run=JSON.parse(bytes);
    if (fingerprint(run.provenance)!==run.provenanceSha256 || run.provenance.protocolSha256!==protocol || run.provenance.servedSource.sha256!==sources[version]) throw Error('Unexpected or damaged frozen provenance: '+file);
    if (run.results.length>1) throw Error('Expected one native case: '+file);
    for (const row of run.results) {
      if (expected.get(row.id)!==row.sha256 || !['phone','desktop'].includes(row.profile) || row.provenanceSha256!==run.provenanceSha256) throw Error('Changed case identity: '+file);
      result.push({version,group,key:row.id+'/'+row.profile,source:path.relative(root,file),runSha256:hash(bytes),provenanceSha256:run.provenanceSha256,sourceSha256:run.provenance.servedSource.sha256,referenceBound:!!run.provenance.reference,accounted:!!accountedOutcome(row),environment:run.provenance.environment,options:run.provenance.options,row});
    }
  }
  return result;
}
const main=collect('main','main'), candidate=[...collect('decoded-picture-strict-candidate','candidate'),...collect('decoded-picture-unpaired-candidate','candidate')];
for (const rows of [main,candidate]) if (new Set(rows.map(r=>r.key)).size!==rows.length) throw Error('Duplicate native case; refusing to select a favorable result.');
const lookup=(rows,id,profile)=>rows.find(r=>r.key===id+'/'+profile);
function strict(a,b) {
  const evidence=b?.row.referenceEvidence;
  return !!(a && b?.referenceBound && b.accounted && a.accounted && evidence?.provenanceSha256===a.provenanceSha256 && evidence.resultFingerprint===fingerprint(a.row) && fingerprint(a.environment)===fingerprint(b.environment) && fingerprint(a.options)===fingerprint(b.options) && (a.row.status!=='finished' || evidence.evaluationSha256===a.row.evaluationSha256));
}
function quality(a,b) {
  return strict(a,b) && a.row.status==='finished' && b.row.status==='finished' && a.row.heldoutEvidence?.complete===true && b.row.heldoutEvidence?.complete===true && a.row.frames?.length>0 && JSON.stringify(a.row.frames.map(f=>[f.time,f.referenceSha256]))===JSON.stringify(b.row.frames?.map(f=>[f.time,f.referenceSha256])) && [a.row.mean?.laplacian,b.row.mean?.laplacian,a.row.mean?.ssim,b.row.mean?.ssim].every(Number.isFinite);
}
const profiles={};
for (const profile of ['phone','desktop']) {
  const before=main.filter(r=>r.row.profile===profile), after=candidate.filter(r=>r.row.profile===profile);
  const pairs=clips.map(c=>[lookup(main,c.id,profile),lookup(candidate,c.id,profile)]).filter(([a,b])=>quality(a,b));
  const baseSharpness=median(pairs.map(([a])=>a.row.mean.laplacian)), newSharpness=median(pairs.map(([,b])=>b.row.mean.laplacian));
  const baseSsim=median(pairs.map(([a])=>a.row.mean.ssim)), newSsim=median(pairs.map(([,b])=>b.row.mean.ssim));
  const times={};
  for (const key of ['firstViewMs','bakeMs']) {
    const timed=pairs.filter(([a,b])=>Number.isFinite(a.row[key])&&Number.isFinite(b.row[key]));
    times[key]={pairs:timed.length,mainMedian:median(timed.map(([a])=>a.row[key])),candidateMedian:median(timed.map(([,b])=>b.row[key])),mainWorst:timed.length?Math.max(...timed.map(([a])=>a.row[key])):null,candidateWorst:timed.length?Math.max(...timed.map(([,b])=>b.row[key])):null};
  }
  profiles[profile]={expected:20,mainCompleted:before.length,candidateCompleted:after.length,candidateAccounted:after.filter(r=>r.accounted).length,candidateStatuses:Object.fromEntries([...new Set(after.map(r=>r.row.status))].map(s=>[s,after.filter(r=>r.row.status===s).length])),strictPairedOutcomes:clips.filter(c=>strict(lookup(main,c.id,profile),lookup(candidate,c.id,profile))).length,qualityPairs:pairs.length,qualityIds:pairs.map(([a])=>a.row.id),diagnosticSharpnessMain:baseSharpness,diagnosticSharpnessCandidate:newSharpness,diagnosticSharpnessRatio:baseSharpness>0?newSharpness/baseSharpness:null,diagnosticSsimMain:baseSsim,diagnosticSsimCandidate:newSsim,diagnosticSsimGain:pairs.length?newSsim-baseSsim:null,diagnosticTiming:times,acceptanceEstablished:false};
}
const ledger={at:new Date().toISOString(),notice:'Protocol 5, decoded-picture candidate only; current native rows only, with explicitly archived harness attempts kept separately; all superseded candidate rows are excluded. Exact native rows retain their original outcomes and provenance. Independent unpaired outcomes, are indexed but cannot establish comparative gains. Partial medians are diagnostics. Acceptance must come from the unchanged production comparator on complete compatible evidence.',mainCompleted:main.length,candidateCompleted:candidate.length,candidateAccounted:candidate.filter(r=>r.accounted).length,candidateNativeOutcomesComplete:candidate.length===40&&candidate.every(r=>r.accounted),profiles,main,candidate};
fs.writeFileSync(path.join(root,'session-isolated-media/native-ledger.json'),JSON.stringify(ledger,null,2)+'\n');
const fmt=(v,d=3)=>Number.isFinite(v)?v.toFixed(d):'—';
const timing=(row,key)=>row?.status==='finished'?fmt(row[key]/1000,1):'—';
let md='# Protocol 5 decoded-picture native per-clip ledger\n\n'+ledger.notice+'\n\n';
for (const profile of ['phone','desktop']) {
 md+='## '+profile+'\n\n| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |\n| --- | --- | --- | --- | --- | --- | --- |\n';
 for (const clip of clips) {
   const a=lookup(main,clip.id,profile),b=lookup(candidate,clip.id,profile);
   md+=`| ${clip.id} | ${a?.row.status??'not recorded'} | ${b?.row.status??'not recorded'} | ${strict(a,b)?'verified':'not established'} | ${fmt(a?.row.mean?.ssim)} / ${fmt(b?.row.mean?.ssim)} | ${timing(a?.row,'firstViewMs')} / ${timing(b?.row,'firstViewMs')} | ${timing(a?.row,'bakeMs')} / ${timing(b?.row,'bakeMs')} |\n`;
 }
 md+='\n';
}
md+='Nonfinished attempts have no completed-bake or first-view timing in this table. Their censored timing, visible explanation, advice, and original status remain in each raw row. Missing or unpaired measurements cannot establish an improvement.\n';
fs.writeFileSync(path.join(root,'session-isolated-media/native-ledger.md'),md);
console.log(JSON.stringify({at:ledger.at,main:main.length,candidate:candidate.length,accounted:ledger.candidateAccounted,profiles}));
