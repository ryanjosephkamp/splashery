import fs from 'node:fs';
import {sourceFrameReceipts} from '/workspace/splashery/tools/v3d-bench-pixels.mjs';
let body=sourceFrameReceipts.toString();
body=body.replace('        let done = false;','        let done = false;\n        let directSeek = false;');
const start=body.indexOf('        const settled = () => {'),end=body.indexOf('        const failed = () =>',start);
if(start<0||end<0)throw Error('Frozen source decoder seam changed');
body=body.slice(0,start)+`        const preroll = () => {
          let from = Math.max(0, index - 4);
          while (from < index - 1 && time - sourceTimes[from] > 0.2) from++;
          video.playbackRate = Math.max(0.125, Math.min(1, (time - sourceTimes[from]) / 1.5));
          if (index === 0) {
            ready = true; seekedAt = performance.now(); play();
          } else {
            const gap = sourceTimes[from + 1] - sourceTimes[from];
            video.currentTime = sourceTimes[from] + Math.min(0.005, gap / 4);
          }
        };
        const settled = () => {
          if (done || video.seeking || video.readyState < 2) return;
          if (directSeek) {
            directSeek = false;
            let frame;
            try {
              video.pause();
              frame = new VideoFrame(video);
              const actual = frame.timestamp / 1e6;
              if (Number.isFinite(actual) && Math.abs(actual - time) <= 0.000001) {
                finish(null, actual);
                return;
              }
            } catch {
              // Unsupported decoded-picture access retains actual callback verification.
            } finally {
              frame?.close();
            }
            preroll();
            return;
          }
          ready = true;
          seekedAt = performance.now();
          play();
        };
        const loaded = () => {
          if (done) return;
          clearTimeout(timer);
          timer = setTimeout(() => finish(new Error(\`No presented source frame at \${time}.\`)), 4000);
          if (typeof VideoFrame === "function") {
            directSeek = true;
            const gap = sourceTimes[index + 1] - time || time - sourceTimes[index - 1] || 0.01;
            video.currentTime = time + Math.min(0.001, gap / 8);
          } else preroll();
        };
`+body.slice(end);
body=body.replace('Fresh independent source decoders, actual presentation timestamps, identical extraction canvas and JPEG encoder; every training JPEG matched, held-out JPEGs disjoint.','Diagnostic independent source decoders, exact actual decoded-frame timestamps or actual presentation callbacks, unchanged canvas/JPEG encoder; every training JPEG matched and held-out JPEGs disjoint. Original native outcomes are unchanged.');
fs.writeFileSync('/workspace/work/v3d-r5/decoder-verification/hybrid-source-helper.mjs','// MIT. Future verifier prototype only; the running native evaluator is unchanged.\nexport '+body+'\nexport {assertPixelDisjointness} from "/workspace/splashery/tools/v3d-bench-pixels.mjs";\n');
