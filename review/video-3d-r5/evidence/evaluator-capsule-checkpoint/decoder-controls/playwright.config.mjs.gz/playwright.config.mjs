import {defineConfig} from "/workspace/splashery/node_modules/@playwright/test/index.mjs";
import {benchmarkLaunchArgs} from "/workspace/splashery/tools/v3d-bench.mjs";
export default defineConfig({testDir:"/workspace/work/v3d-r5/decoder-verification",testMatch:/.*\.spec\.mjs$/,workers:1,retries:0,timeout:30000,reporter:[["list"]],use:{baseURL:"http://127.0.0.1:4180",launchOptions:{executablePath:"/usr/bin/chromium",args:benchmarkLaunchArgs("swiftshader")}}});
