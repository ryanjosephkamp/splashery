// MIT. Diagnostic only: no native status, score, timing, or evaluator file is rewritten.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {sourceFrameReceipts,assertPixelDisjointness} from '/workspace/splashery/tools/v3d-bench-pixels.mjs';
import {selectHeldoutTimes} from '/workspace/splashery/tools/v3d-bench-metrics.mjs';
import {benchmarkProtocolFingerprint,benchmarkLaunchArgs} from '/workspace/splashery/tools/v3d-bench.mjs';
import {panoSafeCrop} from '/workspace/splashery/src/video3d/frames.js';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const root='/workspace/work/v3d-r5',folder=root+'/final-run/runs/decoded-picture-unpaired-candidate/desktop/01-cat-track';
const runBytes=fs.readFileSync(folder+'/run.json'),modelBytes=fs.readFileSync(folder+'/cat-track-desktop/model.json');
const run=JSON.parse(runBytes),model=JSON.parse(modelBytes),file=root+'/corpus/cat-track.mp4';
const meta=JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate:frame=best_effort_timestamp_time','-of','json',file],{encoding:'utf8'}));
const sourceTimes=meta.frames.map(f=>Number(f.best_effort_timestamp_time));const [n,d]=meta.streams[0].r_frame_rate.split('/').map(Number);
const times=selectHeldoutTimes({cameras:model.cams,sourceTimes,attemptedTimes:model.observed.attemptedTimes,trainingTimes:model.observed.trainingTimes,fps:n/d});
const source=sourceFrameReceipts.toString(),helper=sourceFrameReceipts;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});
try {
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const proof=await page.evaluate(helper,{base64:fs.readFileSync(file).toString('base64'),sourceTimes,times,trainingFrames:model.observed.trainingFrames,crop:panoSafeCrop(meta.streams[0].width,meta.streams[0].height)});
 assertPixelDisjointness(model.observed.trainingFrames,proof,times);
 const result={at:new Date().toISOString(),notice:'Separate diagnostic on a retained post-bake verifier failure. Actual decoded-picture timestamps are checked first, with the original actual-callback fallback and deadlines retained in the separately versioned protocol-6 verifier; the active native cohort remains frozen on protocol 5. All JPEG bytes, independent source identities, held-out counts, and disjointness checks remain. The original native harness-error, scores, timings, source, and protocol are not promoted or rewritten.',originalStatus:run.results[0].status,originalRunSha256:hash(runBytes),modelMetadataSha256:hash(modelBytes),helperSha256:hash(source),protocol:benchmarkProtocolFingerprint(),times,matchedTraining:proof.matchedTraining.length,proof};
 fs.writeFileSync(root+'/session/desktop-protocol6-source-proof.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({originalStatus:result.originalStatus,matchedTraining:result.matchedTraining,heldouts:proof.views.length,failedTimeVerified:proof.views.some(v=>Math.abs(v.time-.666667)<1e-6),allExactJpegsAndDisjointness:true}));
}finally{await browser.close();}
