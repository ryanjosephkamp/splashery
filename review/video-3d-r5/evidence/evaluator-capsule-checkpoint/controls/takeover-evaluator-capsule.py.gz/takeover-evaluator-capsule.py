# MIT. Work-directory orchestration only; native commands are adopted unchanged.
import os,signal,json,hashlib,subprocess,datetime,time
from pathlib import Path
ROOT=Path('/workspace/work/v3d-r5/final-run');OLD=ROOT/'session-decoded-picture';NEW=ROOT/'session-isolated-media';REPO=Path('/workspace/work/v3d-r5/evaluator-protocol5')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def processes():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:f=(p/'stat').read_text().rsplit(')',1)[1].split();result[int(p.name)]={'ppid':int(f[1]),'startTicks':f[19],'status':f[0]}
  except (OSError,IndexError,ValueError):pass
 return result
def descendants(root,table):
 owned={root}
 while True:
  extra={pid for pid,item in table.items() if item['ppid'] in owned}
  if extra<=owned:return owned
  owned|=extra
controller=json.loads((OLD/'controller-pid.json').read_text());oldpid=controller['pid'];stopped=False;terminated=False
try:
 for attempt in range(8):
  table=processes();assert table.get(oldpid,{}).get('startTicks')==controller['startTicks'],'Old controller identity changed'
  os.kill(oldpid,signal.SIGSTOP);stopped=True
  statebytes=(OLD/'collection-state.json').read_bytes();state=json.loads(statebytes);table=processes();active=state['active'];native_pids={v['pid'] for v in active.values()}
  unexpected=[pid for pid,item in table.items() if item['ppid']==oldpid and item['status']!='Z' and pid not in native_pids]
  terminal=[tag for tag,item in active.items() if table.get(item['pid'],{}).get('startTicks')!=item['startTicks'] or table[item['pid']]['status']=='Z']
  if unexpected or terminal:
   os.kill(oldpid,signal.SIGCONT);stopped=False;time.sleep(.3);continue
  break
 else:raise RuntimeError('Could not reach an orchestration boundary without an untracked launch or join')
 adopted={}
 for tag,item in active.items():
  pid=item['pid'];args=item['argv'];assert 'tools/v3d-bench.mjs' in args and 'run' in args
  output=Path(args[9]);native=json.loads((output/'run.json').read_text())
  assert native['provenance']['protocolSha256']=='154576a01c7a624fb63dfb034cd7bb5d94407691472c56554584f54ca34c69e9'
  owned=descendants(pid,table)
  adopted[tag]={**item,'owned':{str(p):table[p]['startTicks'] for p in owned if p in table},'originalRunSha256AtTakeover':hashlib.sha256((output/'run.json').read_bytes()).hexdigest(),'originalOutput':str(output),'originalCommandCwd':'/workspace/splashery'}
 (NEW/'prior-controller-state.json').write_bytes(statebytes)
 (NEW/'prior-controller.py').write_bytes((OLD/'collect.py').read_bytes())
 receipt={'at':now(),'oldController':controller,'oldControllerSha256':hashlib.sha256((OLD/'collect.py').read_bytes()).hexdigest(),'newControllerSha256':hashlib.sha256((NEW/'collect.py').read_bytes()).hexdigest(),'adopted':adopted,'nativeUploadsInterrupted':False,'notice':'Only orchestration is replaced. Every active native command already initialized unchanged protocol 5 and retains its original process, source, output, timeout, reference, and CPU mask. Future commands use byte-identical frozen evaluator files in the capsule. No completed result is rerun.'}
 (NEW/'takeover.json').write_text(json.dumps(receipt,indent=2)+'\n')
 freeze=json.loads((OLD/'freeze.json').read_text());freeze.update(controllerSha256=receipt['newControllerSha256'],previousControllerSha256=receipt['oldControllerSha256'],evaluatorRoot=str(REPO),orchestrationContinuedAt=now(),notice='Same native corpus and frozen runtime 81b6524b on unchanged protocol 5. Only the work controller and evaluator location change. All evaluator file hashes and served-source fingerprints match. Active native processes are adopted unchanged. Media rendering waits for every timed native command to finish.')
 (NEW/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');(NEW/'launch-env.json').write_bytes((OLD/'launch-env.json').read_bytes())
 env=dict(os.environ,**json.loads((NEW/'launch-env.json').read_text()))
 validation=subprocess.run(['python3',str(NEW/'collect.py'),'--validate-only'],cwd=REPO,env=env,text=True,capture_output=True)
 (NEW/'validation.log').write_text(validation.stdout+validation.stderr);assert validation.returncode==0,validation.stderr
 print(validation.stdout,flush=True)
 # SIGKILL only the stopped orchestration parent; independent native sessions keep running.
 assert processes().get(oldpid,{}).get('startTicks')==controller['startTicks'];os.kill(oldpid,signal.SIGKILL);terminated=True
 receipt['oldControllerStoppedAt']=now();(NEW/'takeover.json').write_text(json.dumps(receipt,indent=2)+'\n')
 with (NEW/'collection.log').open('w') as log:p=subprocess.Popen(['python3',str(NEW/'collect.py')],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
 tick=Path(f'/proc/{p.pid}/stat').read_text().rsplit(')',1)[1].split()[19];(NEW/'controller-pid.json').write_text(json.dumps({'pid':p.pid,'startTicks':tick,'at':now()},indent=2)+'\n')
 print(json.dumps({'controllerPid':p.pid,'adopted':list(adopted),'nativeUploadsInterrupted':False,'deadlineUTC':'2026-10-16T13:29:00Z'}),flush=True)
 print('Collector exit:',p.wait(),flush=True)
except BaseException:
 if stopped and not terminated:
  try:os.kill(oldpid,signal.SIGCONT)
  except ProcessLookupError:pass
 raise
