from pathlib import Path
import datetime,gzip,hashlib,json,shutil,sys
root=Path('/workspace/work/v3d-r5');repo=Path('/workspace/splashery');name=sys.argv[1]
assert name.startswith('cpu-native-') and all(c.isalnum() or c=='-' for c in name)
dest=root/'clips/review/video-3d-r5/evidence'/name;assert not dest.exists();dest.mkdir(parents=True)
corpus=json.loads((repo/'tools/v3d-corpus.json').read_text());items=[];rows=[]
def copy(source,relative,credit=None):
 raw=source.read_bytes();target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True)
 if source.suffix in ['.json','.mjs','.js','.py','.log','.txt','.md','.jsonl']:
  target=Path(str(target)+'.gz')
  with target.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(raw)
 else:shutil.copyfile(source,target)
 item={'source':str(source.relative_to(root)) if source.is_relative_to(root) else str(source),'file':str(target.relative_to(dest)),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'storedSha256':hashlib.sha256(target.read_bytes()).hexdigest()}
 if credit:item['credit']=credit
 items.append(item)
for group in ['main','cpu-matcher-strict-candidate','cpu-matcher-unpaired-candidate']:
 base=root/'final-run/runs'/group
 for runfile in sorted(base.glob('*/*/run.json')):
  raw=runfile.read_bytes();run=json.loads(raw)
  if not run.get('results'):continue
  assert len(run['results'])==1;row=run['results'][0]
  assert run['provenance']['servedSource']['sha256']==('99cea09dd4f5367f78cfe4d1b5bed97cb87432c38222e6c81edf873be25da9fa' if group=='main' else 'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571')
  assert run['provenance']['protocolSha256']=='154576a01c7a624fb63dfb034cd7bb5d94407691472c56554584f54ca34c69e9'
  clip=next(c for c in corpus if c['id']==row['id']);assert clip['sha256']==row['sha256']
  rows.append({'group':group,'id':row['id'],'profile':row['profile'],'status':row['status'],'phase':row.get('phase'),'runSha256':hashlib.sha256(raw).hexdigest(),'run':str(Path('native')/group/runfile.relative_to(base))+'.gz'})
  for source in sorted(runfile.parent.rglob('*')):
   if source.is_file() and 'attempts' not in source.relative_to(runfile.parent).parts:copy(source,Path('native')/group/source.relative_to(base),credit=clip)
for name in ['cpu-ci-attempt1-summary.json','cpu-ci-normal-shard-retry-plan.json','ci-cpu-shard3-actual.log','ci-cpu-shard16-actual.log','ci-cpu-shard13-actual.log','ci-cpu-shard15-actual.log','ci-cpu-summary-attempt1-actual.log','cpu-clips-fetch-affinity-correction.json','cpu-evidence-publication.json','export-cpu-native-progress.py']:
 copy(root/'session'/name,Path('controls')/name)
for name in ['collection-state.json','collection-events.jsonl','collection.log','native-ledger.json','native-ledger.md','freeze.json','collect.py','cpu-lanes.json','validated-samples.json']:
 copy(root/'final-run/session-cpu-matcher'/name,Path('collection')/name)

# Publish only explicit numeric/text controls; private calibration media and reports are excluded.
extra_controls=['cpu-ci-attempt4-summary.json','ci-cpu-attempt4-summary-actual.log','ci-main-baseline-summary-actual.log','ci-main-current-summary-actual.log','main-ci-runs-0920.json','cpu-strict-progress-0906-comparison.json','cpu-strict-progress-0906-join.log','cpu-strict-progress-0906-compare.log','verify-palace-native-source-only.mjs','palace-native-source-only-proof.json','palace-native-source-only-proof.log','verify-fresnel-native-source.mjs','fresnel-native-source-proof.json','fresnel-native-source-proof.log','cpu-ci-attempt2-summary.json','cpu-ci-attempt3-summary.json','ci-cpu-attempt2-shard3-actual.log','ci-cpu-attempt2-shard15-actual.log','ci-cpu-attempt2-summary-actual.log','ci-cpu-attempt3-shard15-actual.log','ci-cpu-attempt3-summary-actual.log','cpu-ci-0750-jobs.json','cpu-ci-0806-jobs.json','cpu-ci-0825-jobs.json','cpu-ci-0837-jobs.json','native-dianthus-existing-proof-binding.json','native-dianthus-existing-proof-binding.log','bind-native-dianthus-proof.mjs','private-calibration-recovery.json','private-calibration-recovery.log','recover-private-calibration.py','run-private-calibration-when-idle.py','private-calibration-worker.log','cache-real-sift-descriptors.mjs','benchmark-cpu-loop-variants.mjs','benchmark-cpu-loop-guards.mjs','cpu-loop-source-cache.log','cpu-loop-research.log','cpu-loop-guards.log']
for name in extra_controls:
 source=root/'session'/name
 if source.is_file():copy(source,Path('additional-controls')/name)
for source in sorted((root/'session/private-calibration-check').glob('*.json*')):
 if source.is_file():copy(source,Path('private-calibration-numeric-proof')/source.name)
for source in sorted((root/'session/publisher-idle-core-control').glob('*.jsonl')):
 if source.is_file():copy(source,Path('metadata-admission-controls')/source.name)
for source in sorted((root/'session/cpu-loop-research').iterdir()):
 if source.is_file():
  credit=next(c for c in corpus if c['id']=='dianthus') if source.suffix in ['.bin','.json'] else None
  copy(source,Path('unshipped-loop-research')/source.name,credit=credit)
for name in ['palace-heldout-source-times.json','palace-heldout-group-diagnostic.json']:
 source=root/'session'/name
 if source.is_file():copy(source,Path('unchanged-heldout-constraint')/name,credit=next(c for c in corpus if c['id']=='palace-statue'))

inv={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac','runtimeSha256':'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571','notice':'Partial immutable native progress. Every original failure and exact frozen reference is retained; no corpus acceptance is established. The ledger and controller snapshots carry their own capture times. All original fixed-sample evidence remains at the linked preceding immutable checkpoint.','completeSampleCheckpoint':'https://github.com/ryanjosephkamp/splashery/tree/ae793c050c42fbfb7d22a8eacfff51652a48d8aa/review/video-3d-r5/evidence/cpu-matcher-checkpoint','nativeCases':rows,'files':items}
(dest/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
(dest/'README.md').write_text('''# Current CPU native progress

This is partial native evidence from frozen source f1f7f339, against the original main
baseline 5a55f5cc, with unchanged protocol-5 evaluator 0406a781. The inventory lists every
original outcome, runtime fingerprint, and exact input hash. Explained cases retain their
visible reason and advice. Host timeouts remain failures. No missing result is favorable.
The ledger and collection snapshots state their own exact capture times.

The current chameleon phone result has SSIM 0.720044 against main 0.622167, with sharper
petals and branches in the saved views. Large background blobs remain. First view is
28.889 against 37.673 seconds, and bake is 516.196 against 547.301 seconds. Independent
JPEG verification and every original held-out assertion pass. Motion review is pending.
These individual views and partial medians do not establish a corpus pass.

[The preceding complete sample checkpoint](https://github.com/ryanjosephkamp/splashery/tree/ae793c050c42fbfb7d22a8eacfff51652a48d8aa/review/video-3d-r5/evidence/cpu-matcher-checkpoint)
contains all 148 original PNGs and all 74 exact, nonblank main/candidate pixel comparisons
across both profiles, with the six samples' complete source and license records.

The hosted integration first attempt merged this branch with newer main cc297c89 as
8753fec8. It ran all 362 specs and 3,060 tests: 3,054 passed, five failed, and one existing
skip. All five failed checks passed alone, but all five full-run failures still count.
The repository's normal four failed shards are being retried without code or test changes.
No threshold, assertion, timeout, test, or existing skip is reduced or waived.

A publishing fetch initially lacked its metadata CPU mask at approximately 07:28 UTC.
At 07:30:31 UTC all its existing threads were pinned to core 3, after 1.88 observed CPU
seconds. The original dianthus-phone result is retained with potential interference
reported. A separate clean phone timing pair was already predeclared. Software profiles
do not establish physical-phone performance.

Every picture and model carries its complete source author, page, license, checksum, and
transformation record in the inventory. Derived data retain the recorded source license.
Code is MIT, made by Ryan with Codex (GPT-6). Never merge this evidence branch.
All gzip files preserve the original bytes. PNG and PLY bytes are unchanged. Original
and stored SHA-256 hashes are verified for every file.
''')
for item in items:
 data=(dest/item['file']).read_bytes();original=gzip.decompress(data) if item['file'].endswith('.gz') else data
 assert hashlib.sha256(data).hexdigest()==item['storedSha256'] and hashlib.sha256(original).hexdigest()==item['originalSha256']
print(json.dumps({'folder':str(dest),'files':len(items),'nativeCases':len(rows),'candidateCases':sum(r['group']!='main' for r in rows),'allOriginalAndStoredHashesVerified':True}))

with (dest/'README.md').open('a') as f:
 f.write("\nThe formerly conditional private calibration case was executed with the exact original\nCommons files and every original assertion: all 12 calibration cases passed, zero skipped,\nand zero retries, in 36.85 seconds. Only scalar results and public source/license/checksum\nrecords appear here. Private media, screenshots, traces, and the detailed private report\nremain outside the repository and public evidence.\n\nLater CI retries retain the complete normal shard coverage at the same f1f7f339 source.\nThe latest retained total is 3,057 passed, two failed, and one preexisting conditional skip.\nNew job IDs can refer to reused results; the actual start and completion timestamps are\npreserved. Both original remaining failures still count. No isolated pass substitutes for\na normal shard.\n\nThe later desktop palace bake also finished, but its fourth original camera-time group\nhas no independent frame under the unchanged full-source-frame exclusion distance.\nTwelve eligible frames exist globally; borrowing another group's view is forbidden by an\nexisting assertion, so no alternate selection policy is used and the original failure\nremains. The timestamp-only alternative is a diagnostic, with no new score or promotion.\n\nCPU loop variants are unshipped research. All descriptor parity and real timer checks\npass, with mixed performance across variants. Their complete real-source descriptor\ncredits, timing limits, and original module hashes are preserved separately. They do not\nchange the frozen native candidate or establish a native phone-speed improvement.\n")
