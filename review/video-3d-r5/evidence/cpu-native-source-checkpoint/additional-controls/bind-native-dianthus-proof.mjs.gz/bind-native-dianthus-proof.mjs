// MIT. Bind an existing independent source proof to exactly equal native receipts.
// This does not re-decode, render, rescore, retry, promote, or rewrite a native outcome.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {selectHeldoutTimes} from '/workspace/work/v3d-r5/evaluator-protocol5/tools/v3d-bench-metrics.mjs';
import {sourceFrameReceipts} from '/workspace/work/v3d-r5/evaluator-protocol6/tools/v3d-bench-pixels.mjs';
const root='/workspace/work/v3d-r5',dir=root+'/final-run/runs/cpu-matcher-unpaired-candidate/desktop/05-dianthus';
const hash=b=>createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p));
const runBytes=fs.readFileSync(dir+'/run.json'),modelBytes=fs.readFileSync(dir+'/dianthus-desktop/model.json');
const run=JSON.parse(runBytes),model=JSON.parse(modelBytes),row=run.results[0];
const controlBytes=fs.readFileSync(root+'/session/camera-production-cpu-control.json'),control=JSON.parse(controlBytes);
const proofBytes=fs.readFileSync(root+'/session/camera-production-cpu-source-proof.json'),proof=JSON.parse(proofBytes);
assert.equal(row.status,'harness-error');assert.equal(row.phase,'evaluation');
assert.equal(run.provenance.servedSource.sha256,'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571');
assert.equal(proof.originalRunSha256,hash(controlBytes));assert.equal(proof.modelMetadataSha256,hash(controlBytes));
assert.equal(proof.helperSha256,hash(sourceFrameReceipts.toString()));
assert.deepEqual(model.observed.trainingFrames,control.frames);
assert.deepEqual(model.observed.attemptedTimes,control.attemptedTimes);
assert.deepEqual(model.observed.trainingTimes,control.frames.map(f=>f.time));
assert.equal(model.cams.length,17);assert.equal(control.cameras.length,17);
for(let i=0;i<17;i++){
 const c=control.cameras[i],f=control.frames[c.imgIdx];
 assert.deepEqual(model.cams[i],{time:f.time,R:c.R,t:c.t,f:c.f,w:f.width,h:f.height});
 assert.equal(proof.proof.matchedTraining[i].sha256,f.sha256);
 assert.equal(proof.proof.matchedTraining[i].repeatedSha256,f.sha256);
}
const file=root+'/corpus/dianthus.mp4';assert.equal(hash(fs.readFileSync(file)),row.sha256);
const meta=JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=r_frame_rate:frame=best_effort_timestamp_time','-of','json',file],{encoding:'utf8'}));
const sourceTimes=meta.frames.map(f=>Number(f.best_effort_timestamp_time)),[n,d]=meta.streams[0].r_frame_rate.split('/').map(Number);
const times=selectHeldoutTimes({cameras:model.cams,sourceTimes,attemptedTimes:model.observed.attemptedTimes,trainingTimes:model.observed.trainingTimes,fps:n/d});
assert.deepEqual(times,proof.times);assert.equal(times.length,4);assert.equal(proof.proof.views.length,4);
assert(times.includes(0.708008));assert(proof.proof.views.every((v,i)=>v.time===times[i]));
assert.equal(hash(fs.readFileSync(dir+'/run.json')),hash(runBytes));assert.equal(hash(fs.readFileSync(dir+'/dianthus-desktop/model.json')),hash(modelBytes));
const result={at:new Date().toISOString(),notice:'Pure receipt binding, with no new browser or re-decoding. Every actual native input receipt, JPEG hash, attempted time, training time, and all 17 camera parameters exactly equal the earlier camera-only control, whose independent protocol-6 source proof already matched all 17 JPEGs and all four disjoint held-outs, including 0.708008. This binds that existing independent source proof to the retained native model. The original native protocol-5 harness error, missing quality scores, and timing remain unchanged. This is neither a new native protocol-6 upload nor corpus acceptance.',originalNativeStatus:row.status,originalNativeRunSha256:hash(runBytes),nativeModelMetadataSha256:hash(modelBytes),controlSha256:hash(controlBytes),independentSourceProofSha256:hash(proofBytes),all17TrainingReceiptsExactlyEqual:true,all17CameraParametersExactlyEqual:true,independentlyMatchedTrainingJpegs:17,eligibleHeldoutViews:4,heldoutTimes:times,originalNativeOutcomeUnchanged:true};
fs.writeFileSync(root+'/session/native-dianthus-existing-proof-binding.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
