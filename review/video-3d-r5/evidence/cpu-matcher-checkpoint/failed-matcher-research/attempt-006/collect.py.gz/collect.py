# MIT. Separate fresh native protocol-6 control; no original result is rewritten.
import datetime,hashlib,json,os,signal,subprocess,threading,time
from pathlib import Path
REPO=Path('/workspace/work/v3d-r5/evaluator-protocol6')
ROOT=Path('/workspace/work/v3d-r5/final-run')
SESSION=ROOT/'session-matcher-research'
PRIMARY=ROOT/'session-isolated-media'
DEADLINE=datetime.datetime(2026,10,16,13,29,tzinfo=datetime.timezone.utc).timestamp()
lock=threading.RLock();ADOPTED={};MEDIA_REQUESTED=threading.Event();MEDIA_FINISHED=threading.Event();MEDIA_FINISHED.set()
state={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'active':{},'events':[]}
def record(event,**data):
 with lock:
  item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**data};state['events'].append(item)
  tmp=SESSION/'control-state.json.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');os.replace(tmp,SESSION/'control-state.json')
  with (SESSION/'control-events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
  print(json.dumps(item),flush=True)

def processes():
 result={}
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   fields=(path/'stat').read_text().rsplit(')',1)[1].split()
   result[int(path.name)]={'ppid':int(fields[1]),'startTicks':fields[19],'status':fields[0]}
  except (OSError,IndexError,ValueError):pass
 return result

def descendants(root,table):
 owned={root};changed=True
 while changed:
  changed=False
  for pid,item in table.items():
   if item['ppid'] in owned and pid not in owned:owned.add(pid);changed=True
 return owned

def command(args,log,cores,tag):
 if time.time()>=DEADLINE:raise TimeoutError('Goal deadline reached before launch')
 current=hashlib.sha256((REPO/'tools/v3d-affinity.py').read_bytes()).hexdigest()
 if current!=os.environ['V3D_AFFINITY_SHA256']:raise RuntimeError('Affinity launcher changed after freeze')
 argv=['python3','tools/v3d-affinity.py',','.join(map(str,cores)),'--',*map(str,args)]
 env=dict(os.environ,SPLASHERY_CHROMIUM='/usr/bin/chromium',OMP_NUM_THREADS=str(len(cores)))
 adopted=ADOPTED.pop(tag,None)
 observed={int(pid):ticks for pid,ticks in adopted.get('owned',{}).items()} if adopted else {}
 violations=[];last_audit=time.time();p=None;exit_code=None
 def observe(audit=False):
  table=processes()
  for pid in descendants(root_pid,table):
   if pid in table:observed[pid]=table[pid]['startTicks']
  if audit:
   for pid,start in list(observed.items()):
    if table.get(pid,{}).get('startTicks')!=start:continue
    try:
     for tid in (Path('/proc')/str(pid)/'task').iterdir():
      try:
       allowed=os.sched_getaffinity(int(tid.name))
       if not allowed<=set(cores):violations.append({'pid':pid,'tid':int(tid.name),'allowed':sorted(allowed)})
      except (ProcessLookupError,FileNotFoundError):pass
    except FileNotFoundError:pass
  return table
 def live_owned():
  table=processes()
  return [pid for pid,start in observed.items() if table.get(pid,{}).get('startTicks')==start and table[pid]['status']!='Z']
 def stop_owned(reason):
  remaining=live_owned();record(reason,tag=tag,pids=remaining)
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   for pid in remaining:
    try:os.kill(pid,sig)
    except ProcessLookupError:pass
   end=time.time()+2
   while time.time()<end and live_owned():time.sleep(.1)
   remaining=live_owned()
   if not remaining:break
  if remaining:record('owned-processes-still-live',tag=tag,pids=remaining)
 if adopted:
  if adopted['cores']!=cores or str(args[5]) not in adopted['argv']:raise RuntimeError('Adopted command identity differs: '+tag)
  root_pid=adopted['pid'];root_ticks=adopted['startTicks'];log=adopted['log'];observed[root_pid]=root_ticks
  record('adopt-native-command',tag=tag,pid=root_pid,startTicks=root_ticks,log=log,cores=cores,notice='Original native command, output, source, timeout, and CPU mask remain unchanged.')
 else:
  while True:
   if time.time()>=DEADLINE:raise TimeoutError('Goal deadline before native launch')
   with lock:
    blocked=('-desktop-' in tag and MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set())
    if not blocked:
     with Path(log).open('w') as stream:p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
     root_pid=p.pid;root_ticks=processes().get(root_pid,{}).get('startTicks')
     state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':argv,'log':str(log),'cores':cores,'adopted':False}
     break
   MEDIA_FINISHED.wait(.25)
  record('launch',tag=tag,pid=root_pid,log=str(log),cores=cores,affinitySha256=current)
 with lock:state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':adopted['argv'] if adopted else argv,'log':str(log),'cores':cores,'adopted':bool(adopted)}
 record('active-native-command',tag=tag,pid=root_pid)
 while True:
  if p:
   if p.poll() is not None:exit_code=p.returncode;break
  else:
   table=processes();item=table.get(root_pid)
   if not item or item['startTicks']!=root_ticks or item['status']=='Z':
    if adopted.get('receipt'):
     try:exit_code=json.loads(Path(adopted['receipt']).read_text()).get('exitCode')
     except (OSError,ValueError):pass
    break
  now=time.time();observe(audit=now-last_audit>=5)
  if now-last_audit>=5:last_audit=now
  try:primary=json.loads((PRIMARY/'collection-state.json').read_text())
  except (OSError,ValueError):primary={}
  if any(tag.startswith('candidate-desktop-') for tag in primary.get('active',{})):
   stop_owned('research-yield-to-native');exit_code=p.wait(timeout=10) if p else None;break
  if now>=DEADLINE:
   stop_owned('deadline-interruption')
   if p:exit_code=p.wait(timeout=10)
   break
  time.sleep(.5)
 if live_owned():stop_owned('post-terminal-browser-cleanup')
 with lock:state['active'].pop(tag,None)
 record('exit',tag=tag,pid=root_pid,code=exit_code,exitCodeKnown=exit_code is not None,adopted=bool(adopted),affinityViolations=violations,observedProcesses=len(observed))
 if violations:raise RuntimeError('CPU placement escaped: '+str(violations))
 return exit_code


DEADLINE=min(DEADLINE,time.time()+195)
os.environ['V3D_AFFINITY_SHA256']='2bd8feb692dd8be039f43837f59d8d257f9902a53a79b8e5441186bdcb3fbd50'
primary=json.loads((PRIMARY/'collection-state.json').read_text())
if any(tag.startswith('candidate-desktop-') for tag in primary.get('active',{})):raise RuntimeError('Native candidate desktop core is busy')
(SESSION/'primary-state-at-admission.json').write_text(json.dumps(primary,indent=2)+'\n')
record('work-only-research-admitted',notice='Native candidate desktop core is idle; kernel-affinity-locked to that core only, with a 195-second owned-process deadline and an immediate yield if native work resumes.')
code=command(['node','/workspace/work/v3d-r5/session/matcher-ffprobe-source-early-exit-experiment.mjs'],SESSION/'experiment.log',[3],'work-only-matcher-experiment')
record('work-only-research-terminal',exitCode=code)
