// MIT. Work-only matcher experiment. No product, native row, threshold, or budget is edited.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {benchmarkLaunchArgs,withHostDeadline,closeBrowserBounded} from '/workspace/work/v3d-r5/evaluator-protocol6/tools/v3d-bench.mjs';
const root='/workspace/work/v3d-r5',sourceFile=root+'/evaluator-protocol5/vendor/splatjs/src/sfm/gpumatch.js';
const original=fs.readFileSync(sourceFile,'utf8');
const needle='          s = s + u32(d0 * d0 + d1 * d1 + d2 * d2 + d3 * d3);';
if(original.split(needle).length!==2)throw Error('Expected one exact squared-distance accumulation');
const early=original.replace(needle,needle+'\n          if (s >= second) { break; }');
const hash=b=>createHash('sha256').update(b).digest('hex');
fs.writeFileSync(root+'/session/matcher-early-exit-module.mjs',early);
const server=await chromium.launchServer({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});
const browser=await chromium.connect(server.wsEndpoint());
try{
 const page=await browser.newPage();
 page.on('console',m=>{if(m.type()==='log')console.log(m.text());});
 await page.route('**/__r5-match-original.mjs',r=>r.fulfill({contentType:'text/javascript',body:original}));
 await page.route('**/__r5-match-early.mjs',r=>r.fulfill({contentType:'text/javascript',body:early}));
 await page.route('**/__r5-matcher-input.mp4',r=>r.fulfill({contentType:'video/mp4',path:root+'/corpus/dianthus.mp4'}));
 await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const result=await withHostDeadline(()=>page.evaluate(async()=>{
  const [{gpuMatchAll:baseline},{gpuMatchAll:candidate},{detectSift,matchSift}]=await Promise.all([import('/__r5-match-original.mjs'),import('/__r5-match-early.mjs'),import('/vendor/splatjs/src/sfm/sift.js')]);
  const adapter=await navigator.gpu.requestAdapter({powerPreference:'high-performance'});if(!adapter)throw Error('No actual WebGPU adapter');
  const device=await adapter.requestDevice();const receipt={adapter:{vendor:adapter.info.vendor,architecture:adapter.info.architecture,device:adapter.info.device,description:adapter.info.description},notice:'Actual corpus video decoding and SIFT descriptors, then exact CPU/original-GPU/experimental-GPU comparisons. No native upload, training, quality score, or phone-speed acceptance.',cases:[]};
  const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
  const equal=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
  async function compare(label,feats,metadata){
   const cpuStart=performance.now(),expected=matchSift(feats[0].desc,feats[0].n,feats[1].desc,feats[1].n),cpuMs=performance.now()-cpuStart;
   const row={label,...metadata,features:feats.map(f=>f.n),descriptorHashes:await Promise.all(feats.map(f=>sha(f.desc))),matchCount:expected.length/2,expectedSha256:await sha(Int32Array.from(expected).buffer),cpuMs,trials:[]};
   // Compile and warm both separate modules before timing; every warm-up must also match.
   for(const fn of [baseline,candidate])if(!equal((await fn(feats,[[0,1]],.8,()=>{},device,null,{maxPairsPerChunk:4}))[0],expected))throw Error('Warm-up mismatch: '+label);
   for(let rep=0;rep<3;rep++)for(const [name,fn] of (rep%2?[['candidate',candidate],['baseline',baseline]]:[['baseline',baseline],['candidate',candidate]])){
    const t=performance.now(),actual=(await fn(feats,[[0,1]],.8,()=>{},device,null,{maxPairsPerChunk:4}))[0];
    const ms=performance.now()-t;if(!equal(actual,expected))throw Error('Exact match output differs: '+label+'/'+name);
    row.trials.push({rep,name,ms,sha256:await sha(Int32Array.from(actual).buffer)});
   }
   receipt.cases.push(row);console.log(JSON.stringify({label,features:row.features,matches:row.matchCount,cpuMs,trials:row.trials.map(({name,ms})=>({name,ms}))}));
  }
  try{
   let seed=0x61c0d3;const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed>>>24;};
   for(const [nA,nB,ties] of [[1,1,false],[63,65,false],[65,129,false],[65,65,true]]){
    const a=Uint8Array.from({length:nA*128},next),b=Uint8Array.from({length:nB*128},next);
    if(ties){a.fill(12);b.fill(12);}else for(let i=0;i<Math.min(nA,nB);i++)if(i%4===0)b.set(a.subarray(i*128,i*128+128),i*128);
    await compare('synthetic-'+nA+'-'+nB+(ties?'-ties':''),[{n:nA,desc:a},{n:nB,desc:b}],{mock:true});
   }
   for(const [side,maxFeats,firstOctave] of [[480,3000,0],[960,8192,-1]]){
    const video=document.createElement('video');video.muted=true;video.preload='auto';
    await new Promise((resolve,reject)=>{video.onloadedmetadata=resolve;video.onerror=reject;video.src='/__r5-matcher-input.mp4';});
    const feats=[],frames=[];
    try{for(const requestedTime of [.5,2]){
     await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('Source seek timeout')),4000);video.onseeked=()=>{clearTimeout(t);resolve();};video.currentTime=requestedTime+.001;});
     const handle=new VideoFrame(video);const actualTime=handle.timestamp/1e6;handle.close();if(!Number.isFinite(actualTime))throw Error('Source timestamp unavailable');
     const scale=Math.min(1,side/Math.max(video.videoWidth,video.videoHeight)),w=Math.round(video.videoWidth*scale),h=Math.round(video.videoHeight*scale);
     const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(video,0,0,w,h);
     const rgba=ctx.getImageData(0,0,w,h).data,gray=Float32Array.from({length:w*h},(_,i)=>(.299*rgba[i*4]+.587*rgba[i*4+1]+.114*rgba[i*4+2])/255);
     const t=performance.now(),f=detectSift(gray,w,h,maxFeats,firstOctave);if(!f.n)throw Error('No actual SIFT descriptors');feats.push(f);frames.push({requestedTime,actualTime,w,h,pixelsSha256:await sha(rgba),extractionMs:performance.now()-t});
    }}finally{video.pause();video.removeAttribute('src');video.load();}
    await compare('actual-dianthus-'+side,feats,{mock:false,side,maxFeats,firstOctave,frames});
   }
   return receipt;
  }finally{device.destroy();}
 }),{timeoutMs:180000,label:'Work-only exact matcher comparison',onTimeout:()=>closeBrowserBounded(browser,server)});
 const manifest=JSON.parse(fs.readFileSync(root+'/evaluator-protocol5/tools/v3d-corpus.json'));
 Object.assign(result,{at:new Date().toISOString(),sourceClip:manifest.find(c=>c.id==='dianthus'),originalModuleSha256:hash(original),experimentalModuleSha256:hash(early),allComparisonsExact:true});
 fs.writeFileSync(root+'/session/matcher-early-exit-experiment.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({allComparisonsExact:true,cases:result.cases.length}));
}finally{await closeBrowserBounded(browser,server);}
