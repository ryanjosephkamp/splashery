import time,json,datetime
from pathlib import Path
root=Path('/workspace/work/v3d-r5/final-run/session-cpu-matcher')
deadline=datetime.datetime(2026,10,16,13,29,tzinfo=datetime.timezone.utc).timestamp()
def accounted(r):
 return (r.get('status')=='finished' and not r.get('consoleErrors')) or (r.get('status')=='explained' and r.get('reason','').strip() and r.get('explanation',{}).get('visible') is True and r.get('explanation',{}).get('diagnostic','').strip() and r.get('explanation',{}).get('advice','').strip() and not r.get('consoleErrors'))
while time.time()<deadline:
 try:
  state=json.loads((root/'collection-state.json').read_text());rows=[]
  for path in state.get('strictCandidate',[])+state.get('unpairedCandidate',[]):
   try:rows+=json.loads((Path(path)/'run.json').read_text()).get('results',[])
   except (OSError,ValueError):pass
  active={}
  for tag,item in state.get('active',{}).items():
   try:lines=Path(item['log']).read_text().splitlines();last=lines[-1] if lines else 'starting'
   except OSError:last='starting'
   active[tag]=last[:150]
  result={'at':datetime.datetime.now(datetime.timezone.utc).strftime('%H:%M:%S UTC'),'main':len(state.get('main',[])),'candidate':len(rows),'accounted':sum(bool(accounted(r)) for r in rows),'unaccounted':[r['id']+'/'+r['profile']+':'+r['status'] for r in rows if not accounted(r)],'active':active,'controllerErrors':[e.get('lane','')+':'+e.get('error','') for e in state.get('events',[]) if e['event']=='lane-error'][-2:]}
  print(json.dumps(result),flush=True)
 except (OSError,ValueError) as e:print(json.dumps({'watcherError':str(e)}),flush=True)
 time.sleep(50)
