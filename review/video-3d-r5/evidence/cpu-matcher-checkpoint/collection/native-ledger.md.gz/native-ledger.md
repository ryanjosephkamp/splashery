# Protocol 5 cpu-matcher native per-clip ledger

Protocol 5, cpu-matcher candidate only; current native rows only, with explicitly archived harness attempts kept separately; all superseded candidate rows are excluded. Exact native rows retain their original outcomes and provenance. Independent unpaired outcomes, are indexed but cannot establish comparative gains. Partial medians are diagnostics. Acceptance must come from the unchanged production comparator on complete compatible evidence.

## phone

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | explained | explained | verified | — / — | — / — | — / — |
| cat-plays | finished | finished | verified | 0.311 / 0.324 | 54.1 / 34.9 | 680.0 / 520.0 |
| buddha | explained | explained | verified | — / — | — / — | — / — |
| chameleon-flowers | finished | not recorded | not established | 0.622 / — | 37.7 / — | 547.3 / — |
| dianthus | finished | not recorded | not established | 0.274 / — | 64.5 / — | 573.3 / — |
| pisac | finished | not recorded | not established | 0.563 / — | 45.1 / — | 594.7 / — |
| sleeping-dog | explained | not recorded | not established | — / — | — / — | — / — |
| palace-statue | finished | not recorded | not established | 0.252 / — | 44.9 / — | 671.3 / — |
| oa-street | explained | not recorded | not established | — / — | — / — | — / — |
| ullard | finished | not recorded | not established | 0.460 / — | 52.2 / — | 636.7 / — |
| snaefell | finished | not recorded | not established | 0.641 / — | 59.5 / — | 597.6 / — |
| fremantle-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| ihasalu-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| fresnel-lens | not recorded | not recorded | not established | — / — | — / — | — / — |
| saint-denis | not recorded | not recorded | not established | — / — | — / — | — / — |
| horse-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| royal-sovereign | not recorded | not recorded | not established | — / — | — / — | — / — |
| viljandi-ruins | not recorded | not recorded | not established | — / — | — / — | — / — |
| kakerdi-bog | not recorded | not recorded | not established | — / — | — / — | — / — |
| fjoloy | not recorded | not recorded | not established | — / — | — / — | — / — |

## desktop

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | timeout | explained | not established | — / — | — / — | — / — |
| cat-plays | explained | explained | verified | — / — | — / — | — / — |
| buddha | timeout | explained | not established | — / — | — / — | — / — |
| chameleon-flowers | timeout | not recorded | not established | — / — | — / — | — / — |
| dianthus | timeout | not recorded | not established | — / — | — / — | — / — |
| pisac | timeout | not recorded | not established | — / — | — / — | — / — |
| sleeping-dog | not recorded | not recorded | not established | — / — | — / — | — / — |
| palace-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| oa-street | not recorded | not recorded | not established | — / — | — / — | — / — |
| ullard | not recorded | not recorded | not established | — / — | — / — | — / — |
| snaefell | not recorded | not recorded | not established | — / — | — / — | — / — |
| fremantle-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| ihasalu-orbit | not recorded | not recorded | not established | — / — | — / — | — / — |
| fresnel-lens | not recorded | not recorded | not established | — / — | — / — | — / — |
| saint-denis | not recorded | not recorded | not established | — / — | — / — | — / — |
| horse-statue | not recorded | not recorded | not established | — / — | — / — | — / — |
| royal-sovereign | not recorded | not recorded | not established | — / — | — / — | — / — |
| viljandi-ruins | not recorded | not recorded | not established | — / — | — / — | — / — |
| kakerdi-bog | not recorded | not recorded | not established | — / — | — / — | — / — |
| fjoloy | not recorded | not recorded | not established | — / — | — / — | — / — |

Nonfinished attempts have no completed-bake or first-view timing in this table. Their censored timing, visible explanation, advice, and original status remain in each raw row. Missing or unpaired measurements cannot establish an improvement.
