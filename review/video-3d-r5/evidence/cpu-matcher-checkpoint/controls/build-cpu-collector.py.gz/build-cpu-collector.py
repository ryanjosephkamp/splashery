from pathlib import Path
import ast,json,hashlib,datetime
ROOT=Path('/workspace/work/v3d-r5/final-run')
OUT=ROOT/'session-cpu-matcher';OUT.mkdir(exist_ok=True)
source=(ROOT/'session-isolated-media/collect.py').read_text()
source=source.replace("SESSION=ROOT/'session-isolated-media'","SESSION=ROOT/'session-cpu-matcher'").replace('decoded-picture','cpu-matcher').replace('4178/','4179/')
source=source.replace("lock=threading.RLock()","lock=threading.RLock()\nDESKTOP_CLAIMS={'main':set(),'candidate':set()}")
def replace_function(text,name,replacement):
 tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
 lines=text.splitlines(keepends=True);return ''.join(lines[:node.lineno-1])+replacement+'\n'+''.join(lines[node.end_lineno:])
# The unchanged affinity launcher locks children; a pinned orchestration thread briefly
# admits its child's requested cores during Popen, then restores its own original mask.
fixed=(ROOT/'session-cpu-samples-four/collect.py').read_text();tree=ast.parse(fixed)
command=ast.get_source_segment(fixed,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='command'))
source=replace_function(source,'command',command)
helpers='''
def validate_early_samples():
 result=subprocess.run(['nice','-n','19','taskset','-c','3','node','/workspace/work/v3d-r5/session/verify-cpu-samples-for-reuse.mjs'],cwd=REPO,capture_output=True,text=True)
 (SESSION/'sample-reuse-validation.log').write_text(result.stdout+result.stderr)
 if result.returncode:raise RuntimeError('Complete early sample proof is not valid: '+result.stderr[-700:])
 proof=json.loads(result.stdout)
 if proof['candidateSourceSha256']!=FREEZE['candidateServedSourceSha256']:raise RuntimeError('Sample proof belongs to a different runtime')
 (SESSION/'validated-samples.json').write_text(json.dumps(proof,indent=2)+'\\n')
 return proof

def extra_lane_ready(version):
 while time.time()<DEADLINE:
  with lock:
   released=any(e['event']=='isolated-media-window-released' for e in state['events'])
  if released:
   if version=='main':return
   try:
    control=json.loads((ROOT/'session-protocol6-control/control-state.json').read_text())
    terminal=any(e['event'] in ['fresh-control-terminal','fresh-control-not-launched'] for e in control.get('events',[]))
    if terminal and not control.get('active'):return
   except (OSError,ValueError):pass
  time.sleep(.5)
 raise TimeoutError('Goal deadline before the reserved extra desktop lane became available')

def desktop_claim(version):
 with lock:
  if len(DESKTOP_CLAIMS[version])==len(CLIPS):return 'done'
  if MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set():return None
  for index,clip in enumerate(CLIPS,1):
   if index in DESKTOP_CLAIMS[version]:continue
   reference=None
   if version=='candidate':
    try:
     run=json.loads((ROOT/'runs/main/desktop'/f'{index:02d}-{clip["id"]}'/'run.json').read_text())
     master=json.loads((ROOT/'main-reference/run.json').read_text())
     if len(run.get('results',[]))!=1 or not any(r['id']==clip['id'] and r['profile']=='desktop' for r in master['results']):continue
     reference=accounted(run['results'][0])
    except (OSError,ValueError):continue
   DESKTOP_CLAIMS[version].add(index)
   record('desktop-case-claimed',version=version,index=index,id=clip['id'])
   return index,clip,reference
 return None

def desktop_lane(version,cores,extra=False):
 if extra:extra_lane_ready(version)
 while time.time()<DEADLINE:
  claim=desktop_claim(version)
  if claim=='done':
   record('desktop-worker-complete',version=version,cores=cores,extra=extra,notice='Every manifest index has been claimed; final counts still come from actual terminal native rows.')
   return
  if claim is None:time.sleep(.25);continue
  index,clip,reference=claim
  wait_for_media(version+'-desktop-'+clip['id'])
  one(version,'desktop',clip,index,cores,reference=reference)
 raise TimeoutError('Goal deadline in desktop collection')
'''
source=source.replace('def desktop_main():',helpers+'\ndef desktop_main():',1)
source=replace_function(source,'desktop_main',"def desktop_main(extra=False):\n desktop_lane('main',LANES['desktopMainExtra'] if extra else LANES['desktopMain'],extra)")
source=replace_function(source,'desktop_candidate',"def desktop_candidate(extra=False):\n desktop_lane('candidate',LANES['desktopCandidateExtra'] if extra else LANES['desktopCandidate'],extra)")
phone_node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='phone')
phone=ast.get_source_segment(source,phone_node)
start=phone.index(" for version,url in [('main','4174'),('candidate','4178')]:") if " for version,url in [('main','4174'),('candidate','4178')]:" in phone else phone.index(" for version,url in [('main','4174'),('candidate','4179')]:")
end=phone.index(" snapshot=candidate_join(",start)
phone=phone[:start]+" proof=validate_early_samples()\n record('complete-fixed-samples-reused',proof=proof,notice='The complete source-bound four-core sample window already passed every original pixel comparison.')\n"+phone[end:]
phone=phone.replace("LANES['phone'],'phone-review'","LANES['review'],'phone-review'")
source=replace_function(source,'phone',phone)
guard="if (ROOT/'cpu-matcher-samples-main').exists():raise RuntimeError('Isolated-media takeover must happen before sample rendering starts')"
assert guard in source;source=source.replace(guard,"# Complete early samples are reused only after source and every PNG hash are validated.")
needle="if '--validate-only' in __import__('sys').argv:"
insert="""
for version in ['main','candidate']:
 groups=['main'] if version=='main' else ['cpu-matcher-strict-candidate','cpu-matcher-unpaired-candidate']
 for index,clip in enumerate(CLIPS,1):
  for group in groups:
   path=ROOT/'runs'/group/'desktop'/f'{index:02d}-{clip["id"]}'/'run.json'
   if path.exists() and len(json.loads(path.read_text()).get('results',[]))==1:DESKTOP_CLAIMS[version].add(index)
"""
source=source.replace(needle,insert+'\n'+needle)
source=source.replace("record('isolated-media-orchestration-continuation'","validate_early_samples()\nrecord('cpu-matcher-native-collection-start'")
source=source.replace("notice='Fresh candidate outputs on unchanged protocol 5. Exact existing baseline outcomes are reused; all superseded candidate rows remain separate diagnostics.'","notice='Every CPU-matcher candidate case starts fresh on unchanged protocol 5. Exact baseline outcomes are reused, including failures. Old candidate sources remain separate diagnostics. Each desktop case keeps one core; extra desktop lanes start only after phone timing and all review rendering finish.'")
source=source.replace('ThreadPoolExecutor(max_workers=3)','ThreadPoolExecutor(max_workers=5)')
old="[('phone',phone),('desktop-main',desktop_main),('desktop-candidate',desktop_candidate)]"
new="[('phone',phone),('desktop-main',desktop_main),('desktop-candidate',desktop_candidate),('desktop-main-extra',lambda:desktop_main(True)),('desktop-candidate-extra',lambda:desktop_candidate(True))]"
assert old in source;source=source.replace(old,new)
source=source.replace("['taskset','-c',str(LANES['research'][0]),'node'","['nice','-n','19','taskset','-c',str(LANES['research'][0]),'node'")
ast.parse(source);(OUT/'collect.py').write_text(source)
lanes={'phone':[0,1],'desktopMain':[2],'desktopCandidate':[3],'desktopMainExtra':[1],'desktopCandidateExtra':[0],'research':[3],'review':[0,1,2,3],'notice':'Native phone cases keep two cores; each native desktop case keeps one core. Extra desktop lanes begin after phone timing and all media finish. Core 0 first serves the separate protocol-6 control. All descendant masks remain kernel-locked. Software-profile data do not establish physical-device speed.'}
(OUT/'cpu-lanes.json').write_text(json.dumps(lanes,indent=2)+'\n')
prior=json.loads((ROOT/'session-isolated-media/freeze.json').read_text());prior.update(candidateRuntimeCommit='f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac',candidateServedSourceSha256='e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571',controllerSha256=hashlib.sha256(source.encode()).hexdigest(),previousControllerSha256=json.loads((ROOT/'session-isolated-media/freeze.json').read_text())['controllerSha256'],orchestrationContinuedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),notice='Fresh cooperative CPU runtime corpus; original baseline protocol, source, options, and outcomes retained. All earlier candidate sources are diagnostics. Complete fixed samples are validated before reuse. Four-core movie rendering runs without any timed bake. Extra native desktop lanes preserve one core per case.')
(OUT/'freeze.json').write_text(json.dumps(prior,indent=2)+'\n')
(OUT/'takeover.json').write_text(json.dumps({'adopted':{},'notice':'The two uploads active at the orchestration pause completed under their original deadlines. Every owned child was terminal. No native upload is interrupted, relabeled, or promoted.'},indent=2)+'\n')
print(json.dumps({'controller':str(OUT/'collect.py'),'sha256':prior['controllerSha256'],'runtime':prior['candidateRuntimeCommit'],'source':prior['candidateServedSourceSha256'],'workers':5,'extraCoresAfterMedia':{'main':[1],'candidate':[0]}}))
