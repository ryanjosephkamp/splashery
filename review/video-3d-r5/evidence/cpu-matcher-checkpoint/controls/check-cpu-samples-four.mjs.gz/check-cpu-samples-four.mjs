// MIT. Fixed sample pixel comparisons in a separate window after all timed uploads ended.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {checkSamples,assertSampleInventory} from '/workspace/work/v3d-r5/evaluator-protocol5/tools/v3d-bench-samples.mjs';
import {servedSourceFingerprint} from '/workspace/work/v3d-r5/evaluator-protocol5/tools/v3d-bench.mjs';
const root='/workspace/work/v3d-r5',session=root+'/final-run/session-cpu-samples-four';
const hash=b=>createHash('sha256').update(b).digest('hex');
const plan=JSON.parse(fs.readFileSync(session+'/plan.json'));
const receipt={started:new Date().toISOString(),notice:plan.notice,roles:[]};
const save=()=>fs.writeFileSync(session+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');save();
try{
 for(const role of plan.roles){
  for(const [file,want] of Object.entries(plan.runtimeFiles))if(hash(fs.readFileSync('/workspace/splashery/'+file))!==want)throw Error('New runtime changed before sample capture: '+file);
  const before=await servedSourceFingerprint(role.url);if(role.sourceSha256&&before.sha256!==role.sourceSha256)throw Error('Unexpected frozen sample source: '+role.name);
  const item={role:role.name,url:role.url,output:role.output,started:new Date().toISOString(),sourceBefore:before};receipt.roles.push(item);save();
  await checkSamples(role.output,{url:role.url,reference:role.reference});
  const bytes=fs.readFileSync(role.output+'/samples.json'),rows=JSON.parse(bytes);assertSampleInventory(rows);
  item.sourceAfter=await servedSourceFingerprint(role.url);if(item.sourceAfter.sha256!==before.sha256)throw Error('Sample source changed while rendering: '+role.name);
  Object.assign(item,{finished:new Date().toISOString(),samplesSha256:hash(bytes),cases:rows.length,views:rows.reduce((n,r)=>n+r.frames.length,0),status:'passed'});save();
 }
 receipt.finished=new Date().toISOString();receipt.status='passed';save();console.log(JSON.stringify({status:'passed',roles:receipt.roles.map(({role,cases,views,samplesSha256,sourceBefore})=>({role,cases,views,samplesSha256,sourceSha256:sourceBefore.sha256}))}));
}catch(error){receipt.finished=new Date().toISOString();receipt.status='failed';receipt.error=error.message;save();throw error;}
