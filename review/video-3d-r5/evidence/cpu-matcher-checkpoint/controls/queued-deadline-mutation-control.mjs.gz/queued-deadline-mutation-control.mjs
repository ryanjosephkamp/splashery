// MIT. Work-only negative control. The product file and native processes are never edited.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const file='/workspace/splashery/src/video3d/deadline.js',source=fs.readFileSync(file,'utf8');
const guard='          if (performance.now() >= expiresAt) {\n            expire();\n            return;\n          }\n';
assert.equal(source.split(guard).length,2,'Expected exactly one pre-start deadline guard');
const descriptor=Object.getOwnPropertyDescriptor(performance,'now');let now=100;
Object.defineProperty(performance,'now',{configurable:true,value:()=>now});
const outcomes=[];
try{
 for(const [variant,code] of [['unchanged',source],['guard-removed',source.replace(guard,'')]]){
  const {runWithDeadline}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
  let started=false;
  const pending=runWithDeadline(()=>{started=true;return 'late work';},{timeoutMs:10,message:'Try a shorter stretch.'});
  now+=25;let error;try{await pending;}catch(e){error=e.message;}
  outcomes.push({variant,started,error,contractPassed:!started&&error==='Try a shorter stretch.'});
 }
 assert.equal(outcomes[0].contractPassed,true);assert.equal(outcomes[1].contractPassed,false);
 const receipt={at:new Date().toISOString(),sourceSha256:createHash('sha256').update(source).digest('hex'),notice:'Clock-controlled work-only mutation. No product code, original assertion, timeout, source revision, or native result changes.',outcomes};
 fs.writeFileSync('/workspace/work/v3d-r5/session/queued-deadline-mutation-control.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
}finally{if(descriptor)Object.defineProperty(performance,'now',descriptor);else delete performance.now;}
