from pathlib import Path
import datetime,gzip,hashlib,json,shutil
root=Path('/workspace/work/v3d-r5');repo=Path('/workspace/splashery');dest=root/'clips/review/video-3d-r5/evidence/cpu-matcher-checkpoint'
assert not dest.exists(),'Checkpoint must be new; never rewrite a published snapshot'
dest.mkdir(parents=True);items=[]
corpus=json.loads((repo/'tools/v3d-corpus.json').read_text())
assets=json.loads((repo/'tools/assets.json').read_text());sample_records={}
def find(x):
 if isinstance(x,dict):
  if x.get('id') in ['adjara','edinburgh','liberty','lihula','poltsamaa','toolse'] and x.get('toy')=='video-3d':sample_records[x['id']]=x
  else:
   for v in x.values():find(v)
 elif isinstance(x,list):
  for v in x:find(v)
find(assets);assert len(sample_records)==6
for record in sample_records.values():
 for key in ['author','page','license','checked','sha256','note']:assert record.get(key),(record['id'],key)
def copy(source,relative,credit=None,stage=None):
 if not source.is_file():raise FileNotFoundError(source)
 raw=source.read_bytes();target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True)
 if source.suffix in ['.json','.mjs','.js','.py','.log','.txt','.md','.jsonl']:
  target=Path(str(target)+'.gz')
  with target.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(raw)
 else:shutil.copyfile(source,target)
 item={'source':str(source.relative_to(root)) if source.is_relative_to(root) else str(source),'file':str(target.relative_to(dest)),'bytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'storedSha256':hashlib.sha256(target.read_bytes()).hexdigest()}
 if credit:item['credit']=credit
 if stage:item['stage']=stage
 items.append(item)
controls=['build-cpu-collector.py','camera-cpu-matcher-control.json','camera-cpu-matcher-control.mjs','camera-production-cpu-control.json','camera-production-cpu-control.mjs','camera-production-cpu-parity.json','camera-production-cpu-source-proof.json','camera-production-cpu-source-proof.log','check-cpu-media-admission.py','check-cpu-samples-four.mjs','check-cpu-samples.mjs','ci-protocol6-shard15-actual.log','ci-protocol6-shard3-actual.log','ci-protocol6-shard9-actual.log','cpu-atomic-media-admission-control.json','cpu-atomic-media-admission-control.log','cpu-audit-format.log','cpu-ci-live-0717.json','cpu-desktop-claim-control.json','cpu-english.log','cpu-match-engine-controls.log','cpu-match-format.log','cpu-match-pipeline-controls.log','cpu-match-pipeline-final-controls.log','cpu-match-pipeline-format.log','cpu-match-scheduler-negative.log','cpu-matcher-orchestration-pause.json','cpu-matcher-served-source.json','cpu-matcher-state-before-pause.json','cpu-prettier-all.log','cpu-publication-commits.json','cpu-source-publication.json','matcher-early-exit-experiment.mjs','matcher-early-exit-module.mjs','matcher-exact-source-early-exit-experiment.mjs','matcher-ffprobe-source-early-exit-experiment.json','matcher-ffprobe-source-early-exit-experiment.mjs','matcher-picture-early-exit-experiment.mjs','matcher-settled-early-exit-experiment.mjs','original-merged-spec-audit-cpu.json','queued-deadline-controls.log','queued-deadline-format.log','queued-deadline-mutation-control.json','queued-deadline-mutation-control.log','queued-deadline-mutation-control.mjs','sample-resource-pixel-parity.json','verify-cpu-samples-for-reuse.mjs']
for name in controls:copy(root/'session'/name,Path('controls')/name)
for source in sorted((root/'session/affinity-admission-control').rglob('*')):
 if source.is_file():copy(source,Path('controls/affinity-admission-control')/source.relative_to(root/'session/affinity-admission-control'))
for source in sorted((root/'final-run/session-matcher-research').rglob('*')):
 if source.is_file() and source.suffix in ['.json','.log','.mjs','.txt','.py']:
  copy(source,Path('failed-matcher-research')/source.relative_to(root/'final-run/session-matcher-research'),credit=next(c for c in corpus if c['id']=='dianthus'))
for name in ['verify-cpu-camera-source.mjs']:copy(root/'decoder-verification'/name,Path('decoder-controls')/name)
for name in ['vendor/splatjs/src/sfm/sift.js','vendor/splatjs/src/sfm/sfm.js','src/video3d/run.js','tests/cdx-v3d-cpu-match.spec.mjs','tests/cdx-v3d-queued-deadline.spec.mjs','docs/audits/video-3d-r5-2026-10.md']:
 copy(repo/name,Path('published-f1f7f339')/name)
session=root/'final-run/session-cpu-matcher'
for source in sorted(session.iterdir()):
 if source.is_file() and source.suffix in ['.json','.py','.mjs','.jsonl','.log','.md'] and not source.name.startswith(('main-desktop-','candidate-desktop-','candidate-phone-')):
  copy(source,Path('collection')/source.name)
freeze=json.loads((session/'freeze.json').read_text())
for name,want in freeze['files'].items():
 source=root/'evaluator-protocol5'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==want,name
 copy(source,Path('frozen-protocol-5')/name)
for group in ['main','cpu-matcher-strict-candidate','cpu-matcher-unpaired-candidate']:
 base=root/'final-run/runs'/group
 for runfile in sorted(base.glob('*/*/run.json')):
  run=json.loads(runfile.read_text())
  if not run['results']:continue # Active native commands have no terminal outcome yet.
  assert len(run['results'])==1
  row=run['results'][0];clip=next(c for c in corpus if c['id']==row['id'])
  for source in sorted(runfile.parent.rglob('*')):
   if source.is_file() and 'attempts' not in source.relative_to(runfile.parent).parts:
    copy(source,Path('native')/group/source.relative_to(base),credit=clip,stage='baseline-5a55f5cc' if group=='main' else 'current-f1f7f339')
for label in ['session-cpu-samples-four','session-cpu-samples']:
 base=root/'final-run'/label
 if base.exists():
  for source in sorted(base.iterdir()):
   if source.is_file() and source.suffix in ['.json','.mjs','.py','.log']:copy(source,Path('sample-controls')/label/source.name)
for role in ['main','candidate']:
 base=root/'final-run'/f'cpu-matcher-samples-{role}-four'
 for source in sorted(base.rglob('*')):
  if not source.is_file():continue
  ident=source.parent.name.rsplit('-',1)[0] if source.suffix=='.png' else None
  credit=sample_records[ident] if ident else None
  copy(source,Path('samples')/role/source.relative_to(base),credit=credit,stage='baseline-5a55f5cc' if role=='main' else 'current-f1f7f339')
 for ident in sample_records:
  copy(repo/'assets/toys/video-3d'/f'{ident}.json',Path('sample-input-metadata')/f'{ident}.json',credit=sample_records[ident])
  copy(repo/'assets/toys/video-3d'/f'{ident}-baked/manifest.json',Path('sample-input-metadata')/f'{ident}-baked-manifest.json',credit=sample_records[ident])
 # Metadata is identical across roles; only copy it once.
 break
# Candidate screenshots and report are separate originals, even though all PNG bytes are identical.
base=root/'final-run/cpu-matcher-samples-candidate-four'
for source in sorted(base.rglob('*')):
 if source.is_file():
  ident=source.parent.name.rsplit('-',1)[0] if source.suffix=='.png' else None
  copy(source,Path('samples/candidate')/source.relative_to(base),credit=sample_records[ident] if ident else None,stage='current-f1f7f339')
for source in sorted((root/'final-run/session-protocol6-control').iterdir()):
 if source.is_file() and source.suffix in ['.json','.py','.log','.jsonl']:copy(source,Path('separate-future-protocol6-control')/source.name)
notice='Lossless frozen CPU runtime and complete sample preservation, plus partial native protocol-5 evidence. Every original outcome is retained. No corpus acceptance or physical-phone speed is established. Earlier matcher research and the separate future protocol-6 control cannot promote native failures or establish mixed-protocol comparisons.'
(dest/'inventory.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'notice':notice,'source':'f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac','runtimeSha256':'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571','sampleCredits':sample_records,'files':items},indent=2)+'\n')
(dest/'README.md').write_text('''# Cooperative CPU matcher checkpoint

Current published source is f1f7f339, with runtime fingerprint
e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571.
The complete native corpus remains on the unchanged protocol-5 evaluator at 0406a781.
Every new candidate case starts fresh. Exact baseline outcomes, including failures, are reused.
Earlier source revisions and failed research remain separate; no missing result is favorable.

The software-adapter CPU matcher retains the original integer distances, nearest two matches,
ratio and reciprocal tests, tie behavior, and output order. All five new parity and cancellation
checks pass. An actual browser timer rejected the scheduler-yield prototype; ordinary timer
turns pass the same assertion. Every original merged spec file remains byte-identical.
Queued-deadline mutation checks reject work that starts after its deadline. No threshold,
image count, native tier, or training budget is reduced.

An actual camera-only flower upload solved 17 cameras and 5,257 points in 229.745 seconds.
All 17 JPEGs and camera parameters exactly match the synchronous control. Independent
source decoding verifies all 17 training inputs and four eligible, disjoint held-outs.
It stops before seeding and training; it is not a native bake or quality acceptance result.

The six fixed samples pass all original checks against current main: 12 sample/profile
pairs, with 74 views total across both profiles, 37 per profile. All 74 RGBA comparisons
are exact and nonblank. Both roles' 148 original PNGs, reports, all original camera and
inventory checks, and served-source hashes before and after replay are preserved here.
All 74 pairs also have identical PNG bytes. An earlier partial two-core replay is retained;
its 41 overlapping PNGs match the complete quiet four-core replay exactly.

Corpus results are a partial checkpoint. The first current phone quality pair has 2.7816
times sharpness and +0.012297 SSIM, with first view 54.061 to 34.917 seconds and bake
679.986 to 520.049 seconds. This is one clip, not a corpus pass. No strict desktop quality
pair exists yet. Emulated software profiles cannot establish physical-phone performance.
Every host timeout remains a failure; every explained clip must have visible reasons and advice.

The original full suite failures are retained even when isolated reruns pass. A current
359-spec full run is pending. Corpus collection, clean timing, and source-bound phone
movies continue until the 13:30 UTC twelve-hour limit on October 16, 2026.

Every derived native asset carries its complete corpus source record in the inventory.
Sample screenshots carry the six fixed samples' own source records, rather than corpus
credits. Source-derived data retain those licenses. Toolse and Poltsamaa screenshots are
CC BY-SA 4.0 derivatives, by Sillerkiil; the complete source pages and transformations
appear beside each asset in the inventory. No separate licensed sources are composited.
Code is MIT, made by Ryan with Codex (GPT-6). Never merge this evidence branch.
Gzip files preserve exact original bytes. PNG and PLY files are unchanged. Both stored
and original SHA-256 hashes are verified for every copied file.
''')
for item in items:
 stored=(dest/item['file']).read_bytes();raw=gzip.decompress(stored) if item['file'].endswith('.gz') else stored
 assert hashlib.sha256(stored).hexdigest()==item['storedSha256'] and hashlib.sha256(raw).hexdigest()==item['originalSha256'],item['file']
print(json.dumps({'files':len(items),'storedBytes':sum((dest/x['file']).stat().st_size for x in items),'allHashesVerified':True}))
