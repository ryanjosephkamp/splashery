// MIT. Verify the complete original pixel-check reports and every saved PNG before reuse.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {assertSampleInventory,assertSampleCase} from '/workspace/work/v3d-r5/evaluator-protocol5/tools/v3d-bench-samples.mjs';
const root='/workspace/work/v3d-r5/final-run',file=root+'/session-cpu-samples-four/receipt.json';
const hash=b=>createHash('sha256').update(b).digest('hex');
const bytes=fs.readFileSync(file),receipt=JSON.parse(bytes);
if(receipt.status!=='passed'||receipt.roles.length!==2)throw Error('The complete early sample window has not passed');
const expected={main:'99cea09dd4f5367f78cfe4d1b5bed97cb87432c38222e6c81edf873be25da9fa',candidate:'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571'};
const roles={};let pngs=0;
for(const role of receipt.roles){
 if(role.status!=='passed'||role.cases!==12||role.views!==74||role.sourceBefore.sha256!==expected[role.role]||role.sourceAfter.sha256!==expected[role.role])throw Error('Incomplete or changed sample source: '+role.role);
 const report=fs.readFileSync(role.output+'/samples.json');if(hash(report)!==role.samplesSha256)throw Error('Sample report changed');
 const rows=JSON.parse(report);roles[role.role]=assertSampleInventory(rows);
 for(const row of rows)for(const frame of row.frames){
  const saved=fs.readFileSync(path.join(role.output,row.id+'-'+row.profile,frame.index+'.png'));
  if(hash(saved)!==frame.sha256)throw Error('Saved sample PNG changed');pngs++;
 }
}
for(const [key,row]of roles.candidate){assertSampleCase(row,roles.main.get(key));if(row.preserved!==true)throw Error('A sample pixel comparison did not pass: '+key);}
console.log(JSON.stringify({at:new Date().toISOString(),receiptSha256:hash(bytes),mainSourceSha256:expected.main,candidateSourceSha256:expected.candidate,sampleProfilePairs:12,viewsPreserved:74,originalPngsVerified:pngs,allOriginalPixelChecksPassed:true,main:receipt.roles.find(r=>r.role==='main').output,candidate:receipt.roles.find(r=>r.role==='candidate').output}));
