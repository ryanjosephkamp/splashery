import ast,threading,time,hashlib,os,json,types
from pathlib import Path
source=Path('/workspace/work/v3d-r5/final-run/session-cpu-matcher/collect.py');tree=ast.parse(source.read_text());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='command')
entered=threading.Event();release=threading.Event();finished=threading.Event();observed=threading.Event();requested=threading.Event();media_done=threading.Event();lock=threading.RLock();state={'active':{}};events=[];errors=[];seen=[]
class Process:
 pid=1234567
 returncode=None
 def __init__(self,*args,**kwargs):
  entered.set()
  if not release.wait(2):raise AssertionError('Launch was not released')
 def poll(self):
  if finished.is_set():self.returncode=0;return 0
  return None
 def wait(self,**kwargs):return 0
repo=Path('/workspace/work/v3d-r5/evaluator-protocol5');sha=hashlib.sha256((repo/'tools/v3d-affinity.py').read_bytes()).hexdigest()
def processes():return {1234567:{'ppid':1,'startTicks':'test','status':'Z' if finished.is_set() else 'S'}}
namespace={'time':time,'datetime':__import__('datetime'),'hashlib':hashlib,'os':types.SimpleNamespace(environ={**os.environ,'V3D_AFFINITY_SHA256':sha},sched_getaffinity=os.sched_getaffinity,sched_setaffinity=os.sched_setaffinity,kill=lambda *args:(_ for _ in ()).throw(AssertionError('No real process may be signaled'))),'Path':Path,'REPO':repo,'DEADLINE':time.time()+20,'ADOPTED':{},'state':state,'lock':lock,'MEDIA_REQUESTED':requested,'MEDIA_FINISHED':media_done,'subprocess':types.SimpleNamespace(Popen=Process,STDOUT=-2),'processes':processes,'descendants':lambda root,table:{root},'record':lambda event,**data:events.append({'event':event,**data}),'signal':__import__('signal')}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),'exec'),namespace)
def launch():
 try:namespace['command'](['test'],Path('/workspace/work/v3d-r5/session/atomic-admission.log'),[3],'candidate-desktop-test')
 except BaseException as e:errors.append(repr(e))
def inspect_window():
 with lock:seen.extend(state['active']);observed.set()
 finished.set()
worker=threading.Thread(target=launch);worker.start();assert entered.wait(2),errors
requested.set();inspector=threading.Thread(target=inspect_window);inspector.start();time.sleep(.05)
assert not observed.is_set(),'Media window entered while a desktop launch was not registered'
release.set();assert observed.wait(2);assert seen==['candidate-desktop-test'],seen
worker.join(3);inspector.join(3);assert not worker.is_alive() and not errors,errors
assert not state['active']
receipt={'at':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'controllerSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'notice':'Actual generated command function exercised with a paused fake process constructor and concurrent media-window inspector; no native process launched or signaled.','mediaCouldNotPassUnregisteredLaunch':True,'admittedDesktopVisibleBeforeMedia':True,'terminalSlotReleased':True,'events':[e['event'] for e in events]}
Path('/workspace/work/v3d-r5/session/cpu-atomic-media-admission-control.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
