import fs from 'node:fs';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl','--enable-unsafe-webgpu','--enable-features=Vulkan,WebGPU','--use-webgpu-adapter=swiftshader','--use-vulkan=swiftshader']});
try {
 const page=await browser.newPage();
 await page.route('**/__caps',r=>r.fulfill({contentType:'text/html',body:'<title>Affinity capability</title>'}));
 await page.goto('http://127.0.0.1:4175/__caps');
 const gpu=await page.evaluate(async()=>{
  const a=await navigator.gpu.requestAdapter();if(!a)throw Error('No adapter');
  const d=await a.requestDevice(); const b=d.createBuffer({size:4,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});d.queue.writeBuffer(b,0,new Float32Array([1]));await d.queue.onSubmittedWorkDone();b.destroy();d.destroy();return {vendor:a.info.vendor,architecture:a.info.architecture};
 });
 const proc=()=>fs.readdirSync('/proc').filter(s=>/^\d+$/.test(s)).flatMap(id=>{try{const s=fs.readFileSync(`/proc/${id}/status`,'utf8');return [{pid:+id,ppid:+s.match(/^PPid:\s+(\d+)/m)[1]}];}catch{return [];}});
 const all=proc(),owned=new Set([process.pid]);let changed=true;while(changed){changed=false;for(const p of all)if(owned.has(p.ppid)&&!owned.has(p.pid)){owned.add(p.pid);changed=true;}}
 const tasks=[];for(const pid of owned)for(const tid of fs.readdirSync(`/proc/${pid}/task`)){try{const s=fs.readFileSync(`/proc/${pid}/task/${tid}/status`,'utf8');tasks.push({pid,tid:+tid,mask:s.match(/^Cpus_allowed_list:\s+(.*)/m)[1].trim()});}catch{}}
 if(!tasks.length||tasks.some(t=>t.mask!=='3'))throw Error('A descendant escaped the declared CPU: '+JSON.stringify(tasks));
 fs.writeFileSync('/workspace/work/v3d-r5/session/locked-affinity-proof.json',JSON.stringify({at:new Date().toISOString(),gpu,declared:[3],tasks},null,2)+'\n');
 console.log(JSON.stringify({gpu,threadCount:tasks.length,allMasks:'3'}));
}finally{await browser.close();}
