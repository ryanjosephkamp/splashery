# MIT. Validate and preserve actual review media; never modify a benchmark result.
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import fractions
import zipfile

BASE = Path('/workspace/work/v3d-r5')
SOURCE = BASE / 'final-run/cpu-matcher-phone-review'
DEST = BASE / 'clips/review/video-3d-r5/evidence/cpu-phone-movies'
report = json.loads((SOURCE / 'review.json').read_text())
assert report['profile'] == 'phone'
assert report['capturedClips'] == 10
assert len(report['cases']) == 10
assert all(c['status'] == 'captured' for c in report['cases'])
assert not report['selection']['ranked']
assert not report['rankedMediaComplete']
assert hashlib.sha256((BASE / 'evaluator-protocol5/tools/v3d-review.mjs').read_bytes()).hexdigest() == report['provenance']['toolSha256']
assert {v['name']: v['preservePhotometric'] for v in report['provenance']['versions']} == {'main': False, 'this-round': True}
assert not DEST.exists()
DEST.mkdir(parents=True)
items, controls = [], []
sha = lambda data: hashlib.sha256(data).hexdigest()
def copy(file, relative, credit=None):
    raw = file.read_bytes()
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if file.suffix in ['.json', '.jsonl', '.log', '.html', '.txt', '.py', '.mjs']:
        target = Path(str(target) + '.gz')
        with target.open('wb') as stream:
            with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as archive:
                archive.write(raw)
    else:
        shutil.copyfile(file, target)
    item = {'source': str(file.relative_to(BASE)), 'file': str(target.relative_to(DEST)), 'originalBytes': len(raw), 'originalSha256': sha(raw), 'storedSha256': sha(target.read_bytes())}
    if credit:
        item['credit'] = credit
    items.append(item)

for case in report['cases']:
    folder = SOURCE / (case['id'] + '-phone')
    for entry in case['files']:
        file = folder / entry['file']
        assert file.parent == folder and sha(file.read_bytes()) == entry['sha256']
    assert len(case['verification']) == 2
    assert {v['version'] for v in case['verification']} == {'main', 'this-round'}
    assert all(v['scene']['uid'] == 'review-capture' and v['scene']['affine'] is True for v in case['verification'])
    for version in report['provenance']['versions']:
        native = Path(version['directory']) / (case['id'] + '-phone')
        native_run = json.loads((Path(version['directory']) / 'run.json').read_text())
        native_row = next(row for row in native_run['results'] if row['id'] == case['id'] and row['profile'] == report['profile'])
        assert native_row['status'] == 'finished' and native_row['heldoutEvidence']['complete'] is True
        evaluation = json.loads((native / 'evaluation.json').read_text())
        bound = next(v for v in case['modelMetadataSha256'] if v['version'] == version['name'])
        assert sha((native / 'model.json').read_bytes()) == bound['sha256']
        proof = next(v for v in case['verification'] if v['version'] == version['name'])
        assert len(proof['frames']) == len(native_row['frames']) == len(evaluation['times'])
        assert bool(proof['scene'].get('preservePhotometric')) == version['preservePhotometric']
        for index, (frame, original) in enumerate(zip(proof['frames'], native_row['frames'])):
            assert frame['index'] == index and frame['time'] == original['time'] == evaluation['times'][index]
            assert sha((native / f'render-{index}.png').read_bytes()) == frame['savedSha256'] == original['renderSha256']
    assert len(case['frames']) == case['timeline']['frames']
    assert [frame['time'] for frame in case['frames']] == case['timeline']['times']
    assert all(len(frame['mainRgbaSha256']) == 64 and len(frame['candidateRgbaSha256']) == 64 for frame in case['frames'])
    unique_frames = {version: len({frame[version + 'RgbaSha256'] for frame in case['frames']}) for version in ['main', 'candidate']}
    assert all(count > 1 for count in unique_frames.values())
    data = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,nb_read_frames,r_frame_rate:format=duration', '-of', 'json', str(folder / 'comparison.mp4')]))
    stream = data['streams'][0]
    assert stream['width'] == report['provenance']['paneWidth'] * 2 + 4
    assert stream['height'] == report['provenance']['paneHeight'] + 160
    assert int(stream['nb_read_frames']) == len(case['frames'])
    assert fractions.Fraction(stream['r_frame_rate']) == report['provenance']['fps']
    assert abs(float(data['format']['duration']) - case['timeline']['playbackSeconds']) < 0.15
    assert (folder / 'poster.jpg').stat().st_size <= 1000000
    control_folder = BASE / 'session/movie-media-file-controls'
    control_folder.mkdir(exist_ok=True)
    (control_folder / (case['id'] + '.json')).write_text(json.dumps({'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'id': case['id'], 'videoSha256': sha((folder / 'comparison.mp4').read_bytes()), 'originalNativeViewCounts': [len(v['frames']) for v in case['verification']], 'allOriginalNativeTimesAndRenderHashesBound': True, 'ffprobe': data}, indent=2) + '\n')
    controls.append({'id': case['id'], 'sourceBoundFilesVerified': True, 'savedHeldoutPixelsVerifiedPerVersion': [len(v['frames']) for v in case['verification']], 'synchronizedFrames': len(case['frames']), 'distinctFrameHashes': unique_frames, 'ffprobe': data})
    for file in sorted(folder.iterdir()):
        assert file.is_file()
        copy(file, Path(folder.name) / file.name, case['clip'])

for name in ['review.json', 'index.html']:
    copy(SOURCE / name, Path(name))
copy(BASE / 'evaluator-protocol5/tools/v3d-review.mjs', Path('controls/v3d-review.mjs'))
copy(Path(__file__), Path('controls/export-verified-phone-movies.py'))
for name in ['review-plan.json', 'phone-review.log']:
    file = BASE / 'final-run/session-cpu-adaptive' / name
    if file.is_file():
        copy(file, Path('controls') / name)
poster_notes = BASE / 'session/phone-movie-poster-review.json'
if poster_notes.is_file():
    copy(poster_notes, Path('controls/phone-movie-poster-review.json'))
for file in sorted((BASE / 'session/movie-media-file-controls').glob('*.json')):
    copy(file, Path('controls/independent-media-file-checks') / file.name)
for file in [BASE / 'session/movie-export-fixed-four-views/receipt.json', BASE / 'session/movie-export-fixed-four-views/failure.log', BASE / 'session/movie-export-fixed-four-views/export-verified-phone-movies.py']:
    copy(file, Path('controls/original-exporter-assertion-failure') / file.name)
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'movies': 10, 'ranked': False, 'rankLimitation': report['selection']['limitations'], 'validation': controls, 'files': items}
(DEST / 'inventory.json').write_text(json.dumps(receipt, indent=2) + '\n')
text = '''# Ten verified phone comparison movies

Main appears on the left and this round on the right, at 390 by 844 pixels per pane.
The complete movie is 784 by 1,004 pixels, including the original title and source-credit bars.
The production viewer replays the same recorded video times in each model's independently
solved coordinate frame. Every saved held-out render is reproduced exactly before recording.
Production cleanup is retained for each version. No retraining, alignment, camera fitting,
sharpening, or synthetic scene is used. Replay is not a phone-speed measurement.

These are the first ten verified pairs in the fixed manifest order. They are **unranked**:
main's Fjoloy upload has uncaught worker errors, so the unchanged full-profile selector
cannot honestly label five worst and five best clips. That unmet ranking gate is retained.
The inventory records all limitations, original media hashes, synchronized frame hashes,
scene checks, source-bound metadata, and independent ffprobe validation.

| Clip | Main / this round movie | Still | Source and license |
| --- | --- | --- | --- |
'''
for case in report['cases']:
    clip = case['clip']
    folder = case['id'] + '-phone'
    text += f"| {clip['label']} | [MP4]({folder}/comparison.mp4) | [JPEG]({folder}/poster.jpg) | {clip['author']} · [{clip['license']}]({clip['licenseUrl']}) · [source]({clip['source']}) |\n"
text += '\nFull original attribution and transformation records accompany every movie and remain in the inventory. Derived media retain each recorded source license. Gzip preserves original text bytes; MP4 and JPEG bytes are unchanged. Code is MIT, made by Ryan with Codex (GPT-6). Never merge this evidence branch.\n'
(DEST / 'README.md').write_text(text)
output = Path('/codex/browser/projectless/0003-goal-read-docs-codex-94-video-3d-r5-md-in-this-r/output')
output.mkdir(parents=True, exist_ok=True)
bundle = output / 'video-3d-r5-phone-review.zip'
assert not bundle.exists()
temporary = BASE / 'session/video-3d-r5-phone-review.zip'
with zipfile.ZipFile(temporary, 'w') as archive:
    bundle_files = []
    for file in sorted(SOURCE.rglob('*')):
        if file.is_file():
            relative = str(file.relative_to(SOURCE))
            archive.write(file, relative, compress_type=zipfile.ZIP_STORED if file.suffix in ['.mp4', '.jpg'] else zipfile.ZIP_DEFLATED)
            bundle_files.append({'file': relative, 'sha256': sha(file.read_bytes())})
    archive.writestr('README.txt', 'Extract this archive, then open index.html to watch all ten comparisons. Main is on the left. These are unranked verified pairs in the fixed manifest order; the original full-profile ranking remains unavailable. Every source author, license, and transformation is retained in review.json and each attribution.txt. These movies show replay, not physical-phone speed.\n')
    archive.writestr('bundle-inventory.json', json.dumps({'frozenProductSource': 'f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac', 'files': bundle_files}, indent=2) + '\n')
with zipfile.ZipFile(temporary) as archive:
    assert archive.testzip() is None
    for entry in bundle_files:
        assert sha(archive.read(entry['file'])) == entry['sha256']
shutil.move(temporary, bundle)
print(json.dumps({'movies': 10, 'ranked': False, 'allFilesVerified': True, 'folder': str(DEST), 'files': len(items), 'bundle': str(bundle), 'bundleSha256': sha(bundle.read_bytes()), 'bundleBytes': bundle.stat().st_size}))
