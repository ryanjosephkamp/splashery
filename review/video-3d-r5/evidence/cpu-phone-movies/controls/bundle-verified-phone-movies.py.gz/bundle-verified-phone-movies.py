# MIT. Package already-verified originals when the UI output mount is unavailable.
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import zipfile

BASE = Path('/workspace/work/v3d-r5')
SOURCE = BASE / 'final-run/cpu-matcher-phone-review'
DEST = BASE / 'clips/review/video-3d-r5/evidence/cpu-phone-movies'
inventory = json.loads((DEST / 'inventory.json').read_text())
assert inventory['movies'] == 10 and len(inventory['validation']) == 10
assert sum(sum(item['savedHeldoutPixelsVerifiedPerVersion']) for item in inventory['validation']) == 76
report = json.loads((SOURCE / 'review.json').read_text())
assert report['capturedClips'] == 10 and not report['selection']['ranked']
sha = lambda data: hashlib.sha256(data).hexdigest()
for item in inventory['files']:
    data = (DEST / item['file']).read_bytes()
    assert sha(data) == item['storedSha256']
    raw = gzip.decompress(data) if item['file'].endswith('.gz') else data
    assert sha(raw) == item['originalSha256']
temporary = BASE / 'session/video-3d-r5-phone-review.zip'
assert not temporary.exists()
bundle_files = []
with zipfile.ZipFile(temporary, 'w') as archive:
    for file in sorted(SOURCE.rglob('*')):
        if file.is_file():
            relative = str(file.relative_to(SOURCE))
            archive.write(file, relative, compress_type=zipfile.ZIP_STORED if file.suffix in ['.mp4', '.jpg'] else zipfile.ZIP_DEFLATED)
            bundle_files.append({'file': relative, 'sha256': sha(file.read_bytes())})
    archive.writestr('README.txt', 'Extract this archive, then open index.html to watch all ten comparisons. Main is on the left. These are unranked verified pairs in fixed manifest order. Every source author, license, and transformation is retained in review.json and each attribution.txt. All original held-out requirements are retained: four per version for nine cases, two for Fremantle (76 total saved-view matches). All ten complete movie files pass independent decoded frame-count, size, frame-rate, and duration checks. Replay does not measure phone speed.\n')
    archive.writestr('bundle-inventory.json', json.dumps({'frozenProductSource': 'f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac', 'files': bundle_files}, indent=2) + '\n')
with zipfile.ZipFile(temporary) as archive:
    assert archive.testzip() is None
    for entry in bundle_files:
        assert sha(archive.read(entry['file'])) == entry['sha256']
target = DEST / temporary.name
shutil.copyfile(temporary, target)
inventory['files'].append({'source': str(temporary.relative_to(BASE)), 'file': target.name, 'originalBytes': target.stat().st_size, 'originalSha256': sha(target.read_bytes()), 'storedSha256': sha(target.read_bytes()), 'credits': [case['clip'] for case in report['cases']], 'transformation': 'Lossless ZIP of all original comparison movies, posters, index, attributions, and verification records; no media re-encoding.'})
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'movies': 10, 'allMediaFileChecksPassed': True, 'savedViewMatches': 76, 'archiveMembersVerified': True, 'bundleBytes': target.stat().st_size, 'bundleSha256': sha(target.read_bytes()), 'localOutputUnavailable': '/codex is not writable in this execution environment, and sudo is unavailable. The same downloadable gallery is delivered on the explicitly requested clips branch.', 'noNativeResultOrOriginalThresholdChanged': True}
for file, relative in [(Path(__file__), 'controls/bundle-verified-phone-movies.py'), (BASE / 'session/movie-export-corrected.log', 'controls/output-path-packaging-error.log')]:
    raw = file.read_bytes()
    dest = DEST / (relative + '.gz')
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('wb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            compressed.write(raw)
    inventory['files'].append({'source': str(file.relative_to(BASE)), 'file': str(dest.relative_to(DEST)), 'originalBytes': len(raw), 'originalSha256': sha(raw), 'storedSha256': sha(dest.read_bytes())})
inventory['bundle'] = receipt
(DEST / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
with (DEST / 'README.md').open('a') as stream:
    stream.write('\n[Download the complete gallery ZIP](video-3d-r5-phone-review.zip), extract it, and open `index.html`. Every archive member is hash-verified; the ZIP includes the original uncompressed attributions and proofs. The execution workspace has no writable UI output mount, so this bundle is delivered on the requested clips branch.\n')
(BASE / 'session/movie-bundle-recovery.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
