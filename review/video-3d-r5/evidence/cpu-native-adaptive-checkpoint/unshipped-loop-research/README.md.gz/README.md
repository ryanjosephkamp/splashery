# Exact CPU loop experiments

These are work-only experiments. Product source f1f7f339, native source fingerprints,
cohort inputs, every original test, and all native budgets remain unchanged.

Two exact actual source pictures from dianthus, at 0.499674 and 1.999674 seconds,
produce the same pixel and descriptor hashes as the earlier source-verified probe.
The small case has 600 and 584 features, with 205 reciprocal matches. The large
case has 2,065 and 2,133 features, with 677 matches. The source cache carries the
complete original author, license, input hash, source page, and transformation record.

Each experiment checks seven descriptor sets at six ratios against the original:
126 prototype comparisons, plus 42 reference self-checks. All outputs match exactly.
Each prototype also honors an actual browser abort timer in the observed 39 ms.
The browser and its descendants are pinned to one CPU core by the unchanged
kernel-enforced launcher. These are matcher microbenchmarks, not native phone
speed, corpus quality, or complete bake measurements.

Simple loop blocking improves the real descriptor cases but slows the degenerate
all-ties case. Guarding the first component preserves its immediate rejection.
The eight-component variant with that guard improves both measured real cases
and the tie case. An additional zero-distance shortcut helps ties but makes the
cooperative small real case slower in this run; it is not a universal speedup.
No prototype is shipped. A fresh source-bound native cohort would be required.

| Case | Original synchronous ms | Guarded eight synchronous ms | Original cooperative ms | Guarded eight cooperative ms |
| --- | --- | --- | --- | --- |
| actual-dianthus-480 | 88.800 | 72.300 | 156.100 | 108.800 |
| actual-dianthus-960 | 1048.300 | 898.300 | 1211.300 | 1034.200 |
| all-ties-256 | 0.800 | 0.600 | unmeasured | unmeasured |

Source-derived descriptor data retain the original CC BY 4.0 license and Ventrovert credit,
with the full record in source-cache.json. Code is MIT, made by Ryan with Codex (GPT-6).
