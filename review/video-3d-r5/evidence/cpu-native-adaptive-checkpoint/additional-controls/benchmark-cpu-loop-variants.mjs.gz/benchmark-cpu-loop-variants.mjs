// MIT. Work-only exact-match loop experiment, actual Chromium, one isolated CPU core.
import fs from 'node:fs';import {createHash} from 'node:crypto';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {benchmarkLaunchArgs,withHostDeadline,closeBrowserBounded} from '/workspace/work/v3d-r5/evaluator-protocol6/tools/v3d-bench.mjs';
const root='/workspace/work/v3d-r5',folder=root+'/session/cpu-loop-research',cache=JSON.parse(fs.readFileSync(folder+'/source-cache.json'));
const hash=b=>createHash('sha256').update(b).digest('hex');for(const c of cache.cases)for(const f of c.frames)if(hash(fs.readFileSync(folder+'/'+f.file))!==f.descriptorSha256)throw Error('Source descriptors changed');
const names=['original','blocked-4','blocked-8','blocked-16'];
const server=await chromium.launchServer({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')}),browser=await chromium.connect(server.wsEndpoint());
try{
 const page=await browser.newPage();page.on('console',m=>{if(m.type()==='log')console.log(m.text());});
 for(const name of names)await page.route('**/__r5-cpu-loop-'+name+'.mjs',r=>r.fulfill({contentType:'text/javascript',path:folder+'/'+(name==='original'?'original-sift':name+'-sift')+'.mjs'}));
 for(const c of cache.cases)for(const f of c.frames)await page.route('**/__r5-desc-'+f.file,r=>r.fulfill({contentType:'application/octet-stream',path:folder+'/'+f.file}));
 await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const result=await withHostDeadline(()=>page.evaluate(async({names,cases})=>{
  const modules={};for(const name of names)modules[name]=await import('/__r5-cpu-loop-'+name+'.mjs');
  const equal=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]),rows=[];
  const sha=async a=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',Int32Array.from(a))),x=>x.toString(16).padStart(2,'0')).join('');
  const input=[];let seed=0x53d6a1;const next=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed>>>24;};
  for(const [na,nb]of [[1,1],[2,2],[63,65],[65,129]]){const a=Uint8Array.from({length:na*128},next),b=Uint8Array.from({length:nb*128},next);for(let i=0;i<Math.min(na,nb);i+=4)b.set(a.subarray(i*128,i*128+128),i*128);input.push({label:'synthetic-'+na+'-'+nb,mock:true,a,b,na,nb});}
  input.push({label:'all-ties-256',mock:true,a:new Uint8Array(256*128).fill(12),b:new Uint8Array(256*128).fill(12),na:256,nb:256});
  for(const c of cases){const [a,b]=await Promise.all(c.frames.map(async f=>new Uint8Array(await(await fetch('/__r5-desc-'+f.file)).arrayBuffer())));input.push({label:'actual-dianthus-'+c.side,mock:false,a,b,na:c.frames[0].n,nb:c.frames[1].n});}
  let assertions=0;
  for(const entry of input){const {a,b,na,nb}=entry;for(const ratio of [0,.2,.5,.8,1,1.1]){const expected=modules.original.matchSift(a,na,b,nb,ratio);for(const name of names){if(!equal(expected,modules[name].matchSift(a,na,b,nb,ratio)))throw Error('Legacy parity differs: '+entry.label+'/'+name+'/'+ratio);assertions++;}}}
  for(const entry of input){const {a,b,na,nb}=entry,expected=modules.original.matchSift(a,na,b,nb),trials=[];
   for(const name of names)if(!equal(expected,modules[name].matchSift(a,na,b,nb)))throw Error('Warm-up differs');
   for(let rep=0;rep<5;rep++)for(const name of (rep%2?[...names].reverse():names)){const t=performance.now(),actual=modules[name].matchSift(a,na,b,nb),ms=performance.now()-t;if(!equal(expected,actual))throw Error('Timed output differs');trials.push({rep,name,ms});}
   const row={label:entry.label,mock:entry.mock,features:[na,nb],matches:expected.length/2,sha256:await sha(expected),trials};
   if(!entry.mock){row.cooperativeTrials=[];for(let rep=0;rep<3;rep++)for(const name of(rep%2?[...names].reverse():names)){const t=performance.now(),actual=await modules[name].matchSiftAsync(a,na,b,nb),ms=performance.now()-t;if(!equal(expected,actual))throw Error('Cooperative output differs');row.cooperativeTrials.push({rep,name,ms});}}
   rows.push(row);console.log(JSON.stringify({label:entry.label,matches:row.matches,trialCount:trials.length}));
  }
  const real=input.find(c=>c.label==='actual-dianthus-960'),cancellation=[];
  for(const name of names){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),1),t=performance.now();let failed=false;try{await modules[name].matchSiftAsync(real.a,real.na,real.b,real.nb,.8,{signal:controller.signal});}catch(e){if(e.name!=='AbortError')throw e;failed=true;}finally{clearTimeout(timer);}const ms=performance.now()-t;if(!failed||ms>500)throw Error('Real cancellation did not finish promptly');cancellation.push({name,ms,aborted:true});}
  return {assertions,allOutputsExact:true,rows,cancellation};
 },{names,cases:cache.cases}),{timeoutMs:180000,label:'Exact CPU loop variants',onTimeout:()=>closeBrowserBounded(browser,server)});
 const median=v=>{v.sort((a,b)=>a-b);return v.length%2?v[(v.length-1)/2]:(v[v.length/2-1]+v[v.length/2])/2;};
 result.at=new Date().toISOString();result.notice='Work-only Chromium SIFT loop experiment on one kernel-enforced CPU core. Exact cached real descriptors match the earlier source-picture proof; synthetic data are labeled. This is not a native upload, corpus quality score, or phone-speed acceptance. Product source, native cohorts, thresholds, and budgets are untouched.';result.credit=cache.credit;result.cacheSha256=hash(fs.readFileSync(folder+'/source-cache.json'));result.variants=Object.fromEntries(names.map(n=>[n,hash(fs.readFileSync(folder+'/'+(n==='original'?'original-sift':n+'-sift')+'.mjs'))]));
 for(const row of result.rows){row.medianMs=Object.fromEntries(names.map(n=>[n,median(row.trials.filter(t=>t.name===n).map(t=>t.ms))]));if(row.cooperativeTrials)row.cooperativeMedianMs=Object.fromEntries(names.map(n=>[n,median(row.cooperativeTrials.filter(t=>t.name===n).map(t=>t.ms))]));}
 fs.writeFileSync(folder+'/results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({allOutputsExact:result.allOutputsExact,assertions:result.assertions,medians:result.rows.map(r=>({label:r.label,synchronous:r.medianMs,cooperative:r.cooperativeMedianMs})),cancellation:result.cancellation}));
}finally{await closeBrowserBounded(browser,server);}
