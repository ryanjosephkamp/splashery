# MIT. Recover exact publicly documented calibration inputs into private work only.
from pathlib import Path
import concurrent.futures,datetime,hashlib,html,json,re,urllib.parse,urllib.request
root=Path('/workspace/work/v3d-r5/private-calibration');root.mkdir(exist_ok=True)
records=[{'id':'shaky-pan','name':'Airplane_Spotting_at_St._Maarten_part_1.webm','author':'Matt','license':'CC BY 3.0','licenseUrl':'https://creativecommons.org/licenses/by/3.0/','start':94,'length':19,'expectedSha256':'72e98c6d16ee57c1699874fe4f54f06eac6e88df8c51da3d6b306570ecf4b695'}, {'id':'crowd','name':'Crowd_of_participants_at_the_ABU_Cultural_Carnival_3.webm','author':'Halima Waziri','license':'CC BY-SA 4.0','licenseUrl':'https://creativecommons.org/licenses/by-sa/4.0/','start':0,'length':5.8,'expectedSha256':'9732e7bab16be55c76a429d0bb289cb2a284378fb63b9df63f9a41e706c44159'}, {'id':'fast-zoom','name':'Crash_zoom_on_cigarette.webm','author':'Sarrah Anderson','license':'CC BY 3.0','licenseUrl':'https://creativecommons.org/licenses/by/3.0/','start':0,'length':10,'expectedSha256':'2cb1fa579138b475abd5fbc7282150ff6baf572e13e14d512fb380ad0a9f324d'}]
headers={'User-Agent':'Splashery-Video3D-calibration/1.0 (https://github.com/ryanjosephkamp/splashery)'}
def get(r):
 r=dict(r);r['source']='https://commons.wikimedia.org/wiki/File:'+urllib.parse.quote(r['name'],safe='_.()');r['file']=str(root/(r['id']+'.webm'))
 try:
  with urllib.request.urlopen(urllib.request.Request(r['source'],headers=headers),timeout=30) as response:
   page=response.read().decode('utf8');r['pageStatus']=response.status
  if r['licenseUrl'].replace('https:','') not in page:raise RuntimeError('Expected live license link absent')
  r['liveLicenseLinkVerified']=True;r['checked']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  urls=[html.unescape(s) for s in re.findall(r'(?:href|src)="([^"]+)"',page)]
  originals=[u for u in urls if 'upload.wikimedia.org/wikipedia/commons/' in u and '/thumb/' not in u and '/transcoded/' not in u and urllib.parse.unquote(urllib.parse.urlparse(u).path).endswith('/'+r['name'])]
  if not originals:raise RuntimeError('No original direct media URL in source page')
  r['downloadUrl']=originals[0]
  target=Path(r['file']);temp=Path(r['file']+'.part');sha=hashlib.sha256();size=0
  with urllib.request.urlopen(urllib.request.Request(r['downloadUrl'],headers=headers),timeout=60) as response:
   r['downloadStatus']=response.status
   with temp.open('wb') as f:
    while True:
     chunk=response.read(1024*1024)
     if not chunk:break
     f.write(chunk);sha.update(chunk);size+=len(chunk)
  r['bytes']=size;r['sha256']=sha.hexdigest()
  if r['sha256']!=r['expectedSha256']:raise RuntimeError('Downloaded original differs from the exact previously documented source hash')
  temp.replace(target);r['status']='exact-original-recovered'
 except Exception as e:r['status']='not-recovered';r['error']=str(e)
 print(json.dumps({k:r.get(k) for k in ['id','status','pageStatus','downloadStatus','bytes','sha256','error']}),flush=True)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(get,records))
notice='Exact previously documented real counterexample inputs recovered for the unchanged optional calibration test. Media remain privately outside the repository, assets, fixtures, outputs, and evidence branch. Only numeric test evidence and these public source/license/checksum records may be published.'
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'notice':notice,'results':results};Path('/workspace/work/v3d-r5/session/private-calibration-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
if not all(r['status']=='exact-original-recovered' for r in results):raise SystemExit(1)
(root/'manifest.json').write_text(json.dumps(results,indent=2)+'\n');print('All three exact original hashes match; private manifest ready.')
