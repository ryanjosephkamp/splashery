// MIT. Work-only exact uint8 SIFT SIMD prototype, made by Ryan with Codex (GPT-6).
// No production module imports this file. Every invocation owns its memory.
export function createMatcher(module) {
 const counters={calls:0,queries:0,backend:'wasm-simd128'};
 function inputs(a,na,b,nb) {
  const {exports:e}=new WebAssembly.Instance(module),ob=na*128,out=ob+nb*128;
  const pages=Math.ceil((out+16)/65536);if(pages>1)e.memory.grow(pages-1);
  const bytes=new Uint8Array(e.memory.buffer);bytes.set(a,0);bytes.set(b,ob);
  counters.calls++;
  return {e,ob,out,view:new DataView(e.memory.buffer)};
 }
 const check=s=>{if(s?.aborted)throw new DOMException('SfM aborted','AbortError');};
 function row(ctx,pa,pb,nb,ratio){
  ctx.e.nearest(pa,pb,nb,ctx.out);counters.queries++;
  const bi=ctx.view.getInt32(ctx.out,true),v1=ctx.view.getUint32(ctx.out+4,true),v2=ctx.view.getUint32(ctx.out+8,true);
  const b1=v1===0xffffffff?Infinity:v1,b2=v2===0xffffffff?Infinity:v2;
  return bi>=0&&b1<ratio*ratio*b2?bi:-1;
 }
 function result(ab,ba){const res=[];for(let a=0;a<ab.length;a++){const b=ab[a];if(b>=0&&ba[b]===a)res.push(a,b);}return res;}
 function matchSift(a,na,b,nb,ratio=.8){
  const ctx=inputs(a,na,b,nb),ab=new Int32Array(na),ba=new Int32Array(nb);
  for(let i=0;i<na;i++)ab[i]=row(ctx,i*128,ctx.ob,nb,ratio);
  for(let i=0;i<nb;i++)ba[i]=row(ctx,ctx.ob+i*128,0,na,ratio);
  return result(ab,ba);
 }
 async function matchSiftAsync(a,na,b,nb,ratio=.8,{signal}={}){
  check(signal);const ctx=inputs(a,na,b,nb),ab=new Int32Array(na),ba=new Int32Array(nb);let next=performance.now()+32;
  async function best(output,pa,pb,n){for(let i=0;i<output.length;i++){
   check(signal);output[i]=row(ctx,pa+i*128,pb,n,ratio);
   if(performance.now()>=next){await new Promise(r=>setTimeout(r,0));check(signal);next=performance.now()+32;}
  }}
  await best(ab,0,ctx.ob,nb);await best(ba,ctx.ob,0,na);check(signal);return result(ab,ba);
 }
 return {matchSift,matchSiftAsync,stats:()=>({...counters})};
}
