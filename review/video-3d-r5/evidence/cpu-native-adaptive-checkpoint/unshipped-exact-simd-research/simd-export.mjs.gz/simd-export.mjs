// MIT. Work-only module; no production import.
import {createMatcher} from '/__r5-simd-factory.mjs';
const module=await WebAssembly.compile(await(await fetch('/__r5-simd-kernel.wasm')).arrayBuffer());
export const {matchSift,matchSiftAsync,stats}=createMatcher(module);
