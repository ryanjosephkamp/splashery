// MIT. Work-only exact integer matcher checks, made by Ryan with Codex (GPT-6).
import fs from 'node:fs';import assert from 'node:assert/strict';import {createHash}from'node:crypto';
import {createMatcher}from'./matcher.mjs';import {matchSift}from'/workspace/splashery/vendor/splatjs/src/sfm/sift.js';
const hash=b=>createHash('sha256').update(b).digest('hex'),kernels=['nearest','nearest-dot'],result=[];
for(const name of kernels){const bytes=fs.readFileSync(new URL('./'+name+'.wasm',import.meta.url)),module=new WebAssembly.Module(bytes),m=createMatcher(module);let seed=42,cases=0;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed>>>24;};
for(const[na,nb]of[[0,0],[0,2],[2,0],[1,1],[1,2],[2,1],[2,2],[31,33],[63,65],[65,129]])for(const kind of['random','max','ties']){
const a=Uint8Array.from({length:na*128},()=>kind==='ties'?12:kind==='max'?255:rnd()),b=Uint8Array.from({length:nb*128},()=>kind==='ties'?12:kind==='max'?0:rnd());if(kind==='random')for(let i=0;i<Math.min(na,nb);i+=4)b.set(a.subarray(i*128,i*128+128),i*128);const before=[hash(a),hash(b)];
for(const ratio of[0,.2,.5,.8,.8-1e-15,.8+1e-15,1,1.1,Infinity,NaN]){const expected=matchSift(a,na,b,nb,ratio);assert.deepEqual(m.matchSift(a,na,b,nb,ratio),expected);assert.deepEqual(await m.matchSiftAsync(a,na,b,nb,ratio),expected);cases+=2;}assert.deepEqual([hash(a),hash(b)],before);
}
const controller=new AbortController();controller.abort();let reads=0;const bad=new Proxy({}, {get(){reads++;throw Error('Read pre-aborted input');}});await assert.rejects(m.matchSiftAsync(bad,1,bad,1,.8,{signal:controller.signal}),{name:'AbortError'});assert.equal(reads,0);
const raw=new WebAssembly.Instance(module).exports,mem=new Uint8Array(raw.memory.buffer);mem.fill(255,0,128);raw.nearest(0,128,1,256);assert.equal(new DataView(raw.memory.buffer).getUint32(260,true),8323200);
const na=193,nb=197,a=Uint8Array.from({length:na*128},rnd),b=Uint8Array.from({length:nb*128},rnd);for(let i=0;i<na;i+=3)b.set(a.subarray(i*128,i*128+128),i*128);const expected=matchSift(a,na,b,nb);const values=await Promise.all(Array.from({length:5},()=>m.matchSiftAsync(a,na,b,nb)));values.forEach(v=>assert.deepEqual(v,expected));
result.push({kernel:name,kernelSha256:hash(bytes),exactVariantComparisons:cases,inputsUnchanged:true,preAbortBeforeInputAccess:true,exactMaxDistance:8323200,concurrentInvocationsExact:5,stats:m.stats()});}
const record={at:new Date().toISOString(),notice:'Work-only exact SIMD property checks, no production edits or native result promotion.',result};fs.writeFileSync(new URL('./property-check.json',import.meta.url),JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));
