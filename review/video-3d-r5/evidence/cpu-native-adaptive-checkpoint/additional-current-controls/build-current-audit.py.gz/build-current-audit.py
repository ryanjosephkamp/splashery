# MIT. Read-only report builder for the frozen source cohort; no result is rewritten.
from pathlib import Path
import datetime,json
ROOT=Path('/workspace/work/v3d-r5');S=ROOT/'session';COL=ROOT/'final-run/session-cpu-matcher'
base=S/'audit-template.md'
if not base.exists():base.write_bytes((S/'audit-next.md').read_bytes())
old=base.read_text();body=old[old.index('## Implementation and controls'):]
body=body.replace('A predeclared fresh protocol-6 upload waits for the complete phone media window.', 'A predeclared fresh protocol-6 upload uses a separate output and core after phone media. Its actual terminal outcome is retained without promotion into protocol 5. A visible bake rejection does not establish that its post-bake verifier ran.')
body=body.replace('Extra one-core desktop lanes wait until phone timing and review rendering finish. A separate\nfuture control reserves core 0 until its actual native outcome is terminal.', 'After phone timing and review rendering, four adaptive workers claim a ready candidate or the next unrun baseline. Each native upload keeps its original one-core allocation and deadline. Core 0 first belongs to the separate protocol-6 native control until its actual outcome is terminal. No completed or timed-out original baseline is rerun.')
body=body.replace('Stills do not establish motion quality; ten\nsource-bound phone movies and their exact saved-pixel checks remain pending.', 'Actual movie status and exact saved-pixel checks are reported in the gate table. The original whole-profile ranking requirement remains unmet if either inventory has an unaccounted outcome.')
body+='\nThe continuation coordinator was replaced only after the original desktop lanes were idle. An initial setup-lifetime error was corrected by detaching the coordinator; the same already-running native upload was adopted with its original PID, source, timing, and allocation. Original controller records are archived. An independent identity-checked guard stops owned native processes at 13:29 UTC and preserves unfinished rows as incomplete.\n'
d=json.loads((COL/'native-ledger.json').read_text());p=d['profiles']['phone'];q=d['profiles']['desktop']
ci=[]
for f in S.glob('cpu-ci-attempt*-summary.json'):
 try:
  row=json.loads(f.read_text())
  if isinstance(row.get('attempt'),int) and all(k in row for k in ['passed','failed','tests','specs']):ci.append(row)
 except (ValueError,OSError):pass
latest=max(ci,key=lambda x:x['attempt'])
reviewFile=ROOT/'final-run/cpu-matcher-phone-review/review.json'
review=json.loads(reviewFile.read_text()) if reviewFile.exists() else {}
movieCount=review.get('capturedClips',0)
clean={}
for version in ['main','candidate']:
 file=ROOT/f'final-run/phone-timing-control-{version}/run.json'
 if file.exists():
  results=json.loads(file.read_text()).get('results',[])
  if results:clean[version]=results[0]
fmt=lambda n,digits=3:format(n,'.'+str(digits)+'f') if isinstance(n,(int,float)) else '—'
phoneTimes=p['diagnosticTiming'];strict=sum(x['strictPairedOutcomes'] for x in d['profiles'].values())
ciText=f"Latest completed normal integration: {latest['specs']} spec files, {latest['tests']:,} tests; {latest['passed']:,} passed, {latest['failed']} failed, and {latest.get('existingSkipped',1)} preexisting conditional skip."
head=f"""# Video to 3D, round 5

Built by Codex (GPT-6) for task 94. Rule check: none.

Current native snapshot: {d['at']}. The bounded Goal ends October 16, 2026, at 13:30 UTC.
Complete acceptance has **not** been established. Partial measurements do not pass a corpus gate.

The initial main baseline is `5a55f5ccc25ebfa155e5db2391236558feb551ec`.
The measured candidate is `f1f7f339d0d5d325c57dac8ade18442c4b0bc4ac`, with runtime fingerprint
`e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571`.
The immutable protocol-5 evaluator is `0406a781ea6d822faefecd02154883ecf726a739`.
Every original source, held-out count rule, numerical threshold, training tier, budget, and assertion remains.
All current candidate cases are fresh; exact original main outcomes, including failures, are retained.

## Task 88 gates and current evidence

| Gate | Task 88 before | Current R5 evidence |
| --- | --- | --- |
| Phone quality | 11 diagnostic pairs, 4.75773 times sharpness, +0.103364 SSIM; corpus acceptance false | {p['qualityPairs']} verified pairs, {fmt(p['diagnosticSharpnessRatio'],6)} times median sharpness, +{fmt(p['diagnosticSsimGain'],6)} SSIM; corpus acceptance remains false |
| Desktop quality | Zero strict quality pairs | {q['qualityPairs']} strict quality pairs; acceptance not established |
| Phone speed | Complete median and worst unavailable | {p['qualityPairs']} verified finished pairs: first-view median {fmt(phoneTimes['firstViewMs']['mainMedian']/1000)} to {fmt(phoneTimes['firstViewMs']['candidateMedian']/1000)} seconds; bake median {fmt(phoneTimes['bakeMs']['mainMedian']/1000)} to {fmt(phoneTimes['bakeMs']['candidateMedian']/1000)} seconds; original global acceptance remains false |
| Every clip has an outcome | 18/40 strict paired outcomes, with 22 raw unpaired rows | {d['candidateCompleted']}/40 current candidate terminal rows, {d['candidateAccounted']} accounted, and {strict} strict paired outcomes; original errors and pending rows remain |
| Six samples keep their gains | All 74 views preserved across both profiles | PASS: all 12 sample/profile pairs and all 74 exact, nonblank views retained; 37 per profile |
| Every existing spec passes | 2,914 passed, five failed, one existing skip | {latest['passed']:,} passed, {latest['failed']} failed, and one preexisting conditional CI skip; complete unchanged local calibration 12/12 passed with zero skipped |
| Ten phone movies | Zero source-bound verified movies | {movieCount}/10 captured source-bound movies; original full-profile five-worst/five-best ranks remain unavailable because main Fjoloy is unaccounted |

The targets remain 1.5 times median sharpness and +0.03 SSIM at **both** profiles.
R4 never established a complete corpus pass, so no additional 10% improvement is claimed.
The unchanged production comparator requires complete compatible evidence across its full cohort
before either profile passes quality or speed. A completed phone subset cannot bypass this rule.
A phone timing pass also requires every finished main case to finish in the candidate.

Current paired phone timing diagnostics, in seconds:

| Measure | Main median | R5 median | Main worst | R5 worst |
| --- | ---: | ---: | ---: | ---: |
"""
for key,title in [('firstViewMs','First 3D view'),('bakeMs','Bake')]:
 t=phoneTimes[key];head+='| '+title+' | '+' | '.join(fmt(t[k]/1000) if t[k] is not None else '—' for k in ['mainMedian','candidateMedian','mainWorst','candidateWorst'])+' |\n'
head+=f"\nAll {p['candidateAccounted']}/20 candidate phone clips are accounted for. All fourteen finished main phone cases also finish in R5. Main Fjoloy retains two uncaught null-input worker errors during relaxed retry; R5 retains its inputs and gives visible two-camera advice. That baseline product failure stays unpaired and blocks complete-profile ranking. Phone observations do not waive any desktop failure or the comparator's complete global cohort requirement.\n"
if set(clean)=={'main','candidate'} and all(r.get('status')=='finished' for r in clean.values()):
 head+='\nThe separate clean cat phone control ran each version alone on the same two cores, without concurrent timed desktop work. First view: '+ ' to '.join(fmt(clean[v]['firstViewMs']/1000) for v in ['main','candidate'])+' seconds; bake: '+ ' to '.join(fmt(clean[v]['bakeMs']/1000) for v in ['main','candidate'])+' seconds. Both original native outcomes and verifier records are retained. This single control replaces no corpus row and establishes no complete-cohort pass.\n'
else:head+='\nThe separate clean phone control remains pending or did not finish; see its original native outcome.\n'
head+='\n## Original native per-clip results\n\nOnly verified finished rows receive completed timing and image values below. Host timeouts and\npost-bake verifier errors retain their original status and censored timing in the raw records.\nPeak RSS is the host process measurement in MiB, not a physical-phone memory measurement.\nIndependent unpaired image scores, if any, cannot establish a comparative gain.\n\n'
lookup=lambda rows,ident,profile:next((r['row'] for r in rows if r['row']['id']==ident and r['row']['profile']==profile),{})
clips=json.loads((Path('/workspace/splashery')/'tools/v3d-corpus.json').read_text())
for profile in ['phone','desktop']:
 head+='### '+profile.capitalize()+'\n\n| Clip | Main / R5 status | SSIM main / R5 | Sharpness main / R5 | First view seconds main / R5 | Bake seconds main / R5 | Peak RSS MiB main / R5 |\n| --- | --- | --- | --- | --- | --- | --- |\n'
 for clip in clips:
  a=lookup(d['main'],clip['id'],profile);b=lookup(d['candidate'],clip['id'],profile)
  score=lambda r,key:fmt(r.get('mean',{}).get(key),6) if r.get('status')=='finished' and r.get('mean') else '—'
  time=lambda r,key:fmt(r.get(key)/1000,1) if r.get('status')=='finished' and r.get(key) is not None else '—'
  rss=lambda r:fmt(r['peakRssBytes']/1024**2,1) if r.get('peakRssBytes') is not None else '—'
  head+='| '+clip['id']+' | '+a.get('status','pending')+' / '+b.get('status','pending')+' | '+score(a,'ssim')+' / '+score(b,'ssim')+' | '+score(a,'laplacian')+' / '+score(b,'laplacian')+' | '+time(a,'firstViewMs')+' / '+time(b,'firstViewMs')+' | '+time(a,'bakeMs')+' / '+time(b,'bakeMs')+' | '+rss(a)+' / '+rss(b)+' |\n'
 head+='\n'
head+='## Original candidate failures and visible explanations\n\n| Clip and profile | Original status | Original reason or visible advice |\n| --- | --- | --- |\n'
for r in d['candidate']:
 row=r['row']
 if row['status']=='finished':continue
 reason=str(row.get('reason') or row.get('explanation') or 'See the unchanged raw outcome.').splitlines()[0].replace('|','\\|')
 head+='| '+row['id']+' / '+row['profile']+' | '+row['status']+' | '+reason+' |\n'
head+='\nThe first phone lens bake finished, but protocol 5 missed the independent callback at 1.458333 seconds. A separate decoder matched all sixteen actual input JPEGs and all four exact frozen main held-outs, including that time. The predeclared single actual native retry finished at 11:03 UTC and passed every original verifier assertion. Its original error, run, and model remain archived; the replacement is a fresh verified outcome, never a diagnostic promotion.\n\nThe desktop palace bake also finished, but its fourth required camera-time group contains no eligible source frame under the full-frame exclusion distance. Fifteen input JPEGs and twelve globally eligible pictures are independently verified. Borrowing another group’s picture would violate an existing assertion, so the original failure remains without a score.\n\n'
extra='\n## Complete existing checks and private calibration\n\n'+ciText+'\nAll normal failures and isolated rechecks remain evidence. Passing alone does not waive a normal\nfailure. Reused normal results retain their original execution timestamps. The remaining wide-panel\nresizing failure is independently present on newer main; the earlier depth-drift failure is also\npresent on the initial baseline. Those facts do not waive any current failure.\n\nThe three exact original private Commons counterexamples were recovered under their recorded\nlicenses and match all original whole-file hashes. The unchanged full calibration spec passed\n12 cases, with zero skips and zero retries, in 36.85 seconds through its existing manifest hook.\nNo private media, screenshot, trace, or detailed private report is published.\n\n[Exact source and native checkpoint](https://github.com/ryanjosephkamp/splashery/tree/b812f82a95a4cdf206825104186474d8c7916752/review/video-3d-r5/evidence/cpu-native-source-checkpoint)\ncontains 433 lossless originals and 49 outcomes at 09:33 UTC, the exact phone-lens decoder proof,\ncanonical partial production join/comparison, and actual existing-main CI failure summaries.\nLater results are not inserted retroactively into that immutable snapshot.\n\n## Unshipped exact SIMD experiment\n\nThe work-only SIMD prototype preserves squared integer distances, nearest-two ties, JavaScript\nratio semantics, reciprocal matches, output order, and ordinary timer cancellation. It passed\n600 synthetic variant comparisons and the actual-browser real-descriptor controls. Two licensed\nreal descriptor sets ran about five to six times faster; real browser cancellation took 39 ms.\nThe first camera wrapper stalled before matching and reached the unchanged camera deadline.\nA separate inline wrapper removed its auxiliary module-loading dependency. All original attempts\nremain. No threshold or original deadline changed.\n\nThe corrected flower camera control solved all 17 cameras and 5,257 points in 148.049 seconds,\nagainst the earlier cooperative control’s 229.745 seconds. All input JPEG receipts, attempted\ntimes, and camera parameters are exactly identical. All 136 pairs remain. The earlier independent\nproof binds to the same seventeen inputs and four held-outs. This is a 36% whole-control reduction,\nnot a native bake, corpus quality score, physical-phone timing, or five-times whole-solve claim.\nThe production source and native cohort remain unchanged. A harder landscape control is separate.\n'
extra=extra.replace('600 synthetic variant comparisons', '600 synthetic variant comparisons per kernel (1,200 total)')
extra=extra.replace('solved all 17 cameras and 5,257 points', 'solved all 17 cameras with a point count of 5,257')
extra=extra.replace('The production source and native cohort remain unchanged. A harder landscape control is separate.', 'Individual point coordinates were not compared. The production source and native cohort remain unchanged. Both landscape variants matched all 435 pairs and 2,360,252 descriptor queries with identical input receipts, but failed the unchanged camera deadline before a finished solve. Neither has a native model or quality score. All failed attempts remain; no SIMD implementation is shipped.')
(S/'audit-next.md').write_text(head+body+extra)
assert len(clips)==20
print(json.dumps({'nativeSnapshot':d['at'],'main':d['mainCompleted'],'candidate':d['candidateCompleted'],'strict':strict,'caseRows':40,'ciAttempt':latest['attempt'],'draft':str(S/'audit-next.md')}))
