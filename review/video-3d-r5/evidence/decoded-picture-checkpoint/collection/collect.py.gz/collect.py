import concurrent.futures,datetime,hashlib,json,os,signal,subprocess,threading,time,traceback
from pathlib import Path
REPO=Path('/workspace/splashery')
ROOT=Path('/workspace/work/v3d-r5/final-run')
SESSION=ROOT/'session-decoded-picture'
CLIPS=json.loads((REPO/'tools/v3d-corpus.json').read_text())
LANES=json.loads((SESSION/'cpu-lanes.json').read_text())
DEADLINE=datetime.datetime(2026,10,16,13,29,tzinfo=datetime.timezone.utc).timestamp()
lock=threading.RLock()
state={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadline':DEADLINE,'candidateCommit':os.environ['V3D_CANDIDATE_COMMIT'],'baselineCommit':'5a55f5ccc25ebfa155e5db2391236558feb551ec','lanes':LANES,'main':[],'strictCandidate':[],'unpairedCandidate':[],'active':{},'events':[],'snapshots':0}

def record(event,**data):
 with lock:
  item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**data}
  state['events'].append(item)
  tmp=SESSION/'collection-state.json.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');os.replace(tmp,SESSION/'collection-state.json')
  with (SESSION/'collection-events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
  print(json.dumps(item),flush=True)

def processes():
 result={}
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   fields=(path/'stat').read_text().rsplit(')',1)[1].split()
   result[int(path.name)]={'ppid':int(fields[1]),'startTicks':fields[19],'status':fields[0]}
  except (OSError,IndexError,ValueError):pass
 return result

def descendants(root,table):
 owned={root};changed=True
 while changed:
  changed=False
  for pid,item in table.items():
   if item['ppid'] in owned and pid not in owned:owned.add(pid);changed=True
 return owned

def command(args,log,cores,tag):
 if time.time()>=DEADLINE:raise TimeoutError('Goal deadline reached before launch')
 current=hashlib.sha256((REPO/'tools/v3d-affinity.py').read_bytes()).hexdigest()
 if current!=os.environ['V3D_AFFINITY_SHA256']:raise RuntimeError('Affinity launcher changed after freeze')
 argv=['python3','tools/v3d-affinity.py',','.join(map(str,cores)),'--',*map(str,args)]
 env=dict(os.environ,SPLASHERY_CHROMIUM='/usr/bin/chromium',OMP_NUM_THREADS=str(len(cores)))
 adopted=ADOPTED.pop(tag,None)
 observed={int(pid):ticks for pid,ticks in adopted.get('owned',{}).items()} if adopted else {}
 violations=[];last_audit=time.time();p=None;exit_code=None
 def observe(audit=False):
  table=processes()
  for pid in descendants(root_pid,table):
   if pid in table:observed[pid]=table[pid]['startTicks']
  if audit:
   for pid,start in list(observed.items()):
    if table.get(pid,{}).get('startTicks')!=start:continue
    try:
     for tid in (Path('/proc')/str(pid)/'task').iterdir():
      try:
       allowed=os.sched_getaffinity(int(tid.name))
       if not allowed<=set(cores):violations.append({'pid':pid,'tid':int(tid.name),'allowed':sorted(allowed)})
      except (ProcessLookupError,FileNotFoundError):pass
    except FileNotFoundError:pass
  return table
 def live_owned():
  table=processes()
  return [pid for pid,start in observed.items() if table.get(pid,{}).get('startTicks')==start and table[pid]['status']!='Z']
 def stop_owned(reason):
  remaining=live_owned();record(reason,tag=tag,pids=remaining)
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   for pid in remaining:
    try:os.kill(pid,sig)
    except ProcessLookupError:pass
   end=time.time()+2
   while time.time()<end and live_owned():time.sleep(.1)
   remaining=live_owned()
   if not remaining:break
  if remaining:record('owned-processes-still-live',tag=tag,pids=remaining)
 if adopted:
  if adopted['cores']!=cores or str(args[5]) not in adopted['argv']:raise RuntimeError('Adopted command identity differs: '+tag)
  root_pid=adopted['pid'];root_ticks=adopted['startTicks'];log=adopted['log'];observed[root_pid]=root_ticks
  record('adopt-native-command',tag=tag,pid=root_pid,startTicks=root_ticks,log=log,cores=cores,notice='Original native command, output, source, timeout, and CPU mask remain unchanged.')
 else:
  with Path(log).open('w') as stream:p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  root_pid=p.pid;root_ticks=processes().get(root_pid,{}).get('startTicks')
  record('launch',tag=tag,pid=root_pid,log=str(log),cores=cores,affinitySha256=current)
 with lock:state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':adopted['argv'] if adopted else argv,'log':str(log),'cores':cores,'adopted':bool(adopted)}
 record('active-native-command',tag=tag,pid=root_pid)
 while True:
  if p:
   if p.poll() is not None:exit_code=p.returncode;break
  else:
   table=processes();item=table.get(root_pid)
   if not item or item['startTicks']!=root_ticks or item['status']=='Z':
    if adopted.get('receipt'):
     try:exit_code=json.loads(Path(adopted['receipt']).read_text()).get('exitCode')
     except (OSError,ValueError):pass
    break
  now=time.time();observe(audit=now-last_audit>=5)
  if now-last_audit>=5:last_audit=now
  if now>=DEADLINE:
   stop_owned('deadline-interruption')
   if p:exit_code=p.wait(timeout=10)
   break
  time.sleep(.5)
 if live_owned():stop_owned('post-terminal-browser-cleanup')
 with lock:state['active'].pop(tag,None)
 record('exit',tag=tag,pid=root_pid,code=exit_code,exitCodeKnown=exit_code is not None,adopted=bool(adopted),affinityViolations=violations,observedProcesses=len(observed))
 if violations:raise RuntimeError('CPU placement escaped: '+str(violations))
 return exit_code

def alias(source,target):
 tmp=Path(str(target)+'.tmp')
 if tmp.is_symlink():tmp.unlink()
 tmp.symlink_to(source,target_is_directory=True);os.replace(tmp,target)

def publish_main():
 with lock:
  sources=[Path(p) for p in state['main']]
  if len(sources)==1:alias(sources[0],ROOT/'main-reference');return
  state['snapshots']+=1
  target=ROOT/f'main-snapshot-{state["snapshots"]:03d}'
  result=subprocess.run(['taskset','-c',str(LANES['research'][0]),'node','tools/v3d-bench-join.mjs','tools/v3d-corpus.json',str(target),*map(str,sources)],cwd=REPO,capture_output=True,text=True)
  (SESSION/f'join-main-{state["snapshots"]:03d}.log').write_text(result.stdout+result.stderr)
  if result.returncode:raise RuntimeError('Baseline join failed: '+result.stderr[-1000:])
  alias(target,ROOT/'main-reference')
  record('baseline-snapshot',output=str(target),cases=len(sources))

def accounted(row):
 return row.get('status')=='finished' and not row.get('consoleErrors') or row.get('status')=='explained' and row.get('reason','').strip() and row.get('explanation',{}).get('visible') is True and row.get('explanation',{}).get('diagnostic','').strip() and row.get('explanation',{}).get('advice','').strip() and not row.get('consoleErrors')

def one(version,profile,clip,index,cores,reference=None):
 group='main' if version=='main' else ('decoded-picture-strict-candidate' if reference else 'decoded-picture-unpaired-candidate')
 output=ROOT/'runs'/group/profile/f'{index:02d}-{clip["id"]}'
 existed=output.exists()
 args=['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',output,'--url=http://127.0.0.1:'+('4174/' if version=='main' else '4178/'),f'--profiles={profile}',f'--ids={clip["id"]}','--gpu=swiftshader']
 if reference:args.append('--reference='+str(ROOT/'main-reference'))
 tag=f'{version}-{profile}-{clip["id"]}'
 code=command(args,SESSION/(tag+'.log'),cores,tag) if not existed or tag in ADOPTED else None
 run_path=output/'run.json'
 if not run_path.exists():raise RuntimeError(f'No recorded run after {tag}; exit {code}')
 run=json.loads(run_path.read_text())
 rows=run.get('results',[])
 if len(rows)!=1:raise RuntimeError(f'Incomplete native case {tag}; exit {code}; rows {len(rows)}')
 row=rows[0]
 if row['id']!=clip['id'] or row['profile']!=profile or row['sha256']!=clip['sha256']:raise RuntimeError('Unexpected case identity')
 expected_source=FREEZE['baselineServedSourceSha256'] if version=='main' else FREEZE['candidateServedSourceSha256']
 if run['provenance']['servedSource']['sha256']!=expected_source or run['provenance']['protocolSha256']!=FREEZE['benchmarkProtocolSha256'] or row['provenanceSha256']!=run['provenanceSha256']:raise RuntimeError('Frozen source or protocol changed: '+str(output))
 with lock:
  bucket=state['main' if version=='main' else ('strictCandidate' if reference else 'unpairedCandidate')]
  already=str(output) in bucket
  if not already:bucket.append(str(output))
  record('outcome',version=version,profile=profile,id=clip['id'],status=row['status'],phase=row.get('phase'),bakeMs=row.get('bakeMs'),firstViewMs=row.get('firstViewMs'),mean=row.get('mean'),output=str(output))
 if version=='main' and not already:publish_main()
 return row

def candidate_join(label):
 with lock:
  sources=[Path(p) for p in state['strictCandidate']]
  target=ROOT/label
  if len(sources)<2:raise RuntimeError('Not enough strict candidate cases for a join')
  result=subprocess.run(['taskset','-c',str(LANES['research'][0]),'node','tools/v3d-bench-join.mjs','tools/v3d-corpus.json',str(target),*map(str,sources),'--reference='+str(ROOT/'main-reference')],cwd=REPO,capture_output=True,text=True)
  (SESSION/(label+'-join.log')).write_text(result.stdout+result.stderr)
  if result.returncode:raise RuntimeError('Candidate join failed: '+result.stderr[-1500:])
  record('candidate-snapshot',output=str(target),cases=len(sources))
  return target

def phone():
 for tag,item in list(ADOPTED.items()):
  if tag.startswith('main-phone-'):
   clip_id=tag.removeprefix('main-phone-')
   index,clip=next((i,c) for i,c in enumerate(CLIPS,1) if c['id']==clip_id)
   one('main','phone',clip,index,LANES['phone'])
 for index,clip in enumerate(CLIPS,1):
  row=one('main','phone',clip,index,LANES['phone'])
  one('candidate','phone',clip,index,LANES['phone'],reference=accounted(row))
 record('phone-native-complete')
 # Phone bakes have ended. Sample and review rendering use only the phone cores.
 for version,url in [('main','4174'),('candidate','4178')]:
  args=['node','tools/v3d-bench.mjs','samples',ROOT/('decoded-picture-samples-'+version),'--url=http://127.0.0.1:'+url+'/']
  if version=='candidate':args.append('--reference='+str(ROOT/'decoded-picture-samples-main'))
  code=command(args,SESSION/('samples-'+version+'.log'),LANES['phone'],'samples-'+version)
  if code:record('sample-replay-failure',version=version,code=code)
 snapshot=candidate_join('decoded-picture-phone-complete-candidate')
 main_run=json.loads((ROOT/'main-reference/run.json').read_text());candidate_run=json.loads((snapshot/'run.json').read_text())
 before={(r['id'],r['profile']):r for r in main_run['results']}
 after={(r['id'],r['profile']):r for r in candidate_run['results']}
 selected=[]
 for clip in CLIPS:
  a=before.get((clip['id'],'phone'),{});b=after.get((clip['id'],'phone'),{})
  if a.get('status')==b.get('status')=='finished' and a.get('heldoutEvidence',{}).get('complete') and b.get('heldoutEvidence',{}).get('complete') and a.get('frames') and [(f['time'],f['referenceSha256']) for f in a['frames']]==[(f['time'],f['referenceSha256']) for f in b.get('frames',[])]:selected.append(clip['id'])
 selected=selected[:10]
 planner=subprocess.run(['taskset','-c',str(LANES['research'][0]),'node','--input-type=module','-e',
  "import fs from 'node:fs'; import {reviewSelection} from './tools/v3d-review.mjs'; const read=p=>JSON.parse(fs.readFileSync(p,'utf8')); console.log(JSON.stringify(reviewSelection(read('tools/v3d-corpus.json'),read(process.argv[1]),read(process.argv[2]))));",
  str(ROOT/'main-reference/run.json'),str(snapshot/'run.json')],cwd=REPO,capture_output=True,text=True)
 (SESSION/'review-planner.log').write_text(planner.stdout+planner.stderr)
 if planner.returncode:raise RuntimeError('Existing review planner rejected the source-bound runs')
 plan=json.loads(planner.stdout);ranked=plan['ranked']
 if ranked:selected=[r['id'] for r in plan['selected']]
 (SESSION/'review-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 record('phone-review-selection',ids=selected,notice='Existing five-worst/five-best planner' if ranked else 'Manifest-order verified pairs; complete-profile ranks unavailable')
 if selected:
  args=['node','tools/v3d-review.mjs','render','tools/v3d-corpus.json',ROOT/'main-reference',snapshot,ROOT/'decoded-picture-phone-review','--profile=phone','--ids='+','.join(selected),'--seconds=5','--fps=10','--timeout=1200000','--size=390x844','--main-url=http://127.0.0.1:4174/','--candidate-url=http://127.0.0.1:4178/']
  if ranked:args=[a for a in args if not str(a).startswith('--ids=')]
  command(args,SESSION/'phone-review.log',LANES['phone'],'phone-review')
 record('phone-review-phase-complete')

def desktop_main():
 for index,clip in enumerate(CLIPS,1):one('main','desktop',clip,index,LANES['desktopMain'])
 record('desktop-main-complete')

def desktop_candidate():
 for index,clip in enumerate(CLIPS,1):
  source=ROOT/'runs/main/desktop'/f'{index:02d}-{clip["id"]}'/'run.json'
  while time.time()<DEADLINE:
   try:
    run=json.loads(source.read_text());rows=run['results']
    if len(rows)==1:
     # Wait until the immutable baseline snapshot advertises the same row.
     with lock:
      master=json.loads((ROOT/'main-reference/run.json').read_text())
      if any(r['id']==clip['id'] and r['profile']=='desktop' for r in master['results']):row=rows[0];break
   except (OSError,ValueError,KeyError):pass
   time.sleep(.25)
  else:raise TimeoutError('Goal deadline while waiting for desktop reference')
  one('candidate','desktop',clip,index,LANES['desktopCandidate'],reference=accounted(row))
 record('desktop-candidate-complete')

def safe(name,fn):
 try:fn()
 except Exception as e:record('lane-error',lane=name,error=str(e),traceback=traceback.format_exc())

FREEZE=json.loads((SESSION/'freeze.json').read_text())
ADOPTED=json.loads((SESSION/'takeover.json').read_text())['adopted']
# Index terminal main rows only. Failed outcomes are reused, never retried for favorable results.
state['main']=[str(p.parent) for p in sorted((ROOT/'runs/main').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
state['snapshots']=max([0]+[int(p.name.rsplit('-',1)[1]) for p in ROOT.glob('main-snapshot-[0-9][0-9][0-9]')])
for file,expected in FREEZE['files'].items():
 if hashlib.sha256((REPO/file).read_bytes()).hexdigest()!=expected:raise RuntimeError('Frozen evaluator changed: '+file)
if '--validate-only' in __import__('sys').argv:
 print(json.dumps({'mainTerminal':len(state['main']),'adopted':list(ADOPTED),'nextSnapshot':state['snapshots']+1,'candidateCommit':state['candidateCommit']}));raise SystemExit(0)
record('decoded-picture-candidate-start',protocolFilesSha256=os.environ['V3D_PROTOCOL_FILES_SHA256'],notice='Fresh candidate outputs on unchanged protocol 5. Exact existing baseline outcomes are reused; all superseded candidate rows remain separate diagnostics.')
if state['main']:publish_main()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(safe,name,fn) for name,fn in [('phone',phone),('desktop-main',desktop_main),('desktop-candidate',desktop_candidate)]]
 for f in futures:f.result()
record('native-collection-ended')
try:
 if len(state['strictCandidate'])>=2:candidate_join('decoded-picture-final-strict-candidate')
except Exception as e:record('final-join-error',error=str(e))
