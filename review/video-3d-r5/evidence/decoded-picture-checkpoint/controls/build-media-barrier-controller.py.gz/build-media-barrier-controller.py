# Prepare only; do not take over a live collector here.
from pathlib import Path
root=Path('/workspace/work/v3d-r5/final-run');source=root/'session-decoded-picture/collect.py';target=root/'session-isolated-media';target.mkdir(exist_ok=True)
s=source.read_text().replace("SESSION=ROOT/'session-decoded-picture'", "SESSION=ROOT/'session-isolated-media'")
s=s.replace('lock=threading.RLock()', 'lock=threading.RLock()\nMEDIA_REQUESTED=threading.Event()\nMEDIA_FINISHED=threading.Event()')
seam='def desktop_main():\n for index,clip in enumerate(CLIPS,1):one(\'main\',\'desktop\',clip,index,LANES[\'desktopMain\'])'
assert seam in s
s=s.replace(seam,'''def wait_for_media(tag):
 if tag in ADOPTED:return
 version,profile,clip_id=tag.split('-',2)
 index=next(i for i,c in enumerate(CLIPS,1) if c['id']==clip_id)
 groups=['main'] if version=='main' else ['decoded-picture-strict-candidate','decoded-picture-unpaired-candidate']
 for group in groups:
  path=ROOT/'runs'/group/profile/f'{index:02d}-{clip_id}'/'run.json'
  if path.exists() and len(json.loads(path.read_text()).get('results',[]))==1:return
 while MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set():
  if time.time()>=DEADLINE:raise TimeoutError('Goal deadline while waiting for isolated media')
  MEDIA_FINISHED.wait(.25)

def desktop_main():
 for index,clip in enumerate(CLIPS,1):
  wait_for_media('main-desktop-'+clip['id'])
  one('main','desktop',clip,index,LANES['desktopMain'])''')
s=s.replace("  one('candidate','desktop',clip,index,LANES['desktopCandidate'],reference=accounted(row))", "  wait_for_media('candidate-desktop-'+clip['id'])\n  one('candidate','desktop',clip,index,LANES['desktopCandidate'],reference=accounted(row))")
s=s.replace(" for index,clip in enumerate(CLIPS,1):\n  row=one('main','phone'", " for index,clip in enumerate(CLIPS,1):\n  if index>=19 and not MEDIA_REQUESTED.is_set():\n   MEDIA_REQUESTED.set();record('isolated-media-window-requested',phoneIndex=index)\n  row=one('main','phone'")
s=s.replace(" record('phone-native-complete')\n # Phone bakes have ended. Sample and review rendering use only the phone cores.", ''' record('phone-native-complete')
 MEDIA_REQUESTED.set()
 record('waiting-for-native-desktop-terminal-before-media')
 while True:
  with lock:active=[tag for tag in state['active'] if '-desktop-' in tag]
  inherited=[tag for tag in ADOPTED if '-desktop-' in tag]
  if not active and not inherited:break
  if time.time()>=DEADLINE:raise TimeoutError('Goal deadline before isolated media window')
  time.sleep(.25)
 record('isolated-media-window-start',notice='No timed desktop or phone bake remains active. Rendering and clean timing controls use the reserved phone cores.')
 # Predeclared clean timing confirmation. Both outcomes remain separate from corpus rows.
 clean_main=ROOT/'phone-timing-control-main'
 if clean_main.exists():raise RuntimeError('Refusing to repeat the predeclared clean main timing control')
 command(['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',clean_main,'--url=http://127.0.0.1:4174/','--profiles=phone','--ids=cat-plays','--gpu=swiftshader'],SESSION/'clean-timing-main.log',LANES['phone'],'clean-timing-main')
 clean_run=json.loads((clean_main/'run.json').read_text())
 if len(clean_run.get('results',[]))!=1:raise RuntimeError('Clean main timing control has no terminal native row')
 clean_paired=bool(accounted(clean_run['results'][0]))
 clean_candidate=ROOT/('phone-timing-control-candidate' if clean_paired else 'phone-timing-control-candidate-unpaired')
 if clean_candidate.exists():raise RuntimeError('Refusing to repeat the predeclared clean candidate timing control')
 args=['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',clean_candidate,'--url=http://127.0.0.1:4178/','--profiles=phone','--ids=cat-plays','--gpu=swiftshader']
 if clean_paired:args.append('--reference='+str(clean_main))
 command(args,SESSION/'clean-timing-candidate.log',LANES['phone'],'clean-timing-candidate')
 record('clean-phone-timing-controls-complete',main=str(clean_main),candidate=str(clean_candidate),paired=clean_paired,notice='Both original native outcomes are retained regardless of result. This control does not replace corpus rows or establish corpus acceptance.')
 # The clean timed controls have ended. Samples and movies now run with no timed bakes.
''')
s=s.replace(" record('phone-review-phase-complete')", " record('phone-review-phase-complete')\n MEDIA_FINISHED.set();record('isolated-media-window-released')")
s=s.replace(" except Exception as e:record('lane-error',lane=name,error=str(e),traceback=traceback.format_exc())", " except Exception as e:record('lane-error',lane=name,error=str(e),traceback=traceback.format_exc())\n finally:\n  if name=='phone':MEDIA_FINISHED.set()")
s=s.replace("state['snapshots']=max", """state['strictCandidate']=[str(p.parent) for p in sorted((ROOT/'runs/decoded-picture-strict-candidate').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
state['unpairedCandidate']=[str(p.parent) for p in sorted((ROOT/'runs/decoded-picture-unpaired-candidate').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
if len([p for p in state['strictCandidate']+state['unpairedCandidate'] if '/phone/' in p])>=18:MEDIA_REQUESTED.set()
if (ROOT/'decoded-picture-samples-main').exists():raise RuntimeError('Isolated-media takeover must happen before sample rendering starts')
state['snapshots']=max""")
s=s.replace("record('decoded-picture-candidate-start'", "record('isolated-media-orchestration-continuation'")
(target/'collect.py').write_text(s)
(target/'cpu-lanes.json').write_bytes((root/'session-decoded-picture/cpu-lanes.json').read_bytes())
(target/'PREPARED-NOT-RUN.md').write_text('''# Prepared scheduling continuation\n\nDo not run until a takeover receipt adopts all active native processes by PID and start ticks,\narchives the old controller state and source, and stops only that orchestration parent. The\ncurrent collector stays authoritative until then. Runtime 81b6524b and every protocol-5 evaluator\nfile remain frozen. Request the media window around candidate phone case 19, reuse every exact\nterminal outcome, let active desktop commands finish naturally, run the predeclared clean phone\ntiming pair, replay all samples, render the verified comparison movies, and resume desktop work.\nNo timed native bake may overlap sample or movie rendering. The deadline stays 13:29 UTC.\n''')
print(target/'collect.py')
