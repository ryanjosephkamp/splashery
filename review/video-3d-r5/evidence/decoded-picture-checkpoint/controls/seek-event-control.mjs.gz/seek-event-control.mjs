import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import { chromium } from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import { benchmarkLaunchArgs } from '/workspace/splashery/tools/v3d-bench.mjs';
import { sourceFrameReceipts } from '/workspace/splashery/tools/v3d-bench-pixels.mjs';
const file='/workspace/work/v3d-r5/corpus/cat-plays.mp4', base64=fs.readFileSync(file).toString('base64');
const meta=JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time','-of','json',file],{encoding:'utf8'}));
const sourceTimes=meta.frames.map(f=>Number(f.best_effort_timestamp_time));
let body=fs.readFileSync('/workspace/work/v3d-r5/candidate-v5/src/video3d/extract.js','utf8');
const seam='        if (done) return;\n        if (\n          seekedAt === null';
if(!body.includes(seam)) throw Error('Instrumentation seam changed');
body=body.replace(seam,`        if (done) return;
        const canvas = document.createElement('canvas'); canvas.width=270; canvas.height=480;
        canvas.getContext('2d').drawImage(video,0,0,270,480);
        const receipt={requestedTime:time, time:metadata.mediaTime, presentedTime:metadata.mediaTime, width:270,height:480, seeking:video.seeking, seekedAt, currentTime:video.currentTime, metadata:{...metadata}};
        globalThis.__seekTrace.push(receipt);
        globalThis.__seekHashes.push(new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.92)).then(async blob=>{receipt.sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');}));
        if (
          seekedAt === null`);
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});
try {
 const page=await browser.newPage(); await page.route('**/src/video3d/extract.js',r=>r.fulfill({contentType:'text/javascript',body}));
 await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const trace=await page.evaluate(async base64=>{
  globalThis.__seekTrace=[];globalThis.__seekHashes=[];
  const {openVideo,seekPresented,closeVideo}=await import('/src/video3d/extract.js');
  const opened=await openVideo(new File([Uint8Array.from(atob(base64),c=>c.charCodeAt(0))],'cat-plays.mp4'));
  try {for(const t of [.083,.25,.417]) await seekPresented(opened.video,t);await Promise.all(globalThis.__seekHashes);return globalThis.__seekTrace;} finally {closeVideo(opened);}
 },base64);
 const proof=await page.evaluate(sourceFrameReceipts,{base64,sourceTimes,times:[],trainingFrames:trace,crop:{sx:0,sw:270}});
 const result={notice:'Read-only diagnostic of actual callback-time JPEGs; unchanged frozen production extractor, instrumented in an isolated page. No native outcome or timing is changed.',trace,proof};
 fs.writeFileSync('/workspace/work/v3d-r5/session/seek-event-control.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(trace.map((r,i)=>({request:r.requestedTime,callback:r.presentedTime,actualJpegTime:proof.matchedTraining[i].sourceTime,seeking:r.seeking,seekedAt:r.seekedAt,presentationTime:r.metadata.presentationTime}))));
} finally {await browser.close();}
