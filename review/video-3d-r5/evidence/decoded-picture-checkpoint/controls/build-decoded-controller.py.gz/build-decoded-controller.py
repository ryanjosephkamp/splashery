from pathlib import Path
root=Path('/workspace/work/v3d-r5/final-run');session=root/'session-decoded-picture';session.mkdir(exist_ok=True)
s=(root/'session/collect.py').read_text()
s=s.replace('SESSION=ROOT/\'session\'','SESSION=ROOT/\'session-decoded-picture\'')
s=s.replace("'strict-candidate' if reference else 'unpaired-candidate'", "'decoded-picture-strict-candidate' if reference else 'decoded-picture-unpaired-candidate'")
s=s.replace("else '4177/'", "else '4178/'").replace("('candidate','4177')", "('candidate','4178')").replace('127.0.0.1:4177/','127.0.0.1:4178/')
s=s.replace(" if output.exists():raise RuntimeError('Refusing to overwrite '+str(output))", " existed=output.exists()")
s=s.replace(" code=command(args,SESSION/(tag+'.log'),cores,tag)", " code=command(args,SESSION/(tag+'.log'),cores,tag) if not existed or tag in ADOPTED else None")
s=s.replace(" if row['id']!=clip['id'] or row['profile']!=profile:raise RuntimeError('Unexpected case identity')", """ if row['id']!=clip['id'] or row['profile']!=profile or row['sha256']!=clip['sha256']:raise RuntimeError('Unexpected case identity')
 expected_source=FREEZE['baselineServedSourceSha256'] if version=='main' else FREEZE['candidateServedSourceSha256']
 if run['provenance']['servedSource']['sha256']!=expected_source or run['provenance']['protocolSha256']!=FREEZE['benchmarkProtocolSha256'] or row['provenanceSha256']!=run['provenanceSha256']:raise RuntimeError('Frozen source or protocol changed: '+str(output))""")
s=s.replace("  state['main' if version=='main' else ('strictCandidate' if reference else 'unpairedCandidate')].append(str(output))", """  bucket=state['main' if version=='main' else ('strictCandidate' if reference else 'unpairedCandidate')]
  already=str(output) in bucket
  if not already:bucket.append(str(output))""")
s=s.replace(" if version=='main':publish_main()", " if version=='main' and not already:publish_main()")
start=s.index('def command(');end=s.index('\ndef alias(',start)
s=s[:start]+'''def command(args,log,cores,tag):
 if time.time()>=DEADLINE:raise TimeoutError('Goal deadline reached before launch')
 current=hashlib.sha256((REPO/'tools/v3d-affinity.py').read_bytes()).hexdigest()
 if current!=os.environ['V3D_AFFINITY_SHA256']:raise RuntimeError('Affinity launcher changed after freeze')
 argv=['python3','tools/v3d-affinity.py',','.join(map(str,cores)),'--',*map(str,args)]
 env=dict(os.environ,SPLASHERY_CHROMIUM='/usr/bin/chromium',OMP_NUM_THREADS=str(len(cores)))
 adopted=ADOPTED.pop(tag,None)
 observed={int(pid):ticks for pid,ticks in adopted.get('owned',{}).items()} if adopted else {}
 violations=[];last_audit=time.time();p=None;exit_code=None
 def observe(audit=False):
  table=processes()
  for pid in descendants(root_pid,table):
   if pid in table:observed[pid]=table[pid]['startTicks']
  if audit:
   for pid,start in list(observed.items()):
    if table.get(pid,{}).get('startTicks')!=start:continue
    try:
     for tid in (Path('/proc')/str(pid)/'task').iterdir():
      try:
       allowed=os.sched_getaffinity(int(tid.name))
       if not allowed<=set(cores):violations.append({'pid':pid,'tid':int(tid.name),'allowed':sorted(allowed)})
      except (ProcessLookupError,FileNotFoundError):pass
    except FileNotFoundError:pass
  return table
 def live_owned():
  table=processes()
  return [pid for pid,start in observed.items() if table.get(pid,{}).get('startTicks')==start and table[pid]['status']!='Z']
 def stop_owned(reason):
  remaining=live_owned();record(reason,tag=tag,pids=remaining)
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   for pid in remaining:
    try:os.kill(pid,sig)
    except ProcessLookupError:pass
   end=time.time()+2
   while time.time()<end and live_owned():time.sleep(.1)
   remaining=live_owned()
   if not remaining:break
  if remaining:record('owned-processes-still-live',tag=tag,pids=remaining)
 if adopted:
  if adopted['cores']!=cores or str(args[5]) not in adopted['argv']:raise RuntimeError('Adopted command identity differs: '+tag)
  root_pid=adopted['pid'];root_ticks=adopted['startTicks'];log=adopted['log'];observed[root_pid]=root_ticks
  record('adopt-native-command',tag=tag,pid=root_pid,startTicks=root_ticks,log=log,cores=cores,notice='Original native command, output, source, timeout, and CPU mask remain unchanged.')
 else:
  with Path(log).open('w') as stream:p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  root_pid=p.pid;root_ticks=processes().get(root_pid,{}).get('startTicks')
  record('launch',tag=tag,pid=root_pid,log=str(log),cores=cores,affinitySha256=current)
 with lock:state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':adopted['argv'] if adopted else argv,'log':str(log),'cores':cores,'adopted':bool(adopted)}
 record('active-native-command',tag=tag,pid=root_pid)
 while True:
  if p:
   if p.poll() is not None:exit_code=p.returncode;break
  else:
   table=processes();item=table.get(root_pid)
   if not item or item['startTicks']!=root_ticks or item['status']=='Z':
    if adopted.get('receipt'):
     try:exit_code=json.loads(Path(adopted['receipt']).read_text()).get('exitCode')
     except (OSError,ValueError):pass
    break
  now=time.time();observe(audit=now-last_audit>=5)
  if now-last_audit>=5:last_audit=now
  if now>=DEADLINE:
   stop_owned('deadline-interruption')
   if p:exit_code=p.wait(timeout=10)
   break
  time.sleep(.5)
 if live_owned():stop_owned('post-terminal-browser-cleanup')
 with lock:state['active'].pop(tag,None)
 record('exit',tag=tag,pid=root_pid,code=exit_code,exitCodeKnown=exit_code is not None,adopted=bool(adopted),affinityViolations=violations,observedProcesses=len(observed))
 if violations:raise RuntimeError('CPU placement escaped: '+str(violations))
 return exit_code
''' +s[end:]
# The old phone upload, if still live at takeover, must finish before the new phone sequence.
s=s.replace("def phone():\n for index,clip", """def phone():
 for tag,item in list(ADOPTED.items()):
  if tag.startswith('main-phone-'):
   clip_id=tag.removeprefix('main-phone-')
   index,clip=next((i,c) for i,c in enumerate(CLIPS,1) if c['id']==clip_id)
   one('main','phone',clip,index,LANES['phone'])
 for index,clip""")
# Default planner ranks five worst and five best when the full phone profile is accounted.
s=s.replace(" selected=selected[:10]", """ selected=selected[:10]
 planner=subprocess.run(['taskset','-c',str(LANES['research'][0]),'node','--input-type=module','-e',
  \"import fs from 'node:fs'; import {reviewSelection} from './tools/v3d-review.mjs'; const read=p=>JSON.parse(fs.readFileSync(p,'utf8')); console.log(JSON.stringify(reviewSelection(read('tools/v3d-corpus.json'),read(process.argv[1]),read(process.argv[2]))));\",
  str(ROOT/'main-reference/run.json'),str(snapshot/'run.json')],cwd=REPO,capture_output=True,text=True)
 (SESSION/'review-planner.log').write_text(planner.stdout+planner.stderr)
 if planner.returncode:raise RuntimeError('Existing review planner rejected the source-bound runs')
 plan=json.loads(planner.stdout);ranked=plan['ranked']
 if ranked:selected=[r['id'] for r in plan['selected']]
 (SESSION/'review-plan.json').write_text(json.dumps(plan,indent=2)+'\\n')""")
s=s.replace("notice='Manifest-order verified pairs; no score-based substitution'", "notice='Existing five-worst/five-best planner' if ranked else 'Manifest-order verified pairs; complete-profile ranks unavailable'")
s=s.replace("  command(args,SESSION/'phone-review.log',LANES['phone'],'phone-review')", "  if ranked:args=[a for a in args if not str(a).startswith('--ids=')]\n  command(args,SESSION/'phone-review.log',LANES['phone'],'phone-review')")
start=s.index("record('fresh-protocol-5-start'")
s=s[:start]+'''FREEZE=json.loads((SESSION/'freeze.json').read_text())
ADOPTED=json.loads((SESSION/'takeover.json').read_text())['adopted']
# Index terminal main rows only. Failed outcomes are reused, never retried for favorable results.
state['main']=[str(p.parent) for p in sorted((ROOT/'runs/main').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
state['snapshots']=max([0]+[int(p.name.rsplit('-',1)[1]) for p in ROOT.glob('main-snapshot-[0-9][0-9][0-9]')])
for file,expected in FREEZE['files'].items():
 if hashlib.sha256((REPO/file).read_bytes()).hexdigest()!=expected:raise RuntimeError('Frozen evaluator changed: '+file)
if '--validate-only' in __import__('sys').argv:
 print(json.dumps({'mainTerminal':len(state['main']),'adopted':list(ADOPTED),'nextSnapshot':state['snapshots']+1,'candidateCommit':state['candidateCommit']}));raise SystemExit(0)
record('decoded-picture-candidate-start',protocolFilesSha256=os.environ['V3D_PROTOCOL_FILES_SHA256'],notice='Fresh candidate outputs on unchanged protocol 5. Exact existing baseline outcomes are reused; all superseded candidate rows remain separate diagnostics.')
if state['main']:publish_main()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(safe,name,fn) for name,fn in [('phone',phone),('desktop-main',desktop_main),('desktop-candidate',desktop_candidate)]]
 for f in futures:f.result()
record('native-collection-ended')
try:
 if len(state['strictCandidate'])>=2:candidate_join('decoded-picture-final-strict-candidate')
except Exception as e:record('final-join-error',error=str(e))
'''
s=s.replace("candidate_join('phone-complete-candidate')", "candidate_join('decoded-picture-phone-complete-candidate')").replace("ROOT/'samples-", "ROOT/'decoded-picture-samples-").replace("ROOT/('samples-", "ROOT/('decoded-picture-samples-").replace("ROOT/'phone-review'", "ROOT/'decoded-picture-phone-review'")
(session/'collect.py').write_text(s)
(session/'cpu-lanes.json').write_bytes((root/'session/cpu-lanes.json').read_bytes())
print(session/'collect.py')
