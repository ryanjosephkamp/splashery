import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {benchmarkLaunchArgs} from '/workspace/splashery/tools/v3d-bench.mjs';
import {sourceFrameReceipts} from '/workspace/splashery/tools/v3d-bench-pixels.mjs';
const base64=fs.readFileSync('/workspace/work/v3d-r5/corpus/cat-plays.mp4').toString('base64');
const sourceTimes=JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time','-of','json','/workspace/work/v3d-r5/corpus/cat-plays.mp4'],{encoding:'utf8'})).frames.map(f=>Number(f.best_effort_timestamp_time));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});
try {const page=await browser.newPage();await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const frames=await page.evaluate(async base64=>{const {openVideo,seek,closeVideo}=await import('/src/video3d/extract.js');const opened=await openVideo(new File([Uint8Array.from(atob(base64),c=>c.charCodeAt(0))],'cat-plays.mp4'));const result=[];try{for(const t of [.083,.25,.417,.917,1.25,1.917]){await seek(opened.video,t);const vf=new VideoFrame(opened.video);const timestamp=vf.timestamp;vf.close();const c=document.createElement('canvas');c.width=270;c.height=480;c.getContext('2d').drawImage(opened.video,0,0,270,480);const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.92));const sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await blob.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');result.push({requestedTime:t,currentTime:opened.video.currentTime,time:timestamp/1e6,presentedTime:timestamp/1e6,width:270,height:480,sha256});}return result;}finally{closeVideo(opened);}},base64);
 const proof=await page.evaluate(sourceFrameReceipts,{base64,sourceTimes,times:[],trainingFrames:frames,crop:{sx:0,sw:270}});
 fs.writeFileSync('/workspace/work/v3d-r5/session/videoframe-timestamp-control.json',JSON.stringify({notice:'Read-only actual decoded-frame timestamp and exact independent JPEG probe. No production change or accepted corpus outcome.',frames,proof},null,2)+'\n');
 console.log(JSON.stringify(frames.map((r,i)=>({...r,actualJpegTime:proof.matchedTraining[i].sourceTime}))));
}finally{await browser.close();}
