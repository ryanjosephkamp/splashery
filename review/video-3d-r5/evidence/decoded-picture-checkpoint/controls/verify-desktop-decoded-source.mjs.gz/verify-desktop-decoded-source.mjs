// MIT. Diagnostic only: no native status, score, timing, or evaluator file is rewritten.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {sourceFrameReceipts,assertPixelDisjointness} from '/workspace/splashery/tools/v3d-bench-pixels.mjs';
import {selectHeldoutTimes} from '/workspace/splashery/tools/v3d-bench-metrics.mjs';
import {benchmarkLaunchArgs} from '/workspace/splashery/tools/v3d-bench.mjs';
import {panoSafeCrop} from '/workspace/splashery/src/video3d/frames.js';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const root='/workspace/work/v3d-r5',folder=root+'/final-run/runs/decoded-picture-unpaired-candidate/desktop/01-cat-track';
const runBytes=fs.readFileSync(folder+'/run.json'),modelBytes=fs.readFileSync(folder+'/cat-track-desktop/model.json');
const run=JSON.parse(runBytes),model=JSON.parse(modelBytes),file=root+'/corpus/cat-track.mp4';
const meta=JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate:frame=best_effort_timestamp_time','-of','json',file],{encoding:'utf8'}));
const sourceTimes=meta.frames.map(f=>Number(f.best_effort_timestamp_time));const [n,d]=meta.streams[0].r_frame_rate.split('/').map(Number);
const times=selectHeldoutTimes({cameras:model.cams,sourceTimes,attemptedTimes:model.observed.attemptedTimes,trainingTimes:model.observed.trainingTimes,fps:n/d});
let source=sourceFrameReceipts.toString();
const start=source.indexOf('      const mediaTime = await new Promise('),end=source.indexOf('      context.drawImage(',start);
if(start<0||end<0)throw Error('Independent decoder seam changed');
source=source.slice(0,start)+`      const mediaTime = await new Promise((resolve,reject)=>{
        let done=false;
        const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);video.removeEventListener('loadedmetadata',loaded);video.removeEventListener('seeked',settled);video.removeEventListener('error',failed);video.pause();error?reject(error):resolve(value);};
        const settled=()=>{if(done||video.seeking||video.readyState<2)return;let frame;try{frame=new VideoFrame(video);const actual=frame.timestamp/1e6;if(!Number.isFinite(actual)||Math.abs(actual-time)>0.000001)throw Error('Wrong actual decoded source timestamp: '+actual+' wanted '+time);finish(null,actual);}catch(error){finish(error);}finally{frame?.close();}};
        const loaded=()=>{if(done)return;clearTimeout(timer);timer=setTimeout(()=>finish(new Error('No exact decoded source picture at '+time)),4000);const gap=sourceTimes[index+1]-time||time-sourceTimes[index-1]||.01;video.currentTime=time+Math.min(.001,gap/8);};
        const failed=()=>finish(new Error('Independent source cannot be decoded'));
        let timer=setTimeout(()=>finish(new Error('Source metadata timed out')),10000);
        video.addEventListener('loadedmetadata',loaded,{once:true});video.addEventListener('seeked',settled);video.addEventListener('error',failed,{once:true});video.src=url;
      });
`+source.slice(end);
source=source.replace('if (!video.requestVideoFrameCallback)','if (typeof VideoFrame !== "function")').replace('Fresh independent source decoders, actual presentation timestamps, identical extraction canvas and JPEG encoder; every training JPEG matched, held-out JPEGs disjoint.','Diagnostic fresh paused independent decoders, exact actual VideoFrame timestamps, unchanged extraction canvas and JPEG encoder; every training JPEG matched and held-out JPEGs disjoint. Original native status is unchanged.');
const helper=new Function('return ('+source+')')();
fs.writeFileSync(root+'/session/diagnostic-decoded-source-helper.mjs','// MIT. Diagnostic only; not the frozen native evaluator.\nexport '+source+'\n');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});
try {
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const proof=await page.evaluate(helper,{base64:fs.readFileSync(file).toString('base64'),sourceTimes,times,trainingFrames:model.observed.trainingFrames,crop:panoSafeCrop(meta.streams[0].width,meta.streams[0].height)});
 assertPixelDisjointness(model.observed.trainingFrames,proof,times);
 const result={at:new Date().toISOString(),notice:'Separate diagnostic on a retained post-bake verifier failure. Exact paused decoded-frame timestamps replace callback waiting only in this work-directory helper. All JPEG bytes, independent source identities, held-out counts, and disjointness checks remain. The original native harness-error, scores, timings, source, and protocol are not promoted or rewritten.',originalStatus:run.results[0].status,originalRunSha256:hash(runBytes),modelMetadataSha256:hash(modelBytes),helperSha256:hash(source),times,matchedTraining:proof.matchedTraining.length,proof};
 fs.writeFileSync(root+'/session/desktop-decoded-source-proof.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({originalStatus:result.originalStatus,matchedTraining:result.matchedTraining,heldouts:proof.views.length,failedTimeVerified:proof.views.some(v=>Math.abs(v.time-.666667)<1e-6),allExactJpegsAndDisjointness:true}));
}finally{await browser.close();}
