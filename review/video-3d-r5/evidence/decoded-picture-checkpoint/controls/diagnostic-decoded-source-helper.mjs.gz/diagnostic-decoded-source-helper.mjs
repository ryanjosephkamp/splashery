// MIT. Diagnostic only; not the frozen native evaluator.
export async function sourceFrameReceipts({ base64, sourceTimes, times, trainingFrames, crop }) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  const width = trainingFrames[0]?.width,
    height = trainingFrames[0]?.height;
  if (!width || !height || trainingFrames.some((f) => f.width !== width || f.height !== height))
    throw new Error("Training photograph geometry is absent or inconsistent.");
  const url = URL.createObjectURL(new Blob([bytes], { type: "video/mp4" }));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  const hash = async (blob) =>
    Array.from(
      new Uint8Array(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer())),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
  const jpeg = () => new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.92));
  const cache = new Map();
  let releaseRendering;
  const capture = async (index) => {
    if (cache.has(index)) return cache.get(index);
    const time = sourceTimes[index];
    // A fresh independent decoder cannot inherit an old queued presentation. Start a few
    // frames earlier and watch real playback reach the exact requested source timestamp.
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    if (typeof VideoFrame !== "function")
      throw new Error("Independent source-frame presentation is unavailable.");
    try {
      const mediaTime = await new Promise((resolve,reject)=>{
        let done=false;
        const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);video.removeEventListener('loadedmetadata',loaded);video.removeEventListener('seeked',settled);video.removeEventListener('error',failed);video.pause();error?reject(error):resolve(value);};
        const settled=()=>{if(done||video.seeking||video.readyState<2)return;let frame;try{frame=new VideoFrame(video);const actual=frame.timestamp/1e6;if(!Number.isFinite(actual)||Math.abs(actual-time)>0.000001)throw Error('Wrong actual decoded source timestamp: '+actual+' wanted '+time);finish(null,actual);}catch(error){finish(error);}finally{frame?.close();}};
        const loaded=()=>{if(done)return;clearTimeout(timer);timer=setTimeout(()=>finish(new Error('No exact decoded source picture at '+time)),4000);const gap=sourceTimes[index+1]-time||time-sourceTimes[index-1]||.01;video.currentTime=time+Math.min(.001,gap/8);};
        const failed=()=>finish(new Error('Independent source cannot be decoded'));
        let timer=setTimeout(()=>finish(new Error('Source metadata timed out')),10000);
        video.addEventListener('loadedmetadata',loaded,{once:true});video.addEventListener('seeked',settled);video.addEventListener('error',failed,{once:true});video.src=url;
      });
      context.drawImage(video, crop.sx, 0, crop.sw, video.videoHeight, 0, 0, width, height);
      const sha256 = await hash(await jpeg()),
        repeatedSha256 = await hash(await jpeg());
      const result = { index, time, mediaTime, width, height, sha256, repeatedSha256 };
      cache.set(index, result);
      return result;
    } finally {
      video.pause();
      video.removeAttribute("src");
      video.load();
    }
  };
  try {
    // The native bake has already finished. Its viewer must not compete with the independent
    // video decoder; release the hold before any model-view evaluation or review capture.
    releaseRendering = globalThis.__splashery?.player?.stage?.holdRendering?.();
    const views = [];
    for (const time of times) {
      const index = sourceTimes.findIndex((t) => Math.abs(t - time) < 0.000001);
      if (index < 0) throw new Error("The held-out time does not identify an exact source frame.");
      views.push(await capture(index));
    }
    // Match EVERY selected JPEG back to the independent decoder. This checks that a recreated
    // JPEG has the same bytes as training, even on main's seek-only extraction path. Search near
    // its requested/presented time first; a stale picture can require an earlier source frame.
    const matchedTraining = [];
    for (const training of trainingFrames) {
      let match = [...cache.values()].find((f) => f.sha256 === training.sha256);
      if (!match) {
        const target = training.presentedTime ?? training.requestedTime;
        const order = sourceTimes
          .map((time, index) => ({ index, distance: Math.abs(time - target) }))
          .sort((a, b) => a.distance - b.distance || a.index - b.index);
        for (const { index } of order) {
          const frame = await capture(index);
          if (frame.sha256 === training.sha256) {
            match = frame;
            break;
          }
        }
      }
      if (!match)
        throw new Error(
          "A training JPEG could not be matched to an independently presented source frame.",
        );
      matchedTraining.push({
        sha256: training.sha256,
        repeatedSha256: match.repeatedSha256,
        sourceIndex: match.index,
        sourceTime: match.mediaTime,
      });
    }
    return {
      method:
        "Diagnostic fresh paused independent decoders, exact actual VideoFrame timestamps, unchanged extraction canvas and JPEG encoder; every training JPEG matched and held-out JPEGs disjoint. Original native status is unchanged.",
      matchedTraining,
      views,
      decodedFrames: cache.size,
    };
  } finally {
    URL.revokeObjectURL(url);
    releaseRendering?.();
  }
}
