import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {surfaceSeed as candidate} from '/workspace/splashery/src/video3d/surface-seed.js';
const root='/workspace/work/v3d-r5/session/';
const oldBytes=fs.readFileSync(root+'surface-before.js');
const source=oldBytes.toString().replace('"./scene.js"','"file:///workspace/splashery/src/video3d/scene.js"');
const {surfaceSeed:before}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const bytes=fs.readFileSync(root+'r4-seed-probe.json.gz');
const input=JSON.parse(gunzipSync(bytes));
input.frames.forEach(f=>f.rgb=Float32Array.from(f.rgb));
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=[];
for(const options of [{maxPoints:13800},{maxPoints:30000},{maxPoints:8000,stride:3}]) {
 const runs={before:[],candidate:[]}; let reference;
 for(let i=0;i<6;i++) for(const [name,fn] of (i%2?[['candidate',candidate],['before',before]]:[['before',before],['candidate',candidate]])) {
  const start=performance.now();const result=fn(input.recon,input.frames,options);const elapsedMs=performance.now()-start;
  const data=Buffer.from(result.data.buffer);const record={n:result.n,candidates:result.candidates,supported:result.supported,sha256:hash(data)};
  if(reference)assert.deepEqual(record,reference);else reference=record;
  runs[name].push(elapsedMs);
 }
 const median=v=>v.slice().sort((a,b)=>a-b)[v.length>>1];
 rows.push({options,...reference,runs,medianBeforeMs:median(runs.before.slice(1)),medianCandidateMs:median(runs.candidate.slice(1))});
}
const result={date:new Date().toISOString(),notice:'Cached CPU initialization diagnostic; no native bake or phone timing claim.',inputSha256:hash(bytes),beforeSourceSha256:hash(oldBytes),candidateSourceSha256:hash(fs.readFileSync('/workspace/splashery/src/video3d/surface-seed.js')),rows};
fs.writeFileSync(root+'surface-parity.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
