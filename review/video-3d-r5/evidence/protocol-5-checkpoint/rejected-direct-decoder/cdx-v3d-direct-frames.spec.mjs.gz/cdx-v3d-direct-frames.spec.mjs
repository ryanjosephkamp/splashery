import { test, expect } from "@playwright/test";
import fs from "node:fs";
import { execFileSync } from "node:child_process";
import { sourceFrameReceipts, assertPixelDisjointness } from "../tools/v3d-bench-pixels.mjs";

let file, base64, sourceTimes;
test.beforeAll(async ({}, info) => {
  file = info.outputPath("bframes.mp4");
  fs.mkdirSync(new URL(".", `file://${file}`).pathname, { recursive: true });
  execFileSync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "testsrc2=size=160x96:rate=24:duration=2", "-c:v", "libx264", "-g", "24", "-bf", "3", "-pix_fmt", "yuv420p", "-y", file]);
  base64 = fs.readFileSync(file).toString("base64");
  sourceTimes = JSON.parse(execFileSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_frames", "-show_entries", "frame=best_effort_timestamp_time", "-of", "json", file], { encoding: "utf8" })).frames.map((f) => Number(f.best_effort_timestamp_time));
});

test("direct frame selection preserves exact independently presented JPEGs and B-frame times", async ({ page }) => {
  await page.goto("/tests/fixtures/v3d/");
  const selected = await page.evaluate(async (base64) => {
    const { openVideo, grabFrames, closeVideo } = await import("/src/video3d/extract.js");
    const opened = await openVideo(new File([Uint8Array.from(atob(base64), (c) => c.charCodeAt(0))], "bframes.mp4"));
    try {
      const picks = await grabFrames(opened, { windows: [.125, .625, 1.125, 1.625].map((t) => ({ t, from: t, to: t })) }, { side: 160, tries: 1 });
      return Promise.all(picks.map(async (p) => ({ ...p, blob: undefined, sha256: Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", await p.blob.arrayBuffer())), (b) => b.toString(16).padStart(2, "0")).join("") })));
    } finally { closeVideo(opened); }
  }, base64);
  expect(selected.map((p) => p.decoder)).toEqual(Array(4).fill("webcodecs"));
  expect(selected.map((p) => p.presentedTime)).toEqual([.125, .625, 1.125, 1.625]);
  const times = [sourceTimes[7], sourceTimes[19]];
  const proof = await page.evaluate(sourceFrameReceipts, { base64, sourceTimes, times, trainingFrames: selected, crop: { sx: 0, sw: 160 } });
  expect(assertPixelDisjointness(selected, proof, times)).toBe(true);
  for (const [i, p] of proof.matchedTraining.entries()) expect(Math.abs(p.sourceTime - selected[i].presentedTime)).toBeLessThan(.0001);
});

test("bounded MP4 metadata agrees with independent packet times, offsets, and sizes", async () => {
  const { mp4VideoTrack } = await import("../src/video3d/extract.js");
  const track = await mp4VideoTrack(new File([fs.readFileSync(file)], "bframes.mp4"));
  const packets = JSON.parse(execFileSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_packets", "-show_entries", "packet=pts_time,pos,size,flags", "-of", "json", file], { encoding: "utf8" })).packets;
  expect(track.samples).toHaveLength(48);
  expect(track.samples.map((p) => [Math.round(p.time * 1e6), p.offset, p.size, p.key])).toEqual(packets.map((p) => [Math.round(Number(p.pts_time) * 1e6), Number(p.pos), Number(p.size), p.flags.includes("K")]));
});

test("oversized, truncated, and non-MP4 metadata fall back without reading the video payload", async () => {
  const { mp4VideoTrack } = await import("../src/video3d/extract.js");
  const header = new Uint8Array(16), view = new DataView(header.buffer);
  view.setUint32(0, 1);header.set([..."moov"].map((c) => c.charCodeAt(0)), 4);view.setBigUint64(8, BigInt(32 * 1024 * 1024));
  const reads = [];
  expect(await mp4VideoTrack({ size: 1e12, slice(a, b) { reads.push([a, b]);return new Blob([header]); } })).toBe(null);
  expect(reads).toEqual([[0, 16]]);
  expect(await mp4VideoTrack(new Blob([header.subarray(0, 10)]))).toBe(null);
  expect(await mp4VideoTrack(new Blob([new Uint8Array(128)]))).toBe(null);
});
