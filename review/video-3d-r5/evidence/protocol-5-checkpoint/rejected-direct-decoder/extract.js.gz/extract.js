// Video to 3D (lane Video 3D): the video's frames, grabbed in the browser. A <video> element plays
// the file from the device (an object URL: nothing is uploaded), seeks to each moment planFrames
// chose, and a canvas copies the frame. In each window the sharpest of a few frames is kept.

import { windowTimes, sharpness, fitSide, panoSafeCrop } from "./frames.js";
import { runWithDeadline } from "./deadline.js";

// Read only bounded MP4 metadata, then fetch individual compressed pictures on demand.
// Unsupported containers, codecs, edits, and display transforms keep the media-element path.
export async function mp4VideoTrack(file, { signal } = {}) {
  const check = () => {
    if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
  };
  const unsupported = () => { throw new Error("Unsupported MP4 layout"); };
  const text = (view, offset) => String.fromCharCode(...new Uint8Array(view.buffer, view.byteOffset + offset, 4));
  const safe64 = (view, offset) => {
    const value = view.getBigUint64(offset);
    if (value > BigInt(Number.MAX_SAFE_INTEGER)) unsupported();
    return Number(value);
  };
  const boxes = (view, from = 0, to = view.byteLength) => {
    const list = [];
    for (let at = from; at < to;) {
      if (at + 8 > to || list.length >= 100000) unsupported();
      const short = view.getUint32(at);
      const size = short === 1 ? safe64(view, at + 8) : short || to - at;
      const header = short === 1 ? 16 : 8;
      if (size < header || at + size > to) unsupported();
      list.push({ type: text(view, at + 4), data: at + header, end: at + size });
      at += size;
    }
    return list;
  };
  try {
    check();
    let metadata = null;
    for (let offset = 0, count = 0; offset + 8 <= file.size && count < 1024; count++) {
      const header = new DataView(await file.slice(offset, offset + 16).arrayBuffer());
      check();
      const short = header.getUint32(0), size = short === 1 ? safe64(header, 8) : short || file.size - offset;
      if (size < (short === 1 ? 16 : 8) || offset + size > file.size) unsupported();
      if (text(header, 4) === "moov") {
        if (size > 16 * 1024 * 1024) unsupported();
        metadata = new DataView(await file.slice(offset, offset + size).arrayBuffer());
        break;
      }
      if (text(header, 4) === "moof") unsupported();
      offset += size;
    }
    check();
    if (!metadata) return null;
    const view = metadata;
    const root = boxes(view)[0];
    const children = (box) => boxes(view, box.data, box.end);
    const child = (box, type) => children(box).find((b) => b.type === type);
    const tracks = children(root).filter((b) => b.type === "trak");
    for (const track of tracks) {
      const media = child(track, "mdia"), header = media && child(media, "hdlr");
      if (!header || text(view, header.data + 8) !== "vide") continue;
      const tkhd = child(track, "tkhd"), mdhd = child(media, "mdhd");
      if (!tkhd || !mdhd) unsupported();
      const matrix = tkhd.data + (view.getUint8(tkhd.data) === 1 ? 52 : 40);
      const identity = [65536, 0, 0, 0, 65536, 0, 0, 0, 1073741824];
      if (identity.some((value, i) => view.getInt32(matrix + i * 4) !== value)) unsupported();
      const scale = view.getUint32(mdhd.data + (view.getUint8(mdhd.data) === 1 ? 20 : 12));
      if (!scale) unsupported();
      const minf = child(media, "minf"), stbl = minf && child(minf, "stbl");
      if (!stbl) unsupported();
      const table = Object.fromEntries(children(stbl).map((b) => [b.type, b]));
      const stsd = table.stsd;
      if (!stsd || view.getUint32(stsd.data + 4) !== 1) unsupported();
      const entry = boxes(view, stsd.data + 8, stsd.end)[0];
      if (!entry || !["avc1", "avc3"].includes(entry.type)) unsupported();
      const config = boxes(view, entry.data + 78, entry.end).find((b) => b.type === "avcC");
      if (!config || config.end - config.data < 7) unsupported();
      const description = view.buffer.slice(view.byteOffset + config.data, view.byteOffset + config.end);
      const codec = entry.type + "." + Array.from(new Uint8Array(description, 1, 3), (n) => n.toString(16).padStart(2, "0")).join("");
      const width = view.getUint16(entry.data + 24), height = view.getUint16(entry.data + 26);
      if (!width || !height) unsupported();
      const sizes = table.stsz, timing = table.stts, chunks = table.stco || table.co64, mapping = table.stsc;
      if (!sizes || !timing || !chunks || !mapping) unsupported();
      const count = view.getUint32(sizes.data + 8), common = view.getUint32(sizes.data + 4);
      if (!count || count > 100000) unsupported();
      const samples = Array.from({ length: count }, (_, i) => ({
        size: common || view.getUint32(sizes.data + 12 + i * 4),
        key: !table.stss, time: 0, duration: 0, offset: 0,
      }));
      const expand = (box, apply, signed = false) => {
        let index = 0;
        const entries = view.getUint32(box.data + 4);
        if (entries > count || box.data + 8 + entries * 8 !== box.end) unsupported();
        for (let i = 0; i < entries; i++) {
          const at = box.data + 8 + i * 8, repeat = view.getUint32(at);
          const value = signed ? view.getInt32(at + 4) : view.getUint32(at + 4);
          if (!repeat || index + repeat > count) unsupported();
          for (let j = 0; j < repeat; j++) apply(samples[index++], value);
        }
        if (index !== count) unsupported();
      };
      let tick = 0;
      expand(timing, (sample, delta) => {
        if (!delta) unsupported();
        sample.time = tick; sample.duration = delta; tick += delta;
        if (!Number.isSafeInteger(tick)) unsupported();
      });
      if (table.ctts) expand(table.ctts, (sample, delta) => { sample.time += delta; }, view.getUint8(table.ctts.data) === 1);
      const edits = child(track, "edts"), elst = edits && child(edits, "elst");
      let mediaStart = 0;
      if (elst) {
        if (view.getUint32(elst.data + 4) !== 1) unsupported();
        const wide = view.getUint8(elst.data) === 1;
        mediaStart = wide ? Number(view.getBigInt64(elst.data + 16)) : view.getInt32(elst.data + 12);
        const rate = elst.data + (wide ? 24 : 16);
        if (!Number.isSafeInteger(mediaStart) || mediaStart < 0 || view.getInt16(rate) !== 1 || view.getInt16(rate + 2) !== 0) unsupported();
      }
      for (const sample of samples) { sample.time = (sample.time - mediaStart) / scale; sample.duration /= scale; }
      if (table.stss) {
        const sync = table.stss, entries = view.getUint32(sync.data + 4);
        if (sync.data + 8 + entries * 4 !== sync.end) unsupported();
        for (let i = 0; i < entries; i++) {
          const index = view.getUint32(sync.data + 8 + i * 4) - 1;
          if (!samples[index]) unsupported();
          samples[index].key = true;
        }
      }
      const chunkCount = view.getUint32(chunks.data + 4), stride = chunks.type === "co64" ? 8 : 4;
      const runs = view.getUint32(mapping.data + 4);
      if (!chunkCount || !runs || chunks.data + 8 + chunkCount * stride !== chunks.end || mapping.data + 8 + runs * 12 !== mapping.end) unsupported();
      let sampleIndex = 0, run = 0;
      if (view.getUint32(mapping.data + 8) !== 1) unsupported();
      for (let chunk = 1; chunk <= chunkCount; chunk++) {
        while (run + 1 < runs && view.getUint32(mapping.data + 8 + (run + 1) * 12) <= chunk) run++;
        const at = mapping.data + 8 + run * 12;
        if (view.getUint32(at + 8) !== 1) unsupported();
        const perChunk = view.getUint32(at + 4), where = chunks.data + 8 + (chunk - 1) * stride;
        let offset = stride === 8 ? safe64(view, where) : view.getUint32(where);
        if (!perChunk || sampleIndex + perChunk > count) unsupported();
        for (let j = 0; j < perChunk; j++) {
          const sample = samples[sampleIndex++];
          if (!sample.size || offset + sample.size > file.size) unsupported();
          sample.offset = offset; offset += sample.size;
        }
      }
      if (sampleIndex !== count || !samples[0].key) unsupported();
      check();
      return { codec, description, width, height, samples };
    }
    return null;
  } catch (error) {
    if (error?.name === "AbortError") throw error;
    return null;
  }
}

// Each callback owns a decoded picture only until it returns. Copy its pixels synchronously;
// all decoder output pictures are closed here, including errors, cancellation, and late output.
export async function decodeMP4Pictures(file, times, onPicture, { signal, timeoutMs = 6000, colorSpace, readColorSpace } = {}) {
  if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
  if (typeof VideoDecoder !== "function" || !file || !times.length) return false;
  let decoder = null, active = true;
  const waits = new Set();
  try {
    return await runWithDeadline(async (childSignal) => {
      const check = () => {
        if (childSignal.aborted) throw new DOMException("Stopped", "AbortError");
      };
      const track = await mp4VideoTrack(file, { signal: childSignal });
      check();
      if (!track) return false;
      const colors = readColorSpace ? await readColorSpace(childSignal) : colorSpace;
      check();
      const config = { codec: track.codec, description: track.description, codedWidth: track.width, codedHeight: track.height, ...(colors ? {colorSpace: colors} : {}) };
      const supported = await VideoDecoder.isConfigSupported(config);
      check();
      if (!supported.supported) return false;
      const ordered = track.samples.map((sample, index) => ({ ...sample, index })).sort((a, b) => a.time - b.time);
      if (times.some((t) => !Number.isFinite(t) || t < ordered[0].time || t >= ordered.at(-1).time + ordered.at(-1).duration)) return false;
      const requested = times.map((time) => {
        let lo = 0, hi = ordered.length;
        while (lo + 1 < hi) {
          const mid = (lo + hi) >> 1;
          if (ordered[mid].time <= time + 1e-9) lo = mid;
          else hi = mid;
        }
        return ordered[lo];
      });
      const wanted = new Map();
      requested.forEach((sample, index) => {
        const time = Math.round(sample.time * 1e6);
        if (!wanted.has(time)) wanted.set(time, []);
        wanted.get(time).push(index);
      });
      let fail;
      const failure = new Promise((_, reject) => { fail = reject; });
      failure.catch(() => {});
      const emitted = new Set();
      decoder = new VideoDecoder({
        output(frame) {
          try {
            if (!active || childSignal.aborted) return;
            const indexes = wanted.get(frame.timestamp);
            if (!indexes) return;
            if (emitted.has(frame.timestamp) || frame.displayWidth !== track.width || frame.displayHeight !== track.height) throw new Error("Unexpected decoded picture layout");
            onPicture(frame, indexes);
            emitted.add(frame.timestamp);
          } catch (error) { fail(error); }
          finally { frame.close(); }
        },
        error(error) { if (active) fail(error); },
      });
      decoder.configure(config);
      let first = Math.min(...requested.map((s) => s.index));
      const last = Math.max(...requested.map((s) => s.index));
      while (first > 0 && !track.samples[first].key) first--;
      if (!track.samples[first].key) return false;
      for (let i = first; i <= last; i++) {
        check();
        const sample = track.samples[i];
        const data = await Promise.race([file.slice(sample.offset, sample.offset + sample.size).arrayBuffer(), failure]);
        check();
        decoder.decode(new EncodedVideoChunk({ type: sample.key ? "key" : "delta", timestamp: Math.round(sample.time * 1e6), duration: Math.round(sample.duration * 1e6), data }));
        while (decoder.decodeQueueSize >= 8) {
          await Promise.race([new Promise((resolve) => {
            const wake = () => { waits.delete(wake); decoder?.removeEventListener("dequeue", wake); resolve(); };
            waits.add(wake);
            decoder.addEventListener("dequeue", wake, { once: true });
            if (decoder.decodeQueueSize < 8) wake();
          }), failure]);
          check();
        }
      }
      await Promise.race([decoder.flush(), failure]);
      check();
      if (emitted.size !== wanted.size) throw new Error("Missing decoded pictures");
      return true;
    }, { signal, timeoutMs, message: "Direct picture decoding took too long." });
  } catch (error) {
    if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
    return false;
  } finally {
    active = false;
    for (const wake of waits) decoder?.removeEventListener("dequeue", wake);
    waits.clear();
    if (decoder && decoder.state !== "closed") decoder.close();
  }
}

// Opens the video: resolves { video, url, duration, width, height }. Throws a plain message when
// the browser cannot play the file.
export async function openVideo(file, { signal, timeoutMs = 20000 } = {}) {
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;
  try {
    await new Promise((resolve, reject) => {
      const finish = (error) => {
        clearTimeout(t);
        signal?.removeEventListener("abort", abort);
        video.onloadedmetadata = video.onerror = null;
        error ? reject(error) : resolve();
      };
      const abort = () => finish(new DOMException("Stopped", "AbortError"));
      const t = setTimeout(() => finish(new Error("timeout")), timeoutMs);
      signal?.addEventListener("abort", abort, { once: true });
      video.onloadedmetadata = () => {
        finish();
      };
      video.onerror = () => {
        finish(new Error("error"));
      };
      if (signal?.aborted) abort();
    });
  } catch (error) {
    video.removeAttribute("src");
    video.load();
    URL.revokeObjectURL(url);
    if (error?.name === "AbortError") throw error;
    const failure = new Error(
      "This browser cannot play that video. Try an MP4 (H.264) or WebM file, or a shorter clip.",
    );
    failure.code = error?.message === "timeout" ? "V3D_VIDEO_TIMEOUT" : "V3D_VIDEO_UNPLAYABLE";
    throw failure;
  }
  const duration = Number.isFinite(video.duration) ? video.duration : 0;
  if (!duration || !video.videoWidth) {
    video.removeAttribute("src");
    video.load();
    URL.revokeObjectURL(url);
    const failure = new Error("That video has no picture or no length this browser can read.");
    failure.code = "V3D_VIDEO_UNPLAYABLE";
    throw failure;
  }
  return { video, url, duration, width: video.videoWidth, height: video.videoHeight, file };
}

export function seek(video, t, { signal, timeoutMs = 4000 } = {}) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (error) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      video.removeEventListener("seeked", ready);
      video.removeEventListener("loadeddata", ready);
      video.removeEventListener("error", failed);
      signal?.removeEventListener("abort", abort);
      error ? reject(error) : resolve();
    };
    const ready = () => {
      if (!video.seeking && video.readyState >= 2) finish();
    };
    const abort = () => finish(new DOMException("Stopped", "AbortError"));
    const failed = () => {
      const failure = new Error(
        "This browser cannot read a picture from that video. Try an MP4 (H.264) or WebM file.",
      );
      failure.code = "V3D_VIDEO_UNPLAYABLE";
      finish(failure);
    };
    const timer = setTimeout(
      () => finish(new Error("The video took too long to show a frame.")),
      timeoutMs,
    );
    video.addEventListener("seeked", ready);
    video.addEventListener("loadeddata", ready);
    video.addEventListener("error", failed);
    signal?.addEventListener("abort", abort, { once: true });
    try {
      video.currentTime = t;
    } catch (error) {
      finish(error);
      return;
    }
    if (signal?.aborted) abort();
    else if (video.error) failed();
    else ready();
  });
}

// seeked can precede the decoded picture reaching drawImage. Wait for presentation before
// judging sharpness or making a training photograph, and retain the actual source-frame time.
// Older browsers without this API return null: a requested time is not presentation evidence.
const presentedFrames = new WeakMap();
const presentationOwners = new WeakMap();
const recoveryRates = new WeakMap();
export async function seekPresented(video, time, { signal, timeoutMs = 4000 } = {}) {
  if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
  // Keep ownership after completion: play() can settle after its presentation callback,
  // and an older continuation must not pause a later seek on this same local video.
  const owner = {};
  presentationOwners.set(video, owner);
  const ownsVideo = () => presentationOwners.get(video) === owner;
  // A new seek takes over any older recovery without inheriting its temporary speed.
  const priorRate = recoveryRates.get(video);
  if (priorRate) {
    recoveryRates.delete(video);
    video.pause();
    if (video.playbackRate === priorRate.applied) {
      try {
        video.playbackRate = priorRate.before;
      } catch {
        /* The browser owns its rate limits. */
      }
    }
  }
  if (!video.requestVideoFrameCallback) {
    await seek(video, time, { signal, timeoutMs });
    return null;
  }
  const source = video.currentSrc || video.src;
  const previous = presentedFrames.get(video);
  if (
    previous &&
    previous.source === source &&
    previous.requestedTime === time &&
    video.currentTime === previous.position &&
    !video.seeking &&
    video.readyState >= 2
  )
    return previous.mediaTime;
  let cleanup;
  const presented = new Promise((resolve, reject) => {
    let callback;
    let recovery;
    let advanced = false;
    let done = false;
    let seekedAt = null;
    const pauseRecovery = () => {
      video.pause();
      const rate = recoveryRates.get(video);
      if (rate?.owner !== owner) return;
      recoveryRates.delete(video);
      if (video.playbackRate === rate.applied) {
        try {
          video.playbackRate = rate.before;
        } catch {
          /* A host rate change stays authoritative. */
        }
      }
    };
    const finish = (error, mediaTime) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      clearTimeout(recovery);
      signal?.removeEventListener("abort", abort);
      video.removeEventListener("seeking", arm);
      video.removeEventListener("seeked", settled);
      if (callback !== undefined) video.cancelVideoFrameCallback(callback);
      if (advanced && ownsVideo()) pauseRecovery();
      error ? reject(error) : resolve(mediaTime);
    };
    const abort = () => finish(new DOMException("Stopped", "AbortError"));
    const timer = setTimeout(
      () =>
        finish(new Error("The decoded video frame took too long. Try a shorter MP4 (H.264) clip.")),
      timeoutMs,
    );
    // Initial/old RVFCs can arrive after seeking starts but before seeked: accepting one and then
    // waiting for seeked pairs its old mediaTime with the new drawImage picture. Require a fresh
    // presentation after seeked; presentationTime also rejects an older queued callback delivered
    // after that event. Frame duration can vary, so mediaTime proximity is never a test.
    const arm = () => {
      callback = video.requestVideoFrameCallback((_, metadata) => {
        callback = undefined;
        if (done) return;
        if (
          seekedAt === null ||
          video.seeking ||
          (Number.isFinite(metadata.presentationTime) && metadata.presentationTime < seekedAt)
        ) {
          arm();
          return;
        }
        finish(null, metadata.mediaTime);
      });
    };
    // A paused seek can remain inside the already-presented frame. Chromium then sends seeked
    // without another presentation callback. Briefly advancing the muted local video requests a
    // real new picture; pause inside its callback and keep that picture's actual mediaTime.
    // Never infer a timestamp from currentTime or from identical image content.
    const recover = () => {
      if (done || !video.paused || typeof video.play !== "function") return;
      clearTimeout(recovery);
      recovery = setTimeout(() => {
        if (done || !ownsVideo()) return;
        advanced = true;
        // At normal speed a busy callback can arrive after drawImage's picture has already
        // advanced beyond its mediaTime. Slow only this recovery, then restore the caller's
        // rate after pausing. The returned time still comes from an actual presentation.
        const before = video.playbackRate;
        if (Number.isFinite(before) && before > 0) {
          try {
            video.playbackRate = Math.min(before, 0.125);
            recoveryRates.set(video, { owner, before, applied: video.playbackRate });
          } catch {
            // Browsers with narrower rate limits retain the existing bounded recovery.
          }
        }
        let playback;
        try {
          playback = video.play();
        } catch {
          return; // Keep the original deadline if this browser refuses playback synchronously.
        }
        Promise.resolve(playback).then(
          () => {
            if (done && ownsVideo()) pauseRecovery();
          },
          () => {
            /* The original presentation deadline still supplies retry advice. */
          },
        );
      }, 100);
    };
    const settled = () => {
      if (video.seeking || video.readyState < 2) return;
      seekedAt = performance.now();
      recover();
    };
    cleanup = finish;
    video.addEventListener("seeking", arm, { once: true });
    video.addEventListener("seeked", settled);
    signal?.addEventListener("abort", abort, { once: true });
    if (signal?.aborted) abort();
  });
  try {
    const [, mediaTime] = await Promise.all([seek(video, time, { signal, timeoutMs }), presented]);
    // Browsers can round the seek position (for example, 2.01 becomes 2.009999).
    // Reuse only that exact confirmed position for an identical request and source.
    if (ownsVideo())
      presentedFrames.set(video, {
        source,
        requestedTime: time,
        position: video.currentTime,
        mediaTime,
      });
    return mediaTime;
  } finally {
    cleanup();
  }
}

// Grabs the planned frames. opened: openVideo's result; plan: planFrames's; side: the long side
// of each photograph; tries: frames looked at per window. onFrame(i, n, blob) reports progress.
// Resolves [{ blob, time, sharpness, width, height }].
export async function grabFrames(opened, plan, { side = 960, tries = 3, onFrame, signal } = {}) {
  const { video } = opened;
  const crop = panoSafeCrop(opened.width, opened.height);
  const [w, h] = fitSide(crop.sw, opened.height, side);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const g = canvas.getContext("2d", { willReadFrequently: true });
  // Sharpness is judged on a small gray copy (fast, and blur shows at any size).
  const [sw, sh] = fitSide(w, h, 256);
  const small = document.createElement("canvas");
  small.width = sw;
  small.height = sh;
  const gs = small.getContext("2d", { willReadFrequently: true });
  const gray = new Float32Array(sw * sh);
  const out = [];
  const times = plan.windows.flatMap((window) => windowTimes(window, tries));
  const direct = [];
  let usedDirect = false;
  let completingDirect = false;
  try {
    if (opened.file && typeof VideoDecoder === "function" && typeof VideoFrame === "function") {
      // The media demuxer supplies container color metadata and resolution-based defaults.
      // Bare AVC packets can otherwise default to BT.709 while the same video uses BT.601.
      const readColorSpace = async (childSignal) => {
        await seekPresented(video, Math.max(0, times[0]), { signal: childSignal });
        const firstPicture = new VideoFrame(video, { timestamp: 0 });
        try { return firstPicture.colorSpace.toJSON(); }
        finally { firstPicture.close(); }
      };
      usedDirect = await decodeMP4Pictures(opened.file, times, (picture, indexes) => {
        gs.drawImage(picture, crop.sx, 0, crop.sw, opened.height, 0, 0, sw, sh);
        const px = gs.getImageData(0, 0, sw, sh).data;
        for (let k = 0; k < gray.length; k++) gray[k] = .299 * px[k * 4] + .587 * px[k * 4 + 1] + .114 * px[k * 4 + 2];
        const score = sharpness(gray, sw, sh);
        for (const rank of indexes) {
          const index = Math.floor(rank / tries), previous = direct[index];
          if (previous && (previous.sharpness > score || (previous.sharpness === score && previous.rank < rank))) continue;
          const target = previous?.canvas || document.createElement("canvas");
          if (!previous) { target.width = w; target.height = h; }
          target.getContext("2d", { willReadFrequently: true }).drawImage(picture, crop.sx, 0, crop.sw, opened.height, 0, 0, w, h);
          const time = picture.timestamp / 1e6;
          direct[index] = { canvas: target, rank, time, presentedTime: time, requestedTime: times[rank], sharpness: score, decoder: "webcodecs" };
        }
      }, { signal, readColorSpace });
      if (direct.length !== plan.windows.length || plan.windows.some((_, i) => !direct[i])) usedDirect = false;
      if (usedDirect) {
        completingDirect = true;
        for (let i = 0; i < direct.length; i++) {
          if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
          const { canvas: target, rank, ...best } = direct[i];
          best.blob = await new Promise((resolve) => target.toBlob(resolve, "image/jpeg", .92));
          if (!best.blob) throw new Error("The browser could not save a video picture. Try the Phone-safe setting.");
          best.width = w; best.height = h;
          out.push(best);
          onFrame?.(i + 1, plan.windows.length, best);
        }
      }
    }
  } catch (error) {
    if (error?.name === "AbortError" || completingDirect) throw error;
    usedDirect = false;
    out.length = 0;
  } finally {
    for (const picture of direct) if (picture?.canvas) { picture.canvas.width = 0; picture.canvas.height = 0; }
  }
  for (let i = 0; !usedDirect && i < plan.windows.length; i++) {
    if (signal?.aborted) throw new DOMException("Stopped", "AbortError");
    let best = null;
    for (const t of windowTimes(plan.windows[i], tries)) {
      const presentedTime = await seekPresented(video, t, { signal });
      gs.drawImage(video, crop.sx, 0, crop.sw, opened.height, 0, 0, sw, sh);
      const px = gs.getImageData(0, 0, sw, sh).data;
      for (let k = 0; k < gray.length; k++)
        gray[k] = 0.299 * px[k * 4] + 0.587 * px[k * 4 + 1] + 0.114 * px[k * 4 + 2];
      const s = sharpness(gray, sw, sh);
      if (!best || s > best.sharpness) {
        g.drawImage(video, crop.sx, 0, crop.sw, opened.height, 0, 0, w, h);
        best = { time: presentedTime ?? t, requestedTime: t, presentedTime, sharpness: s };
        best.blob = await new Promise((r) => canvas.toBlob(r, "image/jpeg", 0.92));
      }
    }
    best.width = w;
    best.height = h;
    out.push(best);
    onFrame?.(i + 1, plan.windows.length, best);
  }
  return out;
}

export function closeVideo(opened) {
  if (!opened) return;
  opened.video.removeAttribute("src");
  opened.video.load();
  URL.revokeObjectURL(opened.url);
}
