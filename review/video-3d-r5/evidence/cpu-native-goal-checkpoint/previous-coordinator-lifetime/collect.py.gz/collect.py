import concurrent.futures,datetime,hashlib,json,os,signal,subprocess,threading,time,traceback
from pathlib import Path
REPO=Path('/workspace/work/v3d-r5/evaluator-protocol5')
ROOT=Path('/workspace/work/v3d-r5/final-run')
SESSION=ROOT/'session-cpu-adaptive'
CLIPS=json.loads((REPO/'tools/v3d-corpus.json').read_text())
LANES=json.loads((SESSION/'cpu-lanes.json').read_text())
DEADLINE=datetime.datetime(2026,10,16,13,29,tzinfo=datetime.timezone.utc).timestamp()
lock=threading.RLock()
DESKTOP_CLAIMS={'main':set(),'candidate':set()}
MEDIA_REQUESTED=threading.Event()
MEDIA_FINISHED=threading.Event()
state={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadline':DEADLINE,'candidateCommit':os.environ['V3D_CANDIDATE_COMMIT'],'baselineCommit':'5a55f5ccc25ebfa155e5db2391236558feb551ec','lanes':LANES,'main':[],'strictCandidate':[],'unpairedCandidate':[],'active':{},'events':[],'snapshots':0}

def record(event,**data):
 with lock:
  item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**data}
  state['events'].append(item)
  tmp=SESSION/'collection-state.json.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');os.replace(tmp,SESSION/'collection-state.json')
  with (SESSION/'collection-events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
  print(json.dumps(item),flush=True)

def processes():
 result={}
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   fields=(path/'stat').read_text().rsplit(')',1)[1].split()
   result[int(path.name)]={'ppid':int(fields[1]),'startTicks':fields[19],'status':fields[0]}
  except (OSError,IndexError,ValueError):pass
 return result

def descendants(root,table):
 owned={root};changed=True
 while changed:
  changed=False
  for pid,item in table.items():
   if item['ppid'] in owned and pid not in owned:owned.add(pid);changed=True
 return owned

def command(args,log,cores,tag):
 if time.time()>=DEADLINE:raise TimeoutError('Goal deadline reached before launch')
 current=hashlib.sha256((REPO/'tools/v3d-affinity.py').read_bytes()).hexdigest()
 if current!=os.environ['V3D_AFFINITY_SHA256']:raise RuntimeError('Affinity launcher changed after freeze')
 argv=['python3','tools/v3d-affinity.py',','.join(map(str,cores)),'--',*map(str,args)]
 env=dict(os.environ,SPLASHERY_CHROMIUM='/usr/bin/chromium',OMP_NUM_THREADS=str(len(cores)))
 adopted=ADOPTED.pop(tag,None)
 observed={int(pid):ticks for pid,ticks in adopted.get('owned',{}).items()} if adopted else {}
 violations=[];last_audit=time.time();p=None;exit_code=None
 def observe(audit=False):
  table=processes()
  for pid in descendants(root_pid,table):
   if pid in table:observed[pid]=table[pid]['startTicks']
  if audit:
   for pid,start in list(observed.items()):
    if table.get(pid,{}).get('startTicks')!=start:continue
    try:
     for tid in (Path('/proc')/str(pid)/'task').iterdir():
      try:
       allowed=os.sched_getaffinity(int(tid.name))
       if not allowed<=set(cores):violations.append({'pid':pid,'tid':int(tid.name),'allowed':sorted(allowed)})
      except (ProcessLookupError,FileNotFoundError):pass
    except FileNotFoundError:pass
  return table
 def live_owned():
  table=processes()
  return [pid for pid,start in observed.items() if table.get(pid,{}).get('startTicks')==start and table[pid]['status']!='Z']
 def stop_owned(reason):
  remaining=live_owned();record(reason,tag=tag,pids=remaining)
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   for pid in remaining:
    try:os.kill(pid,sig)
    except ProcessLookupError:pass
   end=time.time()+2
   while time.time()<end and live_owned():time.sleep(.1)
   remaining=live_owned()
   if not remaining:break
  if remaining:record('owned-processes-still-live',tag=tag,pids=remaining)
 if adopted:
  if adopted['cores']!=cores or str(args[5]) not in adopted['argv']:raise RuntimeError('Adopted command identity differs: '+tag)
  root_pid=adopted['pid'];root_ticks=adopted['startTicks'];log=adopted['log'];observed[root_pid]=root_ticks
  record('adopt-native-command',tag=tag,pid=root_pid,startTicks=root_ticks,log=log,cores=cores,notice='Original native command, output, source, timeout, and CPU mask remain unchanged.')
 else:
  while True:
   if time.time()>=DEADLINE:raise TimeoutError('Goal deadline before native launch')
   with lock:
    blocked=('-desktop-' in tag and MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set())
    if not blocked:
     prior_cores=os.sched_getaffinity(0)
     try:
      os.sched_setaffinity(0,prior_cores|set(cores))
      with Path(log).open('w') as stream:p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
     finally:os.sched_setaffinity(0,prior_cores)
     root_pid=p.pid;root_ticks=processes().get(root_pid,{}).get('startTicks')
     state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':argv,'log':str(log),'cores':cores,'adopted':False}
     break
   MEDIA_FINISHED.wait(.25)
  record('launch',tag=tag,pid=root_pid,log=str(log),cores=cores,affinitySha256=current)
 with lock:state['active'][tag]={'pid':root_pid,'startTicks':root_ticks,'argv':adopted['argv'] if adopted else argv,'log':str(log),'cores':cores,'adopted':bool(adopted)}
 record('active-native-command',tag=tag,pid=root_pid)
 while True:
  if p:
   if p.poll() is not None:exit_code=p.returncode;break
  else:
   table=processes();item=table.get(root_pid)
   if not item or item['startTicks']!=root_ticks or item['status']=='Z':
    if adopted.get('receipt'):
     try:exit_code=json.loads(Path(adopted['receipt']).read_text()).get('exitCode')
     except (OSError,ValueError):pass
    break
  now=time.time();observe(audit=now-last_audit>=5)
  if now-last_audit>=5:last_audit=now
  if now>=DEADLINE:
   stop_owned('deadline-interruption')
   if p:exit_code=p.wait(timeout=10)
   break
  time.sleep(.5)
 if live_owned():stop_owned('post-terminal-browser-cleanup')
 with lock:state['active'].pop(tag,None)
 record('exit',tag=tag,pid=root_pid,code=exit_code,exitCodeKnown=exit_code is not None,adopted=bool(adopted),affinityViolations=violations,observedProcesses=len(observed))
 if violations:raise RuntimeError('CPU placement escaped: '+str(violations))
 return exit_code

def alias(source,target):
 tmp=Path(str(target)+'.tmp')
 if tmp.is_symlink():tmp.unlink()
 tmp.symlink_to(source,target_is_directory=True);os.replace(tmp,target)

def publish_main():
 with lock:
  sources=[Path(p) for p in state['main']]
  if len(sources)==1:alias(sources[0],ROOT/'main-reference');return
  state['snapshots']+=1
  target=ROOT/f'main-snapshot-{state["snapshots"]:03d}'
  result=subprocess.run(['nice','-n','19','taskset','-c',str(LANES['research'][0]),'node','tools/v3d-bench-join.mjs','tools/v3d-corpus.json',str(target),*map(str,sources)],cwd=REPO,capture_output=True,text=True)
  (SESSION/f'join-main-{state["snapshots"]:03d}.log').write_text(result.stdout+result.stderr)
  if result.returncode:raise RuntimeError('Baseline join failed: '+result.stderr[-1000:])
  alias(target,ROOT/'main-reference')
  record('baseline-snapshot',output=str(target),cases=len(sources))

def accounted(row):
 return row.get('status')=='finished' and not row.get('consoleErrors') or row.get('status')=='explained' and row.get('reason','').strip() and row.get('explanation',{}).get('visible') is True and row.get('explanation',{}).get('diagnostic','').strip() and row.get('explanation',{}).get('advice','').strip() and not row.get('consoleErrors')

def one(version,profile,clip,index,cores,reference=None):
 group='main' if version=='main' else ('cpu-matcher-strict-candidate' if reference else 'cpu-matcher-unpaired-candidate')
 output=ROOT/'runs'/group/profile/f'{index:02d}-{clip["id"]}'
 existed=output.exists()
 args=['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',output,'--url=http://127.0.0.1:'+('4174/' if version=='main' else '4179/'),f'--profiles={profile}',f'--ids={clip["id"]}','--gpu=swiftshader']
 if reference:args.append('--reference='+str(ROOT/'main-reference'))
 tag=f'{version}-{profile}-{clip["id"]}'
 code=command(args,SESSION/(tag+'.log'),cores,tag) if not existed or tag in ADOPTED else None
 run_path=output/'run.json'
 if not run_path.exists():raise RuntimeError(f'No recorded run after {tag}; exit {code}')
 run=json.loads(run_path.read_text())
 rows=run.get('results',[])
 if len(rows)!=1:raise RuntimeError(f'Incomplete native case {tag}; exit {code}; rows {len(rows)}')
 row=rows[0]
 if row['id']!=clip['id'] or row['profile']!=profile or row['sha256']!=clip['sha256']:raise RuntimeError('Unexpected case identity')
 expected_source=FREEZE['baselineServedSourceSha256'] if version=='main' else FREEZE['candidateServedSourceSha256']
 if run['provenance']['servedSource']['sha256']!=expected_source or run['provenance']['protocolSha256']!=FREEZE['benchmarkProtocolSha256'] or row['provenanceSha256']!=run['provenanceSha256']:raise RuntimeError('Frozen source or protocol changed: '+str(output))
 with lock:
  bucket=state['main' if version=='main' else ('strictCandidate' if reference else 'unpairedCandidate')]
  already=str(output) in bucket
  if not already:bucket.append(str(output))
  record('outcome',version=version,profile=profile,id=clip['id'],status=row['status'],phase=row.get('phase'),bakeMs=row.get('bakeMs'),firstViewMs=row.get('firstViewMs'),mean=row.get('mean'),output=str(output))
 if version=='main' and not already:publish_main()
 return row

def candidate_join(label):
 with lock:
  sources=[Path(p) for p in state['strictCandidate']]
  target=ROOT/label
  if len(sources)<2:raise RuntimeError('Not enough strict candidate cases for a join')
  result=subprocess.run(['nice','-n','19','taskset','-c',str(LANES['research'][0]),'node','tools/v3d-bench-join.mjs','tools/v3d-corpus.json',str(target),*map(str,sources),'--reference='+str(ROOT/'main-reference')],cwd=REPO,capture_output=True,text=True)
  (SESSION/(label+'-join.log')).write_text(result.stdout+result.stderr)
  if result.returncode:raise RuntimeError('Candidate join failed: '+result.stderr[-1500:])
  record('candidate-snapshot',output=str(target),cases=len(sources))
  return target

def retry_phone_harness():
 registry=SESSION/'phone-harness-retries.json'
 retries=json.loads(registry.read_text()) if registry.exists() else []
 for output in list(state['strictCandidate'])+list(state['unpairedCandidate']):
  path=Path(output)/'run.json';raw=path.read_bytes();run=json.loads(raw)
  if len(run.get('results',[]))!=1:continue
  row=run['results'][0]
  if row['profile']!='phone' or row['status']!='harness-error' or row.get('phase')!='evaluation' or 'No presented source frame at ' not in row.get('reason','') or row.get('consoleErrors'):continue
  folder=Path(output)/(row['id']+'-phone')
  if not (folder/'model.json').is_file() or not (folder/'model.ply').is_file():continue
  if any(r['output']==output for r in retries) or (Path(output)/'attempts').exists():
   record('phone-harness-retry-already-preserved',output=output);continue
  if DEADLINE-time.time()<31*60:
   record('phone-harness-retry-not-enough-time',output=output);continue
  previous={'output':output,'originalRunSha256':hashlib.sha256(raw).hexdigest(),'id':row['id'],'originalStatus':row['status'],'originalReason':row['reason'],'registeredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'notice':'One explicit native retry of a missed source callback. The CLI archives the original run and model. The replacement outcome is retained regardless of success or quality.'}
  retries.append(previous);registry.write_text(json.dumps(retries,indent=2)+'\n')
  args=['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',output,'--url='+run['url'],'--profiles=phone','--ids='+row['id'],'--gpu=swiftshader','--retry=harness-error']
  if run['provenance'].get('reference'):args.append('--reference='+run['provenance']['reference']['path'])
  command(args,SESSION/('phone-harness-retry-'+row['id']+'.log'),LANES['phone'],'phone-harness-retry-'+row['id'])
  after=path.read_bytes();new=json.loads(after)
  previous.update(replacementRunSha256=hashlib.sha256(after).hexdigest(),replacementStatus=new.get('results',[{}])[0].get('status'))
  registry.write_text(json.dumps(retries,indent=2)+'\n');record('phone-harness-retry-outcome',**previous)

def phone():
 for tag,item in list(ADOPTED.items()):
  if tag.startswith('main-phone-'):
   clip_id=tag.removeprefix('main-phone-')
   index,clip=next((i,c) for i,c in enumerate(CLIPS,1) if c['id']==clip_id)
   one('main','phone',clip,index,LANES['phone'])
 for index,clip in enumerate(CLIPS,1):
  if index>=19 and not MEDIA_REQUESTED.is_set():
   MEDIA_REQUESTED.set();record('isolated-media-window-requested',phoneIndex=index)
  row=one('main','phone',clip,index,LANES['phone'])
  one('candidate','phone',clip,index,LANES['phone'],reference=accounted(row))
 record('phone-native-complete')
 MEDIA_REQUESTED.set()
 record('waiting-for-native-desktop-terminal-before-media')
 while True:
  with lock:active=[tag for tag in state['active'] if '-desktop-' in tag]
  inherited=[tag for tag in ADOPTED if '-desktop-' in tag]
  if not active and not inherited:break
  if time.time()>=DEADLINE:raise TimeoutError('Goal deadline before isolated media window')
  time.sleep(.25)
 record('isolated-media-window-start',notice='No timed desktop or phone bake remains active. Rendering and clean timing controls use the reserved phone cores.')
 retry_phone_harness()
 # Predeclared clean timing confirmation. Both outcomes remain separate from corpus rows.
 clean_main=ROOT/'phone-timing-control-main'
 if clean_main.exists():raise RuntimeError('Refusing to repeat the predeclared clean main timing control')
 command(['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',clean_main,'--url=http://127.0.0.1:4174/','--profiles=phone','--ids=cat-plays','--gpu=swiftshader'],SESSION/'clean-timing-main.log',LANES['phone'],'clean-timing-main')
 clean_run=json.loads((clean_main/'run.json').read_text())
 if len(clean_run.get('results',[]))!=1:raise RuntimeError('Clean main timing control has no terminal native row')
 clean_paired=bool(accounted(clean_run['results'][0]))
 clean_candidate=ROOT/('phone-timing-control-candidate' if clean_paired else 'phone-timing-control-candidate-unpaired')
 if clean_candidate.exists():raise RuntimeError('Refusing to repeat the predeclared clean candidate timing control')
 args=['node','tools/v3d-bench.mjs','run','tools/v3d-corpus.json',ROOT/'corpus',clean_candidate,'--url=http://127.0.0.1:4179/','--profiles=phone','--ids=cat-plays','--gpu=swiftshader']
 if clean_paired:args.append('--reference='+str(clean_main))
 command(args,SESSION/'clean-timing-candidate.log',LANES['phone'],'clean-timing-candidate')
 record('clean-phone-timing-controls-complete',main=str(clean_main),candidate=str(clean_candidate),paired=clean_paired,notice='Both original native outcomes are retained regardless of result. This control does not replace corpus rows or establish corpus acceptance.')
 # The clean timed controls have ended. Samples and movies now run with no timed bakes.

 proof=validate_early_samples()
 record('complete-fixed-samples-reused',proof=proof,notice='The complete source-bound four-core sample window already passed every original pixel comparison.')
 snapshot=candidate_join('cpu-matcher-phone-complete-candidate')
 main_run=json.loads((ROOT/'main-reference/run.json').read_text());candidate_run=json.loads((snapshot/'run.json').read_text())
 before={(r['id'],r['profile']):r for r in main_run['results']}
 after={(r['id'],r['profile']):r for r in candidate_run['results']}
 selected=[]
 for clip in CLIPS:
  a=before.get((clip['id'],'phone'),{});b=after.get((clip['id'],'phone'),{})
  if a.get('status')==b.get('status')=='finished' and a.get('heldoutEvidence',{}).get('complete') and b.get('heldoutEvidence',{}).get('complete') and a.get('frames') and [(f['time'],f['referenceSha256']) for f in a['frames']]==[(f['time'],f['referenceSha256']) for f in b.get('frames',[])]:selected.append(clip['id'])
 selected=selected[:10]
 planner=subprocess.run(['nice','-n','19','taskset','-c',str(LANES['research'][0]),'node','--input-type=module','-e',
  "import fs from 'node:fs'; import {reviewSelection} from './tools/v3d-review.mjs'; const read=p=>JSON.parse(fs.readFileSync(p,'utf8')); console.log(JSON.stringify(reviewSelection(read('tools/v3d-corpus.json'),read(process.argv[1]),read(process.argv[2]))));",
  str(ROOT/'main-reference/run.json'),str(snapshot/'run.json')],cwd=REPO,capture_output=True,text=True)
 (SESSION/'review-planner.log').write_text(planner.stdout+planner.stderr)
 if planner.returncode:raise RuntimeError('Existing review planner rejected the source-bound runs')
 plan=json.loads(planner.stdout);ranked=plan['ranked']
 if ranked:selected=[r['id'] for r in plan['selected']]
 (SESSION/'review-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 record('phone-review-selection',ids=selected,notice='Existing five-worst/five-best planner' if ranked else 'Manifest-order verified pairs; complete-profile ranks unavailable')
 if selected:
  args=['node','tools/v3d-review.mjs','render','tools/v3d-corpus.json',ROOT/'main-reference',snapshot,ROOT/'cpu-matcher-phone-review','--profile=phone','--ids='+','.join(selected),'--seconds=5','--fps=10','--timeout=1200000','--size=390x844','--main-url=http://127.0.0.1:4174/','--candidate-url=http://127.0.0.1:4179/']
  if ranked:args=[a for a in args if not str(a).startswith('--ids=')]
  command(args,SESSION/'phone-review.log',LANES['review'],'phone-review')
 record('phone-review-phase-complete')
 MEDIA_FINISHED.set();record('isolated-media-window-released')

def wait_for_media(tag):
 if tag in ADOPTED:return
 version,profile,clip_id=tag.split('-',2)
 index=next(i for i,c in enumerate(CLIPS,1) if c['id']==clip_id)
 groups=['main'] if version=='main' else ['cpu-matcher-strict-candidate','cpu-matcher-unpaired-candidate']
 for group in groups:
  path=ROOT/'runs'/group/profile/f'{index:02d}-{clip_id}'/'run.json'
  if path.exists() and len(json.loads(path.read_text()).get('results',[]))==1:return
 while MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set():
  if time.time()>=DEADLINE:raise TimeoutError('Goal deadline while waiting for isolated media')
  MEDIA_FINISHED.wait(.25)


def validate_early_samples():
 result=subprocess.run(['nice','-n','19','taskset','-c','3','node','/workspace/work/v3d-r5/session/verify-cpu-samples-for-reuse.mjs'],cwd=REPO,capture_output=True,text=True)
 (SESSION/'sample-reuse-validation.log').write_text(result.stdout+result.stderr)
 if result.returncode:raise RuntimeError('Complete early sample proof is not valid: '+result.stderr[-700:])
 proof=json.loads(result.stdout)
 if proof['candidateSourceSha256']!=FREEZE['candidateServedSourceSha256']:raise RuntimeError('Sample proof belongs to a different runtime')
 (SESSION/'validated-samples.json').write_text(json.dumps(proof,indent=2)+'\n')
 return proof

def extra_lane_ready(version):
 while time.time()<DEADLINE:
  with lock:
   released=any(e['event']=='isolated-media-window-released' for e in state['events'])
  if released:
   if version=='main':return
   try:
    control=json.loads((ROOT/'session-protocol6-control/control-state.json').read_text())
    terminal=any(e['event'] in ['fresh-control-terminal','fresh-control-not-launched'] for e in control.get('events',[]))
    if terminal and not control.get('active'):return
   except (OSError,ValueError):pass
  time.sleep(.5)
 raise TimeoutError('Goal deadline before the reserved extra desktop lane became available')

def desktop_claim(version):
 with lock:
  if len(DESKTOP_CLAIMS[version])==len(CLIPS):return 'done'
  if MEDIA_REQUESTED.is_set() and not MEDIA_FINISHED.is_set():return None
  for index,clip in enumerate(CLIPS,1):
   if index in DESKTOP_CLAIMS[version]:continue
   reference=None
   if version=='candidate':
    try:
     run=json.loads((ROOT/'runs/main/desktop'/f'{index:02d}-{clip["id"]}'/'run.json').read_text())
     master=json.loads((ROOT/'main-reference/run.json').read_text())
     if len(run.get('results',[]))!=1 or not any(r['id']==clip['id'] and r['profile']=='desktop' for r in master['results']):continue
     reference=accounted(run['results'][0])
    except (OSError,ValueError):continue
   DESKTOP_CLAIMS[version].add(index)
   record('desktop-case-claimed',version=version,index=index,id=clip['id'])
   return index,clip,reference
 return None

def adaptive_claim():
 with lock:
  candidate=desktop_claim('candidate')
  if isinstance(candidate,tuple):return ('candidate',*candidate)
  main=desktop_claim('main')
  if isinstance(main,tuple):return ('main',*main)
  return 'done' if candidate=='done' and main=='done' else None

def adaptive_lane(core):
 # No native desktop admission before phone timing and every media job end.
 # Core 0 first belongs to the separately registered protocol-6 control.
 extra_lane_ready('candidate' if core==0 else 'main')
 while time.time()<DEADLINE:
  claim=adaptive_claim()
  if claim=='done':
   record('adaptive-worker-complete',core=core,notice='Every manifest index is claimed; final completion still comes from original terminal rows.');return
  if claim is None:time.sleep(.25);continue
  version,index,clip,reference=claim
  record('adaptive-desktop-dispatch',core=core,version=version,index=index,id=clip['id'],reference=reference,notice='One core, original options and deadline. Ready candidates take priority; otherwise claim the next unrun baseline. No prior outcome is replaced.')
  one(version,'desktop',clip,index,[core],reference=reference)
 raise TimeoutError('Goal deadline in adaptive desktop collection')

def safe(name,fn):
 try:fn()
 except Exception as e:record('lane-error',lane=name,error=str(e),traceback=traceback.format_exc())
 finally:
  if name=='phone':MEDIA_FINISHED.set()

FREEZE=json.loads((SESSION/'freeze.json').read_text())
ADOPTED=json.loads((SESSION/'takeover.json').read_text())['adopted']
state['active']={tag:{**item,'adopted':True} for tag,item in ADOPTED.items()}
prior=json.loads((SESSION/'takeover.json').read_text())['priorState']
if any(e['event']=='phone-native-complete' for e in prior['events']):raise RuntimeError('This continuation must begin before the phone/media phase ends')
state['events']=list(prior['events']);state['continuedFrom']=str(ROOT/'session-cpu-matcher')
if any('-desktop-' in tag for tag in ADOPTED):raise RuntimeError('Take over only when all original desktop commands are terminal')
# Index terminal main rows only. Failed outcomes are reused, never retried for favorable results.
state['main']=[str(p.parent) for p in sorted((ROOT/'runs/main').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
state['strictCandidate']=[str(p.parent) for p in sorted((ROOT/'runs/cpu-matcher-strict-candidate').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
state['unpairedCandidate']=[str(p.parent) for p in sorted((ROOT/'runs/cpu-matcher-unpaired-candidate').glob('*/*/run.json')) if len(json.loads(p.read_text()).get('results',[]))==1]
if len([p for p in state['strictCandidate']+state['unpairedCandidate'] if '/phone/' in p])>=18:MEDIA_REQUESTED.set()
# Complete early samples are reused only after source and every PNG hash are validated.
state['snapshots']=max([0]+[int(p.name.rsplit('-',1)[1]) for p in ROOT.glob('main-snapshot-[0-9][0-9][0-9]')])
for file,expected in FREEZE['files'].items():
 if hashlib.sha256((REPO/file).read_bytes()).hexdigest()!=expected:raise RuntimeError('Frozen evaluator changed: '+file)

for version in ['main','candidate']:
 groups=['main'] if version=='main' else ['cpu-matcher-strict-candidate','cpu-matcher-unpaired-candidate']
 for index,clip in enumerate(CLIPS,1):
  for group in groups:
   path=ROOT/'runs'/group/'desktop'/f'{index:02d}-{clip["id"]}'/'run.json'
   if path.exists() and len(json.loads(path.read_text()).get('results',[]))==1:DESKTOP_CLAIMS[version].add(index)

if '--validate-only' in __import__('sys').argv:
 print(json.dumps({'mainTerminal':len(state['main']),'adopted':list(ADOPTED),'nextSnapshot':state['snapshots']+1,'candidateCommit':state['candidateCommit']}));raise SystemExit(0)
validate_early_samples()
record('cpu-matcher-adaptive-continuation-start',protocolFilesSha256=os.environ['V3D_PROTOCOL_FILES_SHA256'],notice='Every CPU-matcher candidate case starts fresh on unchanged protocol 5. Exact baseline outcomes are reused, including failures. Old candidate sources remain separate diagnostics. Each desktop case keeps one core; extra desktop lanes start only after phone timing and all review rendering finish.')
if state['main']:publish_main()
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 futures=[pool.submit(safe,name,fn) for name,fn in [('phone',phone),('desktop-core-2',lambda:adaptive_lane(2)),('desktop-core-3',lambda:adaptive_lane(3)),('desktop-core-1',lambda:adaptive_lane(1)),('desktop-core-0',lambda:adaptive_lane(0))]]
 for f in futures:f.result()
record('native-collection-ended')
try:
 if len(state['strictCandidate'])>=2:candidate_join('cpu-matcher-adaptive-final-strict-candidate')
except Exception as e:record('final-join-error',error=str(e))
