// MIT. Work-only feature cache from two exact actual corpus pictures; no GPU matcher or bake.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {chromium} from '/workspace/splashery/node_modules/@playwright/test/index.mjs';
import {benchmarkLaunchArgs,withHostDeadline,closeBrowserBounded} from '/workspace/work/v3d-r5/evaluator-protocol6/tools/v3d-bench.mjs';
const root='/workspace/work/v3d-r5',folder=root+'/session/cpu-loop-research';fs.mkdirSync(folder,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
const sourceFile=root+'/corpus/dianthus.mp4',manifest=JSON.parse(fs.readFileSync('/workspace/splashery/tools/v3d-corpus.json'));
const credit=manifest.find(c=>c.id==='dianthus');if(hash(fs.readFileSync(sourceFile))!==credit.sha256)throw Error('Changed source input');
const server=await chromium.launchServer({executablePath:'/usr/bin/chromium',args:benchmarkLaunchArgs('swiftshader')});const browser=await chromium.connect(server.wsEndpoint());
try{
 const page=await browser.newPage();page.on('console',m=>{if(m.type()==='log')console.log(m.text());});
 await page.route('**/__r5-real-descriptor-source.mp4',r=>r.fulfill({contentType:'video/mp4',path:sourceFile}));
 await page.goto('http://127.0.0.1:4180/tests/fixtures/v3d/');
 const result=await withHostDeadline(()=>page.evaluate(async()=>{
  const {detectSift}=await import('/vendor/splatjs/src/sfm/sift.js');
  const sha=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),b=>b.toString(16).padStart(2,'0')).join('');
  const base64=arr=>{let s='';for(let i=0;i<arr.length;i+=16384)s+=String.fromCharCode(...arr.subarray(i,i+16384));return btoa(s);};
  const url=URL.createObjectURL(await(await fetch('/__r5-real-descriptor-source.mp4')).blob()),cases=[];
  try{for(const [side,maxFeats]of [[480,3000],[960,8192]]){
   const v=document.createElement('video');v.muted=true;v.preload='auto';
   await new Promise((resolve,reject)=>{v.onloadedmetadata=resolve;v.onerror=reject;v.src=url;});const frames=[];
   try{for(const wanted of [.499674,1.999674]){
    await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Exact source seek timeout')),4000);v.onseeked=()=>{clearTimeout(timer);resolve();};v.currentTime=wanted+.001;});
    const frame=new VideoFrame(v);const actual=frame.timestamp/1e6,duration=frame.duration/1e6;frame.close();if(!Number.isFinite(actual)||Math.abs(actual-wanted)>1e-6)throw Error('Actual source timestamp differs');
    const scale=Math.min(1,side/Math.max(v.videoWidth,v.videoHeight)),w=Math.round(v.videoWidth*scale),h=Math.round(v.videoHeight*scale),canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(v,0,0,w,h);
    const rgba=ctx.getImageData(0,0,w,h).data,gray=Float32Array.from({length:w*h},(_,i)=>(.299*rgba[i*4]+.587*rgba[i*4+1]+.114*rgba[i*4+2])/255),f=detectSift(gray,w,h,maxFeats,0);if(!f.n)throw Error('Missing source features');
    frames.push({requestedTime:wanted,actualTime:actual,duration,w,h,n:f.n,pixelsSha256:await sha(rgba),descriptorSha256:await sha(f.desc),base64:base64(f.desc)});console.log(JSON.stringify({side,actualTime:actual,n:f.n}));
   }}finally{v.pause();v.removeAttribute('src');v.load();}
   if(frames[0].actualTime===frames[1].actualTime||frames[0].pixelsSha256===frames[1].pixelsSha256)throw Error('Repeated source picture');cases.push({side,maxFeats,frames});
  }return cases;}finally{URL.revokeObjectURL(url);}
 }),{timeoutMs:180000,label:'Exact source descriptor cache',onTimeout:()=>closeBrowserBounded(browser,server)});
 for(const c of result)for(let i=0;i<c.frames.length;i++){const f=c.frames[i],b=Buffer.from(f.base64,'base64');if(hash(b)!==f.descriptorSha256||b.length!==f.n*128)throw Error('Changed descriptor cache');f.file=`dianthus-${c.side}-${i}.bin`;fs.writeFileSync(folder+'/'+f.file,b);delete f.base64;}
 const prior=JSON.parse(fs.readFileSync(root+'/session/matcher-ffprobe-source-early-exit-experiment.json'));
 for(const c of result){const old=prior.cases.find(r=>r.label==='actual-dianthus-'+c.side);if(!old||JSON.stringify(old.descriptorHashes)!==JSON.stringify(c.frames.map(f=>f.descriptorSha256)))throw Error('Descriptor cache differs from the already measured exact source control');}
 fs.writeFileSync(folder+'/source-cache.json',JSON.stringify({at:new Date().toISOString(),notice:'Actual fixed input source pictures at independently confirmed ffprobe times; descriptor and pixel hashes match the prior exact source experiment. No native upload, bake, or performance acceptance.',credit,cases:result},null,2)+'\n');console.log(JSON.stringify({allSourceAndDescriptorHashesExact:true,cases:result.length}));
}finally{await closeBrowserBounded(browser,server);}
