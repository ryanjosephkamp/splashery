# MIT. Run the unchanged optional real-input calibration on an unused metadata core.
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
ROOT=Path('/workspace/work/v3d-r5');REPO=Path('/workspace/splashery');PRIMARY=ROOT/'final-run/session-cpu-matcher';PRIVATE=ROOT/'private-calibration';SESSION=ROOT/'session/private-calibration-check';SESSION.mkdir(exist_ok=True)
DEADLINE=datetime.datetime(2026,10,16,13,29,45,tzinfo=datetime.timezone.utc).timestamp();state={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'active':{},'events':[]}
def record(event,**data):
 item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**data};state['events'].append(item);temp=SESSION/'state.json.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');os.replace(temp,SESSION/'state.json')
 with (SESSION/'events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
 print(json.dumps(item),flush=True)
def table():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split();result[int(p.name)]={'ppid':int(f[1]),'ticks':f[19],'status':f[0],'argv':(p/'cmdline').read_bytes().split(b'\0')}
  except (OSError,ValueError,IndexError):pass
 return result
def native_busy(core):
 s=json.loads((PRIMARY/'collection-state.json').read_text());active=s.get('active',{})
 if any(core in x['cores'] for x in active.values()):return True,s
 if any(e['event']=='isolated-media-window-start' for e in s['events']) and not any(e['event']=='isolated-media-window-released' for e in s['events']):return True,s
 for pid,x in table().items():
  if x['status']=='Z' or not x['argv'] or not x['argv'][0]:continue
  a=x['argv'];exe=Path(a[0].decode(errors='replace')).name;launcher=len(a)>2 and a[1]==b'tools/v3d-affinity.py';native=exe.startswith(('chrome','chromium')) or (exe=='node' and len(a)>1 and a[1] in [b'tools/v3d-bench.mjs',b'tools/v3d-review.mjs'])
  if launcher and core in [int(v) for v in a[2].decode().split(',')]:return True,s
  if native:
   try:
    if core in os.sched_getaffinity(pid):return True,s
   except ProcessLookupError:pass
 return False,s
manifest=json.loads((PRIVATE/'manifest.json').read_text());assert len(manifest)==3
for sample in manifest:assert hashlib.sha256(Path(sample['file']).read_bytes()).hexdigest()==sample['expectedSha256']
test=REPO/'tests/cdx-v3d-calibration.spec.mjs';assert test.read_bytes()==subprocess.check_output(['git','show','3f2b0fac8ccdecddecdd181138e1992f180990dc:tests/cdx-v3d-calibration.spec.mjs'],cwd=REPO)
record('waiting-for-unused-core',notice='All three original counterexample hashes match. Run the complete unchanged 12-case calibration spec only while native core 3 is unused and before the clean timing/review window. Media and private screenshots/traces remain outside public evidence. Stop the auxiliary check if new native work claims its core; original native outcomes are never interrupted or replaced.')
while time.time()<DEADLINE:
 try:busy,s=native_busy(3)
 except (OSError,ValueError):time.sleep(2);continue
 if not busy:break
 time.sleep(2)
else:record('not-launched-before-goal-end');raise SystemExit(0)
argv=['python3',str(ROOT/'evaluator-protocol5/tools/v3d-affinity.py'),'3','--','node',str(REPO/'node_modules/@playwright/test/cli.js'),'test','tests/cdx-v3d-calibration.spec.mjs','--workers=1','--reporter=json','--output='+str(PRIVATE/'test-results')]
env=dict(os.environ,SPLASHERY_CHROMIUM='/usr/bin/chromium',SPLASHERY_PORT='4180',CDX_V3D_BAD_MANIFEST=str(PRIVATE/'manifest.json'))
stream=(PRIVATE/'calibration-report.json').open('w');err=(PRIVATE/'calibration-stderr.log').open('w');p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=stream,stderr=err,start_new_session=True);owned={p.pid:table()[p.pid]['ticks']};state['active']={'pid':p.pid,'startTicks':owned[p.pid],'cores':[3]};record('unchanged-full-spec-launched',pid=p.pid,activeNativeMasks={k:v['cores'] for k,v in s['active'].items()},testSha256=hashlib.sha256(test.read_bytes()).hexdigest())
started=time.time();interrupted=None
while p.poll() is None:
 t=table();changed=True
 while changed:
  changed=False
  for pid,x in t.items():
   if x['ppid'] in owned and pid not in owned:owned[pid]=x['ticks'];changed=True
 # The auxiliary test's own browser is excluded from the occupancy check.
 primary=json.loads((PRIMARY/'collection-state.json').read_text());claimed=any(3 in x['cores'] for x in primary.get('active',{}).values())
 media=any(e['event']=='isolated-media-window-start' for e in primary['events']) and not any(e['event']=='isolated-media-window-released' for e in primary['events'])
 if claimed or media or time.time()-started>120 or time.time()>=DEADLINE:
  interrupted='native-core-claimed' if claimed else 'media-window-started' if media else 'auxiliary-host-deadline'
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   for pid,ticks in owned.items():
    if t.get(pid,{}).get('ticks')==ticks and t[pid]['status']!='Z':
     try:os.kill(pid,sig)
     except ProcessLookupError:pass
   end=time.time()+1
   while time.time()<end and p.poll() is None:time.sleep(.05)
   t=table()
  break
 time.sleep(.5)
code=p.wait(timeout=5);stream.close();err.close();state['active']={}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'interrupted':interrupted,'testSha256':hashlib.sha256(test.read_bytes()).hexdigest(),'testUnchanged':test.read_bytes()==subprocess.check_output(['git','show','3f2b0fac8ccdecddecdd181138e1992f180990dc:tests/cdx-v3d-calibration.spec.mjs'],cwd=REPO),'mediaRemainPrivate':True}
if not interrupted:
 try:
  report=json.loads((PRIVATE/'calibration-report.json').read_text());result['stats']=report['stats'];result['reportSha256']=hashlib.sha256((PRIVATE/'calibration-report.json').read_bytes()).hexdigest()
 except Exception as e:result['reportError']=str(e)
result['sourceHashes']=[{'id':r['id'],'sha256':r['expectedSha256']} for r in manifest]
(SESSION/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');record('auxiliary-calibration-terminal',**result)
