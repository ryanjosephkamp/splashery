# MIT. Read-only original pack check after every timed upload and movie ends.
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

BASE = Path('/workspace/work/v3d-r5')
SESSION = BASE / 'session'
PRIMARY = BASE / 'final-run/session-cpu-adaptive'
CONTROL = BASE / 'final-run/session-protocol6-control'
EXPECTED = '6ce63f35a6355b39c68ecc392802c34f59171ca326dde2619a609535631d29fb'
plan = json.loads((SESSION / 'pack-check-quiet-plan.json').read_text())
end = datetime.datetime(2026, 10, 16, 13, 29, 10, tzinfo=datetime.timezone.utc).timestamp()
while time.time() < end:
    assert hashlib.sha256((PRIMARY / 'collect.py').read_bytes()).hexdigest() == EXPECTED
    state = json.loads((PRIMARY / 'collection-state.json').read_text())
    control = json.loads((CONTROL / 'control-state.json').read_text())
    events = {event['event'] for event in state['events']}
    c6_terminal = any(event['event'] in ['fresh-control-terminal', 'fresh-control-not-launched'] for event in control['events'])
    naturally_quiet = 'native-collection-ended' in events and not state.get('active') and c6_terminal and not control.get('active')
    stop = SESSION / 'goal-end-receipt.json'
    guard_quiet = stop.exists() and not json.loads(stop.read_text())['remainingOwnedProcesses']
    if naturally_quiet or guard_quiet:
        break
    time.sleep(0.5)
else:
    raise RuntimeError('No verified quiet window before the final pack-check deadline')
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'quietReason': 'all-native-and-media-ended' if naturally_quiet else 'identity-checked-guard-cleanup', 'originalThresholdMs': 1500, 'core': 0, 'checks': [], 'initialLoadedFailureRetained': True}
for version, path in [('main', BASE / 'main'), ('candidate', Path('/workspace/splashery'))]:
    for file, expected in plan['files'][version].items():
        assert hashlib.sha256((path / file).read_bytes()).hexdigest() == expected
    command = ['taskset', '-c', '0', 'node', 'tools/check-packs.mjs', 'video-3d']
    run = subprocess.run(command, cwd=path, capture_output=True, text=True, timeout=30)
    text = run.stdout + run.stderr
    (SESSION / f'pack-check-quiet-{version}.log').write_text(text)
    result['checks'].append({'version': version, 'exitCode': run.returncode, 'output': text, 'buildMs': int(re.search(r'(\d+) ms', text).group(1)) if re.search(r'(\d+) ms', text) else None, 'unchangedInputHashesVerified': True})
result['passed'] = all(item['exitCode'] == 0 for item in result['checks'])
(SESSION / 'pack-check-quiet.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
