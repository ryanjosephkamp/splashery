# MIT. Original production joins/comparison of terminal records; no native result is changed.
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

BASE = Path('/workspace/work/v3d-r5')
ROOT = BASE / 'final-run'
REPO = BASE / 'evaluator-protocol5'
label = sys.argv[1]
assert label.startswith('cpu-comparison-') and all(c.isalnum() or c == '-' for c in label)
destination = ROOT / label
assert not destination.exists()
destination.mkdir()
def terminal(group):
    result = []
    for file in sorted((ROOT / 'runs' / group).glob('*/*/run.json')):
        data = json.loads(file.read_text())
        if not data.get('results'):
            continue
        assert len(data['results']) == 1
        assert data['provenance']['protocolSha256'] == '154576a01c7a624fb63dfb034cd7bb5d94407691472c56554584f54ca34c69e9'
        assert data['provenance']['servedSource']['sha256'] == ('99cea09dd4f5367f78cfe4d1b5bed97cb87432c38222e6c81edf873be25da9fa' if group == 'main' else 'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571')
        result.append(file.parent)
    return result
main = terminal('main')
candidate = terminal('cpu-matcher-strict-candidate')
commands = [
    ['node', 'tools/v3d-bench-join.mjs', 'tools/v3d-corpus.json', str(destination / 'main'), *map(str, main)],
    ['node', 'tools/v3d-bench-join.mjs', 'tools/v3d-corpus.json', str(destination / 'candidate'), *map(str, candidate), '--reference=' + str(destination / 'main')],
    ['node', 'tools/v3d-bench.mjs', 'compare', str(destination / 'candidate/join-reference'), str(destination / 'candidate'), str(destination / 'comparison.json')],
    ['node', str(ROOT / 'session-cpu-matcher/report-ledger.mjs')],
]
with (destination / 'commands.log').open('w') as log:
    for command in commands:
        subprocess.run(command, cwd=REPO, stdout=log, stderr=subprocess.STDOUT, check=True)
comparison = json.loads((destination / 'comparison.json').read_text())
assert comparison['provenanceCompatible']
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'mainTerminalInputs': len(main), 'strictCandidateTerminalInputs': len(candidate), 'complete': comparison['complete'], 'provenanceCompatible': comparison['provenanceCompatible'], 'neverFails': comparison['neverFails'], 'phoneQuality': comparison['profiles']['phone']['quality'], 'desktopQuality': comparison['profiles']['desktop']['quality'], 'phoneNoSlower': comparison['profiles']['phone']['noSlower'], 'comparisonSha256': hashlib.sha256((destination / 'comparison.json').read_bytes()).hexdigest(), 'fixedReference': str(destination / 'candidate/join-reference'), 'notice': 'Original immutable evaluator, source, view-count rules, assertion thresholds, and budgets. Every original terminal row, including failure, remains. Unpaired native rows remain in the separate full raw ledger; no missing strict candidate result is fabricated.'}
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
