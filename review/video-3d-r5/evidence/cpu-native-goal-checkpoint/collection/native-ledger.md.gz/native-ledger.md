# Protocol 5 cpu-matcher native per-clip ledger

Protocol 5, cpu-matcher candidate only; current native rows only, with explicitly archived harness attempts kept separately; all superseded candidate rows are excluded. Exact native rows retain their original outcomes and provenance. Independent unpaired outcomes, are indexed but cannot establish comparative gains. Partial medians are diagnostics. Acceptance must come from the unchanged production comparator on complete compatible evidence.

## phone

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | explained | explained | verified | — / — | — / — | — / — |
| cat-plays | finished | finished | verified | 0.311 / 0.324 | 54.1 / 34.9 | 680.0 / 520.0 |
| buddha | explained | explained | verified | — / — | — / — | — / — |
| chameleon-flowers | finished | finished | verified | 0.622 / 0.720 | 37.7 / 28.9 | 547.3 / 516.2 |
| dianthus | finished | finished | verified | 0.274 / 0.511 | 64.5 / 46.0 | 573.3 / 528.8 |
| pisac | finished | finished | verified | 0.563 / 0.604 | 45.1 / 28.7 | 594.7 / 511.5 |
| sleeping-dog | explained | explained | verified | — / — | — / — | — / — |
| palace-statue | finished | finished | verified | 0.252 / 0.394 | 44.9 / 25.0 | 671.3 / 512.1 |
| oa-street | explained | explained | verified | — / — | — / — | — / — |
| ullard | finished | finished | verified | 0.460 / 0.466 | 52.2 / 36.3 | 636.7 / 522.6 |
| snaefell | finished | finished | verified | 0.641 / 0.650 | 59.5 / 45.9 | 597.6 / 531.4 |
| fremantle-orbit | finished | finished | verified | 0.715 / 0.822 | 50.3 / 33.5 | 549.9 / 518.6 |
| ihasalu-orbit | finished | finished | verified | 0.485 / 0.694 | 47.7 / 31.0 | 617.9 / 517.8 |
| fresnel-lens | finished | finished | verified | 0.590 / 0.704 | 52.3 / 35.2 | 708.4 / 537.3 |
| saint-denis | finished | finished | verified | 0.246 / 0.276 | 81.4 / 56.0 | 607.1 / 537.2 |
| horse-statue | explained | explained | verified | — / — | — / — | — / — |
| royal-sovereign | finished | finished | verified | 0.578 / 0.783 | 44.4 / 29.5 | 704.9 / 520.4 |
| viljandi-ruins | finished | finished | verified | 0.509 / 0.679 | 68.8 / 33.1 | 811.7 / 519.3 |
| kakerdi-bog | finished | finished | verified | 0.345 / 0.676 | 48.8 / 30.9 | 670.9 / 516.5 |
| fjoloy | harness-error | explained | not established | — / — | — / — | — / — |

## desktop

| Clip | Main | Candidate | Strict reference | SSIM main / candidate | First view seconds main / candidate | Bake seconds main / candidate |
| --- | --- | --- | --- | --- | --- | --- |
| cat-track | timeout | explained | not established | — / — | — / — | — / — |
| cat-plays | explained | explained | verified | — / — | — / — | — / — |
| buddha | timeout | explained | not established | — / — | — / — | — / — |
| chameleon-flowers | timeout | explained | not established | — / — | — / — | — / — |
| dianthus | timeout | harness-error | not established | — / — | — / — | — / — |
| pisac | timeout | explained | not established | — / — | — / — | — / — |
| sleeping-dog | timeout | explained | not established | — / — | — / — | — / — |
| palace-statue | timeout | harness-error | not established | — / — | — / — | — / — |
| oa-street | timeout | explained | not established | — / — | — / — | — / — |
| ullard | timeout | explained | not established | — / — | — / — | — / — |
| snaefell | timeout | explained | not established | — / — | — / — | — / — |
| fremantle-orbit | timeout | explained | not established | — / — | — / — | — / — |
| ihasalu-orbit | timeout | explained | not established | — / — | — / — | — / — |
| fresnel-lens | timeout | harness-error | not established | — / — | — / — | — / — |
| saint-denis | timeout | explained | not established | — / — | — / — | — / — |
| horse-statue | timeout | explained | not established | — / — | — / — | — / — |
| royal-sovereign | not recorded | not recorded | not established | — / — | — / — | — / — |
| viljandi-ruins | not recorded | not recorded | not established | — / — | — / — | — / — |
| kakerdi-bog | not recorded | not recorded | not established | — / — | — / — | — / — |
| fjoloy | not recorded | not recorded | not established | — / — | — / — | — / — |

Nonfinished attempts have no completed-bake or first-view timing in this table. Their censored timing, visible explanation, advice, and original status remain in each raw row. Missing or unpaired measurements cannot establish an improvement.
