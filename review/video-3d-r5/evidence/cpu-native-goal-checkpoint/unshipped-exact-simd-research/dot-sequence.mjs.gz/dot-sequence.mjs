// MIT. Work-only stages, no product or native mutation.
import fs from 'node:fs';
const r=JSON.parse(fs.readFileSync(new URL('./property-check.json',import.meta.url)));if(r.result.length!==2||r.result.some(x=>x.exactVariantComparisons!==600))throw Error('Exact property controls incomplete');
await import('./benchmark-dot.mjs');
const d=JSON.parse(fs.readFileSync(new URL('./results-dot.json',import.meta.url)));if(!d.allOutputsExact||!d.dotBackendStats?.calls)throw Error('Real browser dot controls failed');
await import('./camera-snaefell-inline-dot.mjs');
