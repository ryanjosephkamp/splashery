# MIT. Goal-end cleanup only, made by Ryan with Codex (GPT-6).
from pathlib import Path
import datetime,hashlib,json,os,signal,sys,time
BASE=Path('/workspace/work/v3d-r5/session');PLAN=json.loads((BASE/'goal-end-plan.json').read_text())
def table():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split();result[int(p.name)]={'ppid':int(f[1]),'startTicks':f[19],'status':f[0]}
  except(OSError,ValueError,IndexError):pass
 return result
def valid(x,t):
 return t.get(x['pid'],{}).get('startTicks')==x['startTicks'] and t[x['pid']]['status']!='Z' and hashlib.sha256(Path(x['source']).read_bytes()).hexdigest()==x['sourceSha256']
def record(event,**data):
 item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**data}
 with (BASE/'goal-end-guard-events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
 print(json.dumps(item),flush=True)
if '--check-only' in sys.argv:
 t=table();print(json.dumps({'deadlineUtc':PLAN['deadlineUtc'],'targetIdentityMatches':[valid(x,t) for x in PLAN['targets']],'pidReuseNegativeControl':not valid({**PLAN['targets'][0],'startTicks':'0'},t),'signalsSent':0}));raise SystemExit(0)
record('goal-end-guard-armed',deadlineUtc=PLAN['deadlineUtc'],notice=PLAN['notice'])
while time.time()<PLAN['deadline']:time.sleep(min(30,PLAN['deadline']-time.time()))
t=table();roots=[]
for x in PLAN['targets']:
 if valid(x,t):
  try:os.kill(x['pid'],signal.SIGSTOP);roots.append(x['pid'])
  except ProcessLookupError:pass
 else:record('collector-already-terminal-or-identity-mismatch',pid=x['pid'])
owned={};snapshots={}
for name,file in [('primary','/workspace/work/v3d-r5/final-run/session-cpu-adaptive/collection-state.json'),('protocol6','/workspace/work/v3d-r5/final-run/session-protocol6-control/control-state.json')]:
 try:snapshots[name]=json.loads(Path(file).read_text()).get('active',{})
 except(OSError,ValueError):pass
# Include exact active roots adopted from an earlier orchestration parent.
for active in snapshots.values():
 for item in active.values():
  pid=item.get('pid');ticks=item.get('startTicks');t=table()
  if t.get(pid,{}).get('startTicks')==ticks and pid not in roots:
   roots.append(pid)
   try:os.kill(pid,signal.SIGSTOP)
   except ProcessLookupError:pass
for rep in range(3):
 t=table();group=set(roots);changed=True
 while changed:
  changed=False
  for pid,x in t.items():
   if x['ppid'] in group and pid not in group:group.add(pid);changed=True
 for pid in group:
  if pid not in owned and pid in t:
   owned[pid]=t[pid]['startTicks']
   try:os.kill(pid,signal.SIGSTOP)
   except ProcessLookupError:pass
 time.sleep(.05)
record('goal-end-owned-trees-stopped',roots=roots,ownedStartTicks=owned,activeSnapshots=snapshots,notice='Only exact owned collector descendants are terminated at the predeclared Goal end. Original outcomes stay unchanged; unfinished uploads remain incomplete.')
for sig in [signal.SIGTERM,signal.SIGCONT]:
 t=table()
 for pid,ticks in owned.items():
  if t.get(pid,{}).get('startTicks')==ticks:
   try:os.kill(pid,sig)
   except ProcessLookupError:pass
end=time.time()+2
while time.time()<end:
 t=table()
 if not any(t.get(pid,{}).get('startTicks')==ticks and t[pid]['status']!='Z' for pid,ticks in owned.items()):break
 time.sleep(.1)
t=table()
for pid,ticks in owned.items():
 if t.get(pid,{}).get('startTicks')==ticks and t[pid]['status']!='Z':
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
time.sleep(.1);t=table();remaining=[pid for pid,ticks in owned.items() if t.get(pid,{}).get('startTicks')==ticks and t[pid]['status']!='Z']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadlineUtc':PLAN['deadlineUtc'],'roots':roots,'ownedStartTicks':owned,'activeSnapshots':snapshots,'remainingOwnedProcesses':remaining,'noNativeRowPromoted':True};(BASE/'goal-end-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');record('goal-end-cleanup-terminal',remainingOwnedProcesses=remaining)
