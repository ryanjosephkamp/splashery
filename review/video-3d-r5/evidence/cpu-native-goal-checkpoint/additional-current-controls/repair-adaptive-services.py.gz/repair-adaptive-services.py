# MIT. Repair only detached orchestration monitors; no native process is changed.
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import time

BASE = Path('/workspace/work/v3d-r5')
SCRATCH = BASE / 'session'
PRIMARY = BASE / 'final-run/session-cpu-adaptive'
CONTROL = BASE / 'final-run/session-protocol6-control'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(pid):
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return {'ticks': fields[19], 'state': fields[0]}

def launch(script, log):
    with log.open('a') as stream:
        process = subprocess.Popen(['python3', str(script)], cwd=BASE / 'evaluator-protocol5', stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    return {'pid': process.pid, 'startTicks': identity(process.pid)['ticks'], 'at': now(), 'detachedSession': os.getsid(process.pid) == process.pid}

primary = json.loads((PRIMARY / 'controller-pid.json').read_text())
control = json.loads((CONTROL / 'controller-pid.json').read_text())
for item in [primary, control]:
    actual = identity(item['pid'])
    assert actual['ticks'] == item['startTicks'] and actual['state'] != 'Z'
    assert os.getsid(item['pid']) == item['pid']
source_sha = hashlib.sha256((PRIMARY / 'collect.py').read_bytes()).hexdigest()
helper = SCRATCH / 'keep-adaptive-publisher-on-idle-core.py'
text = helper.read_text()
text, count = re.subn(r'^PID=.*$', f"PID={primary['pid']};TICKS='{primary['startTicks']}';SOURCE='{source_sha}'", text, flags=re.M)
assert count == 1
helper.write_text(text)
metadata = launch(helper, SCRATCH / 'publisher-adaptive-helper.log')
old_guards = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        argv = (path / 'cmdline').read_bytes().split(b'\0')
        if str(SCRATCH / 'goal-end-guard.py').encode() in argv and b'--check-only' not in argv:
            pid = int(path.name)
            old_guards.append({'pid': pid, 'startTicks': identity(pid)['ticks']})
            os.kill(pid, signal.SIGTERM)
    except (OSError, ValueError):
        pass
old_plan = (SCRATCH / 'goal-end-plan.json').read_bytes()
archive = SCRATCH / 'goal-end-plan-before-adaptive.json'
if not archive.exists():
    archive.write_bytes(old_plan)
guard_file = SCRATCH / 'goal-end-guard.py'
source = guard_file.read_text().replace('/final-run/session-cpu-matcher/collection-state.json', '/final-run/session-cpu-adaptive/collection-state.json')
if '# Include exact active roots adopted' not in source:
    needle = 'for rep in range(3):'
    assert source.count(needle) == 1
    addition = """# Include exact active roots adopted from an earlier orchestration parent.
for active in snapshots.values():
    for item in active.values():
        pid = item.get('pid')
        start = item.get('startTicks')
        current = table()
        if current.get(pid, {}).get('startTicks') == start and pid not in roots:
            roots.append(pid)
            try:
                os.kill(pid, signal.SIGSTOP)
            except ProcessLookupError:
                pass
"""
    source = source.replace(needle, addition + needle)
guard_file.write_text(source)
plan = json.loads(old_plan)
plan['targets'] = [{'pid': item['pid'], 'startTicks': item['startTicks'], 'source': str(file), 'sourceSha256': hashlib.sha256(file.read_bytes()).hexdigest()} for item, file in [(primary, PRIMARY / 'collect.py'), (control, CONTROL / 'collect.py')]]
(SCRATCH / 'goal-end-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
check = subprocess.run(['python3', str(guard_file), '--check-only'], capture_output=True, text=True, check=True)
assert all(json.loads(check.stdout)['targetIdentityMatches'])
guard = launch(guard_file, SCRATCH / 'goal-end-guard.log')
time.sleep(0.3)
for item in [metadata, guard]:
    assert identity(item['pid'])['ticks'] == item['startTicks']
    assert identity(item['pid'])['state'] != 'Z'
receipt = {'at': now(), 'primary': primary, 'protocol6WaitingWorker': control, 'protocol6PreviousPlanArchived': str(BASE / 'final-run/session-protocol6-control-before-adaptive-primary'), 'protocol6RuntimeEvaluatorAndBudgetUnchanged': True, 'metadataHelper': metadata, 'goalEndGuard': guard, 'previousGuardProcesses': old_guards, 'goalEndCheck': json.loads(check.stdout), 'nativeUploadsInterrupted': False, 'launchCorrection': 'The first coordinator and prior tool-session guard were not persistent. The coordinator was relaunched detached and adopted the same original native upload. All monitors now run in independent sessions and write to files.'}
(SCRATCH / 'adaptive-continuation-services.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
