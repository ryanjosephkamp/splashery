# MIT. Read-only snapshot metadata only; never move native upload processes.
from pathlib import Path
import datetime,hashlib,json,os,time
ROOT=Path('/workspace/work/v3d-r5/final-run/session-cpu-adaptive')
SESSION=Path('/workspace/work/v3d-r5/session/publisher-adaptive-idle-core-control');SESSION.mkdir(exist_ok=True)
PID=227861;TICKS='3323433';SOURCE='6ce63f35a6355b39c68ecc392802c34f59171ca326dde2619a609535631d29fb'
DEADLINE=datetime.datetime(2026,10,16,13,29,tzinfo=datetime.timezone.utc).timestamp();moved=set()
def record(event,**fields):
 item={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**fields}
 with (SESSION/'events.jsonl').open('a') as f:f.write(json.dumps(item)+'\n')
 print(json.dumps(item),flush=True)
record('metadata-only-plan',controller=PID,controllerStartTicks=TICKS,controllerSha256=SOURCE,notice='Only direct-child main-snapshot joins are eligible. The frozen parent holds its global lock for the complete join lifetime, preventing new native admission. Loan core 2, else 1, only when absent from every active native mask. All existing native allocations, source, options, outcomes, and deadlines remain unchanged. Core 0 is eligible only after its separate control is terminal with no active process. Do not loan a core while review rendering is active.')
while time.time()<DEADLINE:
 try:
  parent=(Path('/proc')/str(PID)/'stat').read_text().rsplit(')',1)[1].split()
  if parent[19]!=TICKS or parent[0]=='Z':record('controller-ended');break
  if hashlib.sha256((ROOT/'collect.py').read_bytes()).hexdigest()!=SOURCE:raise RuntimeError('Controller source changed; admission guarantee is no longer established')
  state=json.loads((ROOT/'collection-state.json').read_text())
  active=state.get('active',{});occupied={c for item in active.values() for c in item['cores']}
  # No core used by primary native, timing, sample, or review work is eligible.
  # The on-disk state can lag a just-admitted launch while another thread
  # waits to write its launch event. Scan actual native processes too.
  for proc in Path('/proc').iterdir():
   if not proc.name.isdigit():continue
   try:
    stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
    if stat[0]=='Z':continue
    argv=(proc/'cmdline').read_bytes().split(b'\0')
    if not argv or not argv[0]:continue
    exe=Path(argv[0].decode(errors='replace')).name
    launcher=len(argv)>2 and argv[1]==b'tools/v3d-affinity.py'
    native_browser=exe.startswith(('chromium','chrome'))
    native_node=exe=='node' and len(argv)>1 and argv[1] in [b'tools/v3d-bench.mjs',b'tools/v3d-review.mjs',b'tools/v3d-bench-samples.mjs']
    if launcher:
     occupied.update(int(c) for c in argv[2].decode().split(','))
    if launcher or native_browser or native_node:
     occupied.update(os.sched_getaffinity(int(proc.name)))
   except (ProcessLookupError,FileNotFoundError):pass
  choices=[2,1]
  control=json.loads(Path('/workspace/work/v3d-r5/final-run/session-protocol6-control/control-state.json').read_text())
  if not control.get('active') and any(e['event'] in ['fresh-control-terminal','fresh-control-not-launched'] for e in control.get('events',[])):choices.append(0)
  core=next((c for c in choices if c not in occupied),None)
  if core is not None:
   for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
     fields=(p/'stat').read_text().rsplit(')',1)[1].split();pid=int(p.name)
     if int(fields[1])!=PID or fields[0]=='Z' or (pid,fields[19]) in moved:continue
     cmd=(p/'cmdline').read_bytes().split(b'\0')
     if len(cmd)<5 or cmd[0]!=b'node' or cmd[1]!=b'tools/v3d-bench-join.mjs' or not cmd[3].startswith(b'/workspace/work/v3d-r5/final-run/main-snapshot-'):continue
     before={}
     for t in (p/'task').iterdir():
      before[t.name]=sorted(os.sched_getaffinity(int(t.name)));os.sched_setaffinity(int(t.name),{core})
     # Recheck threads after changing the spawning thread's inherited mask.
     for t in (p/'task').iterdir():os.sched_setaffinity(int(t.name),{core})
     after={t.name:sorted(os.sched_getaffinity(int(t.name))) for t in (p/'task').iterdir()}
     assert all(mask==[core] for mask in after.values())
     moved.add((pid,fields[19]));record('idle-core-loan',pid=pid,startTicks=fields[19],core=core,activeNativeMasks={k:v['cores'] for k,v in active.items()},before=before,after=after)
    except (ProcessLookupError,FileNotFoundError):pass
 except (ProcessLookupError,FileNotFoundError):record('controller-ended');break
 except (OSError,ValueError) as e:record('read-retry',error=str(e))
 except Exception as e:record('stopped-on-unestablished-safety-condition',error=str(e));break
 time.sleep(2)
record('idle-core-helper-ended',loans=len(moved))
