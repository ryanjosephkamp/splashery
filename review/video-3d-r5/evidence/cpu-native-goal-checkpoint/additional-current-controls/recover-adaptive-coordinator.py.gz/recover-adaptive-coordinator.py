# MIT. Correct only coordinator lifetime; retain every actual native process.
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import time

BASE = Path('/workspace/work/v3d-r5')
SESSION = BASE / 'final-run/session-cpu-adaptive'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def table():
    result = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            result[int(path.name)] = {'ppid': int(fields[1]), 'startTicks': fields[19], 'status': fields[0]}
        except (OSError, ValueError, IndexError):
            pass
    return result

processes = table()
previous = json.loads((SESSION / 'controller-pid.json').read_text())
assert previous['pid'] not in processes or processes[previous['pid']]['status'] == 'Z'
state = json.loads((SESSION / 'collection-state.json').read_text())
assert not any(event['event'] == 'phone-native-complete' for event in state['events'])
assert not any('-desktop-' in tag for tag in state['active'])
archive = BASE / 'final-run/session-cpu-adaptive-before-detach-fix'
assert not archive.exists()
shutil.copytree(SESSION, archive)
adopted = {}
for tag, item in state['active'].items():
    assert tag.startswith(('main-phone-', 'candidate-phone-'))
    pid = item['pid']
    if processes.get(pid, {}).get('startTicks') != item['startTicks'] or processes[pid]['status'] == 'Z':
        continue
    descendants = {pid}
    changed = True
    while changed:
        changed = False
        for child, details in processes.items():
            if details['ppid'] in descendants and child not in descendants:
                descendants.add(child)
                changed = True
    output = Path(item['argv'][9])
    native = json.loads((output / 'run.json').read_text())
    assert native['provenance']['protocolSha256'] == '154576a01c7a624fb63dfb034cd7bb5d94407691472c56554584f54ca34c69e9'
    assert native['provenance']['servedSource']['sha256'] == 'e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571'
    adopted[tag] = {**item, 'owned': {str(child): processes[child]['startTicks'] for child in descendants}, 'originalOutput': str(output), 'originalRunSha256AtTakeover': hashlib.sha256((output / 'run.json').read_bytes()).hexdigest()}
receipt = {'at': now(), 'priorState': state, 'adopted': adopted, 'previousCoordinator': previous, 'previousCoordinatorArchive': str(archive), 'newControllerSha256': hashlib.sha256((SESSION / 'collect.py').read_bytes()).hexdigest(), 'nativeUploadsInterrupted': False, 'notice': 'Correct only the coordinator launch-session lifetime. Every active native upload keeps its original PID, source, CPU mask, output, and deadline. No product or evaluator change, and no native upload is restarted.'}
(SESSION / 'takeover.json').write_text(json.dumps(receipt, indent=2) + '\n')
environment = dict(os.environ, **json.loads((SESSION / 'launch-env.json').read_text()))
validation = subprocess.run(['python3', str(SESSION / 'collect.py'), '--validate-only'], env=environment, cwd=BASE / 'evaluator-protocol5', capture_output=True, text=True, check=True)
(SESSION / 'detach-fix-validation.log').write_text(validation.stdout + validation.stderr)
with (SESSION / 'collection.log').open('a') as log:
    process = subprocess.Popen(['python3', str(SESSION / 'collect.py')], cwd=BASE / 'evaluator-protocol5', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
identity = {'pid': process.pid, 'startTicks': table()[process.pid]['startTicks'], 'at': now(), 'detachedSession': True}
(SESSION / 'controller-pid.json').write_text(json.dumps(identity, indent=2) + '\n')
time.sleep(0.3)
assert process.poll() is None
print(json.dumps({'newPrimary': identity, 'adopted': list(adopted), 'nativeUploadsInterrupted': False, 'validation': json.loads(validation.stdout)}))
