# MIT. Lossless evidence only; no product source or native row is changed.
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import runpy
import sys

BASE = Path('/workspace/work/v3d-r5')
SCRATCH = BASE / 'session'
name = sys.argv[1]
sys.argv = [str(SCRATCH / 'export-cpu-native-progress.py'), name]
context = runpy.run_path(str(SCRATCH / 'export-cpu-native-progress.py'))
destination = context['dest']
copy = context['copy']
corpus = context['corpus']
for folder, label in [('session-cpu-adaptive', 'adaptive-collection'), ('session-cpu-adaptive-before-detach-fix', 'previous-coordinator-lifetime'), ('session-protocol6-control', 'current-separate-protocol6-control'), ('session-protocol6-control-before-adaptive-primary', 'previous-unexecuted-protocol6-plan')]:
    directory = BASE / 'final-run' / folder
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.suffix in ['.py', '.json', '.jsonl', '.log']:
            copy(file, Path(label) / file.name)
for file in sorted((BASE / 'final-run/session-cpu-matcher').glob('*.log')):
    credit = next((clip for clip in corpus if clip['id'] in file.stem), None)
    copy(file, Path('original-primary-native-logs') / file.name, credit=credit)
for file in sorted((SCRATCH / 'simd-research').iterdir()):
    if file.is_file() and file.suffix in ['.mjs', '.json', '.log', '.wasm', '.wat']:
        credit = next(c for c in corpus if c['id'] == ('snaefell' if 'snaefell' in file.name else 'dianthus')) if file.suffix == '.json' and file.name != 'property-check.json' else None
        copy(file, Path('unshipped-exact-simd-research') / file.name, credit=credit)
for folder in ['simd-browser-check', 'simd-camera-dianthus-check', 'simd-camera-dianthus-inline-check', 'simd-camera-snaefell-inline-check', 'simd-dot-sequence-check', 'publisher-adaptive-idle-core-control']:
    for file in sorted((SCRATCH / folder).glob('*')):
        if file.is_file() and file.suffix in ['.json', '.jsonl', '.log']:
            copy(file, Path('additional-work-controls') / folder / file.name)
controls = ['adaptive-dispatch-controls.json', 'adaptive-continuation-services.json', 'check-adaptive-dispatch.py', 'takeover-adaptive-desktop.py', 'recover-adaptive-coordinator.py', 'repair-adaptive-services.py', 'keep-adaptive-publisher-on-idle-core.py', 'goal-end-plan.json', 'goal-end-plan-before-adaptive.json', 'goal-end-guard.py', 'goal-end-guard-events.jsonl', 'build-current-audit.py', 'export-rich-cpu-checkpoint.py', 'export-after-clean-controls.py', 'rich-checkpoint-export-worker.json', 'rich-checkpoint-export-worker-before-review-tag-fix.json', 'cpu-ci-wide-panel-timing-diagnostic.json']
for attempt in [5, 6, 7]:
    controls += [f'cpu-ci-attempt{attempt}-summary.json', f'ci-cpu-attempt{attempt}-shard3-actual.log', f'ci-cpu-attempt{attempt}-summary-actual.log']
for name in controls:
    file = SCRATCH / name
    if file.is_file():
        copy(file, Path('additional-current-controls') / name)
extra_ci = sorted(SCRATCH.glob('cpu-ci-attempt*-summary.json')) + sorted(SCRATCH.glob('ci-cpu-attempt*-actual.log'))
already = {item['file'] for item in context['items']}
for file in extra_ci:
    target = Path('additional-current-controls') / file.name
    if str(target) + '.gz' not in already:
        copy(file, target)
for name in ['adaptive-checkpoint-publication.json', 'movie-evidence-publication.json', 'audit-source-publication.json', 'ci-audit-active.json', 'cpu-phone-complete-comparison.json', 'goal-end-receipt.json', 'cpu-ci-panel-source-review.json', 'collect-current-comparison.py', 'phone-movie-poster-review.json', 'pack-check-during-review.json', 'pack-check-quiet.json', 'pack-check-quiet-plan.json', 'pack-check-quiet-worker.json', 'check-pack-when-quiet.py', 'pack-check-quiet-main.log', 'pack-check-quiet-candidate.log']:
    file = SCRATCH / name
    if file.is_file():
        copy(file, Path('latest-proof-and-publication') / name)
for group in ['cpu-matcher-strict-candidate', 'cpu-matcher-unpaired-candidate']:
    directory = BASE / 'final-run/runs' / group
    for run_file in sorted(directory.glob('*/*/run.json')):
        clip_id = run_file.parent.name.split('-', 1)[1]
        credit = next(c for c in corpus if c['id'] == clip_id)
        for file in sorted((run_file.parent / 'attempts').rglob('*')):
            if file.is_file():
                copy(file, Path('original-native-retry-history') / group / file.relative_to(directory), credit=credit)
for folder in ['phone-timing-control-main', 'phone-timing-control-candidate', 'phone-timing-control-candidate-unpaired']:
    directory = BASE / 'final-run' / folder
    if directory.is_dir():
        for file in sorted(directory.rglob('*')):
            if file.is_file():
                copy(file, Path('separate-clean-phone-timing') / folder / file.relative_to(directory), credit=next(c for c in corpus if c['id'] == 'cat-plays'))
control_plan = json.loads((BASE / 'final-run/session-protocol6-control/plan.json').read_text())
control_output = Path(control_plan['output'])
if (control_output / 'run.json').is_file():
    control_run = json.loads((control_output / 'run.json').read_text())
    if control_run.get('results'):
        for file in sorted(control_output.rglob('*')):
            if file.is_file():
                copy(file, Path('separate-protocol6-native-output') / file.relative_to(control_output), credit=next(c for c in corpus if c['id'] == 'cat-track'))
ledger = json.loads((BASE / 'final-run/session-cpu-matcher/native-ledger.json').read_text())
phone = ledger['profiles']['phone']
ci = []
for file in SCRATCH.glob('cpu-ci-attempt*-summary.json'):
    value = json.loads(file.read_text())
    if isinstance(value.get('attempt'), int) and all(key in value for key in ['passed', 'failed', 'tests', 'specs']):
        ci.append(value)
latest_ci = max(ci, key=lambda item: item.get('at', ''))
movie_file = BASE / 'final-run/cpu-matcher-phone-review/review.json'
movie_count = json.loads(movie_file.read_text()).get('capturedClips', 0) if movie_file.exists() else 0
inventory_file = destination / 'inventory.json'
inventory = json.loads(inventory_file.read_text())
inventory['files'] = context['items']
inventory['authoritativeController'] = 'session-cpu-adaptive'
inventory['notice'] = 'Immutable current-source checkpoint. All original errors and archived retry attempts are retained. Completed phone evidence does not bypass the original global comparator or the failed baseline phone case. Unshipped SIMD controls are not native quality scores.'
inventory_file.write_text(json.dumps(inventory, indent=2) + '\n')
(destination / 'README.md').write_text(f'''# Current phone evidence and adaptive desktop continuation

Captured at {inventory['at']} from frozen source f1f7f339, against the original main
5a55f5cc baseline and unchanged protocol-5 evaluator 0406a781. The candidate runtime is
e61e943343a7f76e07f6ec6baffecc9bd562e465750eab40ceca2782b4ddf571.
Every original input hash, outcome, artifact, and source license is preserved in the inventory.
All original and stored file hashes are verified. Complete acceptance remains unproven.

At the native ledger's own capture, all {phone['candidateAccounted']}/20 R5 phone outcomes are
accounted for, with {phone['qualityPairs']} verified paired successes. Observed median sharpness is
{phone['diagnosticSharpnessRatio']:.6f} times main's, and SSIM is up {phone['diagnosticSsimGain']:.6f}.
No missing, rejected, or unverified image receives a score. These phone observations do not
bypass the unchanged global comparator's complete-cohort requirement.

The predeclared single fresh phone-lens retry completed and independently verified every
original input and frozen main held-out view. The original callback error, run, and model
are archived, with the old error also preserved at the earlier immutable b812f82a checkpoint.
Every replacement outcome is retained; no diagnostic source proof promotes an old native row.
Main Fjoloy has two uncaught null-input worker errors during relaxed retry. R5 preserves
the inputs and gives clear advice about its two-camera result. The baseline failure stays
unpaired, and full-profile best/worst ranks remain withheld. At this capture, {movie_count}/10
source-bound paired movies are captured. Their actual state is in the controller record.

Phone timing confirmation and movies run without timed desktop bakes. Desktop dispatch then
uses every available core for a ready candidate or the next unrun baseline, with one core per
case, original limits, fixed sources, and no previous outcome replaced. Core 0 first belongs
to the separate protocol-6 native control. Concurrency controls verify unique claims, baseline
advertisement, media isolation, and the reservation. Only orchestration was replaced; active
native processes retained their original identities, allocations, source, and timing. The first
coordinator launch did not persist after setup; its complete records are archived, and the
corrected detached coordinator adopted the same still-running native upload. The independent
Goal-end guard checks original process identities and preserves every incomplete outcome.

The six samples retain all 74 exact, nonblank views across both profiles. The complete prior
sample checkpoint contains all 148 PNGs, original inventory/camera/tier checks, and full credits:
https://github.com/ryanjosephkamp/splashery/tree/ae793c050c42fbfb7d22a8eacfff51652a48d8aa/review/video-3d-r5/evidence/cpu-matcher-checkpoint

The unchanged private calibration spec passed all twelve cases, zero skipped and zero retries,
with the exact original licensed inputs. Only scalar receipts and public source/checksum records
are included. Private media, screenshots, traces, and detailed reports remain outside all public
and repository branches. All 348 original specs remain byte-identical; no test, threshold,
assertion, deadline, or skip is reduced or waived. The latest completed normal full integration
at this capture retains {latest_ci['passed']:,} passed, {latest_ci['failed']} failed, and
{latest_ci.get('existingSkipped', 1)} preexisting conditional skip, in run {latest_ci['run']},
attempt {latest_ci['attempt']}. Original normal failures still count even when present on main.

Unshipped exact SIMD research is labeled separately. Both kernels pass the 600 synthetic
variant checks each, actual-browser real-descriptor parity, input ownership, and real timer
cancellation. Descriptor matching improves substantially. The flower control solves seventeen
exact camera poses with the same input JPEGs and a point count of 5,257 in 148.049 seconds,
against the earlier 229.745-second control. Individual point coordinates were not compared.
Both harder landscape variants reach the unchanged camera deadline without a finished solve.
The first asynchronous wrapper also failed before matching; the corrected inline wrapper and
all failed attempts are retained. No prototype is shipped, no native score is substituted,
and no physical-phone performance or universal speedup is claimed. The compiler package itself
is excluded; the WAT source and compiled modules contain only this work's MIT code.

Every derived native picture, model, and real-source descriptor retains its recorded author,
source, license, checksum, and transformation. Research data use the corresponding dianthus or
Snaefell corpus record; synthetic property checks and code are MIT, made by Ryan with Codex (GPT-6).
The earlier immutable checkpoint attached the flower reference context to its synthetic receipt;
that receipt contains generated descriptors, with no source image or real descriptor data.
Gzip preserves original
bytes; PNG, PLY, WASM, and other binary bytes are unchanged. Never merge this evidence branch.
''')
for entry in inventory['files']:
    stored = (destination / entry['file']).read_bytes()
    original = gzip.decompress(stored) if entry['file'].endswith('.gz') else stored
    assert hashlib.sha256(stored).hexdigest() == entry['storedSha256']
    assert hashlib.sha256(original).hexdigest() == entry['originalSha256']
print(json.dumps({'folder': str(destination), 'originals': len(inventory['files']), 'nativeRows': len(inventory['nativeCases']), 'allOriginalAndStoredHashesVerified': True}))
