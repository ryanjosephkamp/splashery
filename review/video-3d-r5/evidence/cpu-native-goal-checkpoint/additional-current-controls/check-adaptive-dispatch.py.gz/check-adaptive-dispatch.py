# MIT. Focused read-only concurrency/admission controls for the prepared continuation.
from pathlib import Path
import ast,concurrent.futures,datetime,hashlib,json,tempfile,threading,time
base=Path('/workspace/work/v3d-r5');old=(base/'final-run/session-cpu-matcher/collect.py').read_text();source=(base/'final-run/session-cpu-adaptive/collect.py').read_text()
def functions(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a=functions(old);b=functions(source);unchanged=['command','one','phone','retry_phone_harness','publish_main','candidate_join','validate_early_samples','extra_lane_ready','desktop_claim']
assert all(a[x]==b[x] for x in unchanged)
assert 'desktop-main' not in source[source.index('with concurrent.futures.ThreadPoolExecutor'):]
with tempfile.TemporaryDirectory(prefix='adaptive-controls-',dir=base/'session') as tmp:
 root=Path(tmp);clips=[{'id':f'c{i:02d}'}for i in range(1,21)];records=[];lock=threading.RLock();request=threading.Event();finish=threading.Event();claims={'main':set(range(1,14)),'candidate':set(range(1,13))};state={'events':[{'event':'isolated-media-window-released'}]}
 def write(i,rows):
  p=root/'runs/main/desktop'/f'{i:02d}-c{i:02d}';p.mkdir(parents=True,exist_ok=True);(p/'run.json').write_text(json.dumps({'results':rows}))
 def master(ids):
  p=root/'main-reference';p.mkdir(exist_ok=True);(p/'run.json').write_text(json.dumps({'results':[{'id':f'c{i:02d}','profile':'desktop'}for i in ids]}))
 for i in range(1,14):write(i,[{'id':f'c{i:02d}','profile':'desktop','status':'timeout'}])
 master(range(1,14))
 scope={'lock':lock,'DESKTOP_CLAIMS':claims,'CLIPS':clips,'MEDIA_REQUESTED':request,'MEDIA_FINISHED':finish,'ROOT':root,'Path':Path,'json':json,'record':lambda event,**data:records.append({'event':event,**data}),'accounted':lambda r:r['status']in['finished','explained'],'state':state,'time':time,'DEADLINE':time.time()+20}
 exec('\n\n'.join(b[x]for x in ['desktop_claim','adaptive_claim','extra_lane_ready']),scope)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:answers=list(pool.map(lambda _:scope['adaptive_claim'](),range(4)))
 assert sum(x[0]=='candidate' for x in answers)==1
 cand=next(x for x in answers if x[0]=='candidate');assert cand[1]==13 and cand[3]is False
 assert sorted(x[1]for x in answers if x[0]=='main')==[14,15,16]
 request.set();before={k:set(v)for k,v in claims.items()}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:blocked=list(pool.map(lambda _:scope['adaptive_claim'](),range(4)))
 assert blocked==[None]*4 and claims==before
 finish.set();write(14,[]);master(range(1,15));x=scope['adaptive_claim']();assert x[0]=='main'and x[1]==17
 write(14,[{'id':'c14','profile':'desktop','status':'timeout'}]);master(range(1,14));x=scope['adaptive_claim']();assert x[0]=='main'and x[1]==18
 master(range(1,15));x=scope['adaptive_claim']();assert x[0]=='candidate'and x[1]==14 and x[3]is False
 write(15,[{'id':'c15','profile':'desktop','status':'explained'}]);master(range(1,16));x=scope['adaptive_claim']();assert x[0]=='candidate'and x[1]==15 and x[3]is True
 keys=[(r['version'],r['index'])for r in records];assert len(keys)==len(set(keys))
 control=root/'session-protocol6-control';control.mkdir();file=control/'control-state.json';file.write_text(json.dumps({'events':[],'active':{}}))
 scope['extra_lane_ready']('main')
 with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:
  f=pool.submit(scope['extra_lane_ready'],'candidate');time.sleep(.1);assert not f.done();file.write_text(json.dumps({'events':[{'event':'fresh-control-terminal'}],'active':{'owned':1}}));time.sleep(.6);assert not f.done();file.write_text(json.dumps({'events':[{'event':'fresh-control-terminal'}],'active':{}}));f.result(timeout=2)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'collectorSha256':hashlib.sha256(source.encode()).hexdigest(),'nineNativeMediaAndReferenceFunctionsByteIdentical':unchanged,'concurrentClaimsUnique':True,'readyCandidateBeforeNextUnrunBaseline':True,'noCandidateBeforeBaselineTerminalAndAdvertised':True,'timeoutBaselineRemainsUnpaired':True,'accountedBaselineGetsStrictReference':True,'mediaGateAtomicForAllFourWorkers':True,'coreZeroWaitsForOriginalControlTerminalAndNoActiveProcess':True,'nativeUploadsLaunched':0,'notRunningYet':True}
(base/'session/adaptive-dispatch-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
