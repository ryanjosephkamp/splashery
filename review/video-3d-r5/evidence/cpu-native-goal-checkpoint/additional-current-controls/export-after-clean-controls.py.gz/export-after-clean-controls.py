# MIT. Wait for timing isolation before copying evidence. No browser or bake is launched.
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

BASE = Path('/workspace/work/v3d-r5')
PRIMARY = BASE / 'final-run/session-cpu-adaptive'
OUT = BASE / 'session/rich-checkpoint-export'
OUT.mkdir(exist_ok=True)
expected = '6ce63f35a6355b39c68ecc392802c34f59171ca326dde2619a609535631d29fb'
end = datetime.datetime(2026, 10, 16, 13, 10, tzinfo=datetime.timezone.utc).timestamp()
while time.time() < end:
    assert hashlib.sha256((PRIMARY / 'collect.py').read_bytes()).hexdigest() == expected
    state = json.loads((PRIMARY / 'collection-state.json').read_text())
    if any(event['event'] == 'clean-phone-timing-controls-complete' for event in state['events']):
        assert not any(tag.startswith(('clean-timing-', 'main-phone-', 'candidate-phone-', 'phone-harness-retry-')) for tag in state.get('active', {}))
        break
    time.sleep(2)
else:
    raise RuntimeError('Clean timing controls did not finish before the evidence window')
with (OUT / 'export.log').open('w') as log:
    commands = [
        ['nice', '-n', '19', 'taskset', '-c', '3', 'node', str(BASE / 'final-run/session-cpu-matcher/report-ledger.mjs')],
        ['nice', '-n', '19', 'taskset', '-c', '3', 'python3', str(BASE / 'session/export-rich-cpu-checkpoint.py'), 'cpu-native-adaptive-checkpoint'],
    ]
    for command in commands:
        subprocess.run(command, cwd=BASE / 'clips', stdout=log, stderr=subprocess.STDOUT, check=True)
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exportCompleted': True, 'noTimedPhoneWorkDuringCopy': True, 'folder': 'review/video-3d-r5/evidence/cpu-native-adaptive-checkpoint'}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
