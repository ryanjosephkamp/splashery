import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { makeWoven, squareSample, FG, BG } from '../../../src/qr-craft/picture.js';
import { weaveDetail } from '../../../src/qr-craft/detail.js';
import { fitPadding } from '../../../src/qr/picture-padding.js';
import { encodeQR } from '../../../src/qr/encode.js';
import { rotateCode, inversePicture } from '../../../src/qr-craft/orientation.js';
import { cropCirclePicture, textureFrame } from '../../../src/qr-craft/frame.js';
import { shapeHalf } from '../../../src/qr/circle.js';
import { validateDetail } from '../../../src/qr-craft/scan-pool.js';
import { loadBlurKernel } from '../../../src/qr-craft/fast-blur.js';
import { loadSecondReader } from '../../../src/qr-craft/second-reader.js';
import { read } from '../../../tools/qrc-picture.mjs';
import { loadBrowserSource } from '../../../tools/picture-qr-fidelity/sources.mjs';
import { capturedFidelity } from '../../../tools/picture-qr-fidelity/metrics.mjs';
import { LINKS } from '../../../tools/cdx-circle-study.mjs';
await loadBlurKernel(fs.readFileSync('src/qr-craft/blur.wasm'));
await loadSecondReader(fs.readFileSync('src/qr-craft/vendor/zxing/reader/zxing_reader.wasm'));
let source=fs.readFileSync('src/qr-craft/picture.js','utf8').replace(/from "(\.{1,2}\/[^"\n]+)"/g,(_m,p)=>'from '+JSON.stringify(new URL(p,pathToFileURL(process.cwd()+'/src/qr-craft/picture.js')).href));
source=source.replace('o.channel !== "green" &&\n        o.channel !== "weighted" &&','');
const {makeWoven:correctedWoven}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const keys=JSON.parse(fs.readFileSync('.cache/picture-qr-fidelity/review-pass/guard-cases.json'));
const out='.cache/picture-qr-fidelity/review-pass/strategy-probe.jsonl';
for(const key of keys){
 const [id,linkText,shape]=key.split('/'),link=Number(linkText),full=loadBrowserSource(id);
 const o={text:LINKS[link],fidelity:'detail',shape,level:'H',size:'more',center:'small',contrast:.5,style:'color',preferContinuous:true,texture:'tiles',channel:'weighted',finderGuard:3};
 const first=makeWoven(full,o),pic=shape==='circle'?cropCirclePicture(full,first.code.size):full;
 const strategies=[['current',first],['correction',correctedWoven(full,{...o,preferCorrection:true})]];
 if(link!==0 || id==='cdx-qr-ai-fern'){
  const base=encodeQR(o.text,o.level,{boost:false,min:first.code.version,mask:first.code.mask});
  for(const turn of [1,2,3]){
   const code=rotateCode(fitPadding(base,inversePicture(pic,base.size,turn)),turn);
   strategies.push(['rotate-'+turn,weaveDetail(code,pic,{...o,margin:.16,finderEdge:.24})]);
  }
  const code=fitPadding(encodeQR(o.text,o.level,{boost:false,min:first.code.version,mask:0}),pic);
  strategies.push(['mask-0',weaveDetail(code,pic,{...o,margin:.16,finderEdge:.24})]);
 }
 for(const [strategy,w]of strategies){
  w.rendering.texture='tiles';w.rendering.validation='model';
  const check=await validateDetail(w,full,shape,read),image=textureFrame(w,full,shape),modules=2*(shapeHalf(w.code.size,shape)+1);
  const scores=capturedFidelity(pic,image,w.code.size,modules);
  const sample=squareSample(pic,w.code.size);let functionError=0;
  for(let i=0;i<w.code.role.length;i++)if(w.code.role[i])for(let ch=0;ch<3;ch++)functionError+=(sample[i*3+ch]-(w.code.dark[i]?FG[ch]:BG[ch]))**2;
  fs.appendFileSync(out,JSON.stringify({key,strategy,check,scores,functionError,method:w.rendering.method,rotation:w.code.rotation||0,mask:w.code.mask})+'\n');
 }
 console.log(key);
}
