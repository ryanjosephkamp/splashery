import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { SAMPLES } from '../../../src/qr-craft/samples.js';
import { makeWoven } from '../../../src/qr-craft/picture.js';
import { cropCirclePicture, textureFrame } from '../../../src/qr-craft/frame.js';
import { shapeHalf } from '../../../src/qr/circle.js';
import { LINKS } from '../../../tools/cdx-circle-study.mjs';
import { capturedFidelity } from '../../../tools/picture-qr-fidelity/metrics.mjs';
import { loadBrowserSource } from '../../../tools/picture-qr-fidelity/sources.mjs';
const source=fs.readFileSync('src/qr-craft/detail.js','utf8').replace('"./picture.js"',JSON.stringify(pathToFileURL(process.cwd()+'/src/qr-craft/picture.js').href));
const variants=[];
for(const blend of [0,.25,.5,1]){
 let code=source;
 code=code.replace('delta * luminance[ch]',`delta * (${1-blend} * luminance[ch] + ${blend}/3)`);
 code=code.replace('luminance[ch] ** 2',`luminance[ch] * (${1-blend} * luminance[ch] + ${blend}/3)`);
 variants.push([blend,(await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'))).weaveDetail]);
}
const requested=(process.argv[2]||'all').split(',');
const corpus=[...SAMPLES,...JSON.parse(fs.readFileSync('tools/picture-qr-fidelity/corpus.json'))].filter(p=>requested.includes('all')||requested.includes(p.id));
const out='.cache/picture-qr-fidelity/review-pass/color-probe.jsonl';
for(const picture of corpus)for(const shape of ['square','circle']){
 const full=loadBrowserSource(picture.id),options={text:LINKS[0],fidelity:'detail',shape,level:'H',size:'more',center:'small',contrast:.5,style:'color',preferContinuous:true,texture:'tiles',channel:'weighted'};
 const first=makeWoven(full,options),pic=shape==='circle'?cropCirclePicture(full,first.code.size):full;
 for(const [blend,weave]of variants){
 const w=weave(first.code,pic,{...options,margin:.16,finderEdge:.24});
 w.rendering.texture='tiles';
 const image=textureFrame(w,full,shape),modules=2*(shapeHalf(w.code.size,shape)+1);
 const scores=capturedFidelity(pic,image,w.code.size,modules);
 fs.appendFileSync(out,JSON.stringify({picture:picture.id,shape,blend,scores})+'\n');
 }
 console.log(picture.id,shape);
}
