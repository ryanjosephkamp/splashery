import { chromium } from '@playwright/test';
const browser = await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const page=await browser.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});
page.on('pageerror',e=>console.log(e.message));
await page.goto('http://127.0.0.1:4173/?renderer=webgl2&adapt=off&profile=low&labs=1');
await page.waitForSelector("body[data-ready='true']",{timeout:180000});
console.log(JSON.stringify(await page.evaluate(async()=>{
 const {app:a}=window.__splashery, {RECIPES}=await import('/src/packs/qr-craft.js');
 const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
 const ctx=canvas.getContext('2d');let value=64;
 RECIPES['qr-picture']={
  build(k){k.reach([-.6,-.6,-.1]);k.reach([.6,.6,.1]);k.cloud({share:1/k.count,jitter:0,pattern:false},()=>({p:[0,0,0],scales:[.26,.26,.004],quat:[0,0,0,1],color:[1,1,1],opacity:1,photo:true,params:[1,0],pattern:false}));},
  photo:{rect:()=>[-.5,-.5,.5,.5],version:()=>value,source:()=>canvas,tiles:()=>[1,0,0,0]},
 };
 const rows=[];
 for(value of [64,128,192]){
 ctx.fillStyle=`rgb(${value},${value},${value})`;ctx.fillRect(0,0,64,64);
 await a.chooseToy('qr-picture');
 const rgb=await a.withCapture([256,256],async()=>{
  const pose={yaw:0,pitch:0,roll:0,distance:3};
  await a.player.renderAt(a.player.time,pose);
  await new Promise(r=>setTimeout(r,120));
  const shot=await a.player.renderAt(a.player.time,pose);
  return [...shot.getContext('2d').getImageData(128,128,1,1).data];
 });rows.push({input:value,output:rgb});
 }
 return rows;
}),null,2));
await browser.close();
