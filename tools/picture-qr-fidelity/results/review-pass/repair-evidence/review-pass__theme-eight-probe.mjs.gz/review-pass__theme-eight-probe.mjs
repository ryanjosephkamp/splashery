import {chromium} from '../../../node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try {
 const page=await browser.newPage({viewport:{width:390,height:844}});
 await page.addInitScript(()=>Object.defineProperty(navigator,'hardwareConcurrency',{get:()=>4}));
 await page.goto('http://127.0.0.1:4173/?renderer=webgl2&adapt=off&profile=low&labs=1');
 await page.waitForSelector("body[data-ready='true']",{timeout:180000});
 const rows=await page.evaluate(async()=>{
  await import('/src/packs/qr-craft.js');const{app,qrCraft:q}=window.__splashery;q.autoCheck=false;await app.chooseToy('qr-picture');
  const {SAMPLES}=await import('/src/qr-craft/samples.js');const sample=SAMPLES.find(p=>p.id==='cdx-theme-seasons-2-2');
  const bmp=await createImageBitmap(await(await fetch('/'+sample.file)).blob());const f=Math.min(1,640/Math.max(bmp.width,bmp.height));const c=document.createElement('canvas');c.width=Math.round(bmp.width*f);c.height=Math.round(bmp.height*f);c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);bmp.close();const bytes=c.getContext('2d').getImageData(0,0,c.width,c.height).data;const data=new Float32Array(c.width*c.height*3);for(let i=0;i<c.width*c.height;i++)for(let ch=0;ch<3;ch++)data[i*3+ch]=bytes[i*4+ch]/255;const full={w:c.width,h:c.height,data};
  const {encodeQR}=await import('/src/qr/encode.js');const{fitPadding}=await import('/src/qr/picture-padding.js');const{fitPictureErrors}=await import('/src/qr/picture-errors.js');const{weaveDetail}=await import('/src/qr-craft/detail.js');const{validateDetail,cancelDetailChecks}=await import('/src/qr-craft/scan-pool.js');const{cropCirclePicture}=await import('/src/qr-craft/frame.js');const{loadBlurKernel}=await import('/src/qr-craft/fast-blur.js');const{loadRasterKernel}=await import('/src/qr-craft/fast-raster.js');await Promise.all([loadBlurKernel(),loadRasterKernel()]);
  const read=(data,w,h)=>(window.jsQR.default||window.jsQR)(data,w,h,{inversionAttempts:'dontInvert'})?.data??null;
  const text="https://example.org/a/9?q=circlecirclecirclecirclecirclecirclecirclecircle&page=8";const pic=cropCirclePicture(full,65);const rows=[];
  for(const settings of [{guard:3,edge:0.32,core:.08,margin:.16},{guard:3,edge:0.36,core:.08,margin:.16},{guard:3,edge:0.38,core:.08,margin:.16},{guard:3,edge:0.4,core:.08,margin:.16},{guard:3,edge:0.42,core:.08,margin:.16},{guard:3,edge:0.44,core:.08,margin:.16},{guard:3,edge:0.46,core:.08,margin:.16}]){const mask=0;
   const code=fitPadding(encodeQR(text,'H',{boost:false,min:12,mask}),pic);
   const w=weaveDetail(fitPictureErrors(code,pic,.4),pic,{shape:'circle',level:'H',style:'color',center:'small',contrast:.5,margin:settings.margin,finderEdge:settings.edge,finderCore:settings.core,finderGuard:settings.guard,channel:'weighted',method:'correction'});
   Object.assign(w.rendering,{texture:'tiles',textureBlur:0,textureGuard:0,validation:'capture',fraction:.4});
   const start=performance.now();const check=await validateDetail(w,full,'circle',read);rows.push({mask,...settings,ms:performance.now()-start,check});
  }
  cancelDetailChecks();return rows;
 });console.log(JSON.stringify(rows,null,2));
}finally{await browser.close();}
