import fs from 'node:fs';
import { chromium } from '../../../node_modules/@playwright/test/index.mjs';
const launch=chromium.launch.bind(chromium);
const source=fs.readFileSync('.cache/picture-qr-fidelity/review-pass/moon-more-picture.js','utf8');
chromium.launch=async (...args)=>{
 const browser=await launch(...args);const create=browser.newPage.bind(browser);
 browser.newPage=async (...options)=>{
  const page=await create(...options);
  await page.route('**/src/qr-craft/picture.js',route=>route.fulfill({contentType:'text/javascript',body:source}));
  return page;
 };
 return browser;
};
