// DIAGNOSTIC ORACLE: uses true depth to calibrate each face, never a deployable method.
import { ids, load, direction, project, sample, save } from "./common.mjs";
const rows = [];
for (const id of ids) {
  const { truth, mask, tiles, w, h } = await load(id), results = {};
  for (const mode of ["invZ", "invR", "Z", "R"]) for (const overlapOnly of [false, true]) {
    const sums = tiles.map(() => ({ sw: 0, sx: 0, sy: 0, sxx: 0, sxy: 0, n: 0 }));
    for (let i = 0; i < truth.length; i++) if (mask[i] === 1 && truth[i] > 0) {
      const u = (i % w + 0.5) / w, v = (Math.floor(i / w) + 0.5) / h;
      const ray = direction(u, v), views = tiles.map((t) => project(ray, t));
      if (overlapOnly && views.filter(Boolean).length < 2) continue;
      views.forEach((p, j) => {
        if (!p) return;
        const t = tiles[j], x = sample(t.d, t.w, t.h, p.u, p.v, 1, 0, false);
        const y = mode === "invZ" ? 1 / (truth[i] * p.cosine) : mode === "invR" ? 1 / truth[i] : mode === "Z" ? truth[i] * p.cosine : truth[i];
        const weight = Math.sin(v * Math.PI) * p.weight, s = sums[j];
        s.sw += weight; s.sx += weight * x; s.sy += weight * y;
        s.sxx += weight * x * x; s.sxy += weight * x * y; s.n++;
      });
    }
    const fits = sums.map((s) => {
      const a = (s.sxy - s.sx * s.sy / s.sw) / (s.sxx - s.sx * s.sx / s.sw);
      return { a, b: (s.sy - a * s.sx) / s.sw, n: s.n };
    });
    let error = 0, weight = 0;
    for (let i = 0; i < truth.length; i++) if (mask[i] === 1 && truth[i] > 0) {
      const u = (i % w + 0.5) / w, v = (Math.floor(i / w) + 0.5) / h, ray = direction(u, v);
      let sum = 0, weights = 0;
      tiles.forEach((t, j) => {
        const p = project(ray, t); if (!p || !fits[j].n) return;
        const q = fits[j].a * sample(t.d, t.w, t.h, p.u, p.v, 1, 0, false) + fits[j].b;
        const inverse = mode === "invZ" ? q * p.cosine : mode === "invR" ? q : mode === "Z" ? p.cosine / q : 1 / q;
        if (inverse > 0) { sum += p.weight * inverse; weights += p.weight; }
      });
      if (weights) { const q = Math.sin(v * Math.PI); error += q * Math.abs(weights / sum - truth[i]) / truth[i]; weight += q; }
    }
    results[mode + (overlapOnly ? "-overlap" : "-full")] = { absRel: error / weight, fits };
  }
  rows.push({ id, results }); console.log(id, results["invZ-full"].absRel, results["invZ-overlap"].absRel);
}
await save("oracle-affine-results.json", { note: "Ground-truth calibration. No production claim. invZ means an affine model prediction of inverse perspective Z, then cosine conversion to radial inverse depth. The same calibration set is scored; these are diagnostic upper-bound measurements.", scenes: rows });
