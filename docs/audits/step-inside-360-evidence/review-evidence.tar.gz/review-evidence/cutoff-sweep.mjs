// Fixed non-oracle threshold sweep, preserving the exact pre-sky-fix experiment.
import { ids, load, score, mathVariant, save } from "./common.mjs";
const rows = [];
for (const id of ids) {
  const fixture = await load(id), results = {};
  for (const cutoff of [0.05, 0.1, 0.2, 0.3, 0.5]) {
    const m = await mathVariant({ positive: false, cutoff, fallback: 30 });
    const alignment = m.alignTiles(fixture.tiles);
    results[cutoff] = {
      absRel: score(fixture, m.fuseDepth(fixture.tiles, alignment)).absRel,
      noClipAbsRel: score(fixture, m.fuseDepth(fixture.tiles, alignment, 512, 256, { normalize: false })).absRel,
      overlapDisagreement: alignment.seamMedian,
    };
  }
  rows.push({ id, results }); console.log(id, JSON.stringify(results));
}
await save("cutoff-sweep-results.json", { note: "No oracle information enters fitting. Allows negative shifts, filters sampled overlap raw/median <= cutoff, and uses radius-30 fallback BEFORE normalization. The normalizer still includes fallback rays, intentionally reproducing the issue diagnosed in review. noClipAbsRel uses fuseDepth normalize:false and metric median scale calibration. These variants do not include later production neighbor validity tests or tile reliability.", scenes: rows });
