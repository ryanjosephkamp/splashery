// No truth enters fitting. Truth is used only by scoreDepth after fit/fusion.
// Tests residual normalization, priors, gauge anchors, and iteration convergence.
import fs from "node:fs/promises";
import path from "node:path";
import jpeg from "jpeg-js";
import { ids, root, directory, load, save } from "./common.mjs";
import * as frozen from "./calibration-start-core.mjs";
const { perspective, tileReliability, project, direction, sample } = frozen;
const source = await fs.readFile(path.join(directory, "calibration-start-core.mjs"), "utf8");
const settings = [
  { id: "current" },
  { id: "iterations20", iterations: 20 },
  { id: "coordinate3000", sweeps: 3000 },
  ...["fixed", "dynamic"].flatMap((mode) => [0.04, 0.1, 0.2].map((huber) => ({ id: `${mode}-relative-${huber}`, mode, huber }))),
  ...[0.01, 0.1, 1, 10, 100].map((scalePrior) => ({ id: `scale-prior-${scalePrior}`, scalePrior })),
  ...[0.01, 0.1, 1, 10].map((scalePrior) => ({ id: `both-prior-${scalePrior}`, scalePrior, shiftPrior: scalePrior })),
  ...[1, 2, 3, 5].map((anchor) => ({ id: `anchor-${anchor}`, anchor })),
];

function median(input) {
  const a = Array.from(input).filter(Number.isFinite); if (!a.length) return 0;
  const k = Math.floor(a.length / 2); let low = 0, high = a.length - 1;
  while (low < high) {
    const pivot = a[Math.floor((low + high) / 2)]; let i = low, j = high;
    while (i <= j) {
      while (a[i] < pivot) i++; while (a[j] > pivot) j--;
      if (i <= j) { [a[i], a[j]] = [a[j], a[i]]; i++; j--; }
    }
    if (k <= j) high = j; else if (k >= i) low = i; else break;
  }
  return a[k];
}

async function makeMath(c) {
  let text = source;
  const replace = (before, after) => { if (!text.includes(before)) throw new Error("Missing research transform: " + before.slice(0, 60)); text = text.replace(before, after); };
  replace("iteration < 5", `iteration < ${c.iterations || 5}`);
  replace("sweep < 300", `sweep < ${c.sweeps || 300}`);
  replace("m[i][i] += 0.0001;", `m[i][i] += i % 2 ? ${c.scalePrior || 0.0001} : ${c.shiftPrior || 0.0001};`);
  replace("b[i] += 0.0001 * (i % 2 ? 1 : 0);", `b[i] += ${c.scalePrior || 0.0001} * (i % 2 ? 1 : 0);`);
  if (c.mode) {
    const helper = `
function researchMagnitude(r, target, current, dynamic) {
  const fit = dynamic ? current : Array.from({length:11}, (_,i)=>i%2?1:0);
  let sum = r[0] ? Math.abs(-target + r[0]*fit[0]) : 0;
  for(let i=1;i<11;i+=2) sum += Math.abs(r[i]*fit[i]+r[i+1]*fit[i+1]);
  return Math.max(0.01, sum/2);
}
`;
    text = helper + text;
    replace("const w = weight * Math.min(1, 0.04 / Math.max(1e-8, residual));", `const denominator=researchMagnitude(r,target,fit,${c.mode === "dynamic"}); const relative=residual/denominator; const w=weight/(denominator*denominator)*Math.min(1,${c.huber}/Math.max(1e-8,relative));`);
  }
  return import("data:text/javascript;base64," + Buffer.from(text).toString("base64"));
}
const modules = await Promise.all(settings.map(makeMath));

function projections(tiles, w = 512, h = 256) {
  const cached = tiles.map(() => ({ raw: new Float64Array(w * h), cosine: new Float64Array(w * h), weight: new Float64Array(w * h) }));
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = y * w + x, ray = direction((x + 0.5) / w, (y + 0.5) / h);
    tiles.forEach((t, j) => { const p = project(ray, t); if (!p || t.reliability === 0) return; cached[j].raw[i] = sample(t.d, t.w, t.h, p.u, p.v, 1, 0, false); cached[j].cosine[i] = p.cosine; cached[j].weight[i] = p.weight; });
  }
  return { cached, w, h };
}
function fuse(cached, alignment, w, h) {
  const d = new Float32Array(w * h); let supported = 0;
  for (let i = 0; i < d.length; i++) {
    let sum = 0, weights = 0;
    cached.forEach((v, j) => { if (!v.weight[i]) return; const a = alignment.transforms[j], inverse = (a.a * v.raw[i] + a.b) * v.cosine[i]; if (inverse > 1e-6) { sum += v.weight[i] * inverse; weights += v.weight[i]; } });
    d[i] = weights ? weights / sum : NaN; if (weights) supported++;
  }
  const scale = 3 / Math.max(1e-6, median(d)); let nearClipped = 0;
  for (let i = 0; i < d.length; i++) { if (Number.isFinite(d[i])) { if (d[i] * scale < 0.6) nearClipped++; d[i] = Math.max(0.6, Math.min(30, d[i] * scale)); } else d[i] = 30; }
  return { d, w, h, supported, nearClipped, normalizeScale: scale };
}
function scoreDepth(f, depth) {
  const { truth, mask, w, h } = f;
  const prediction = Float32Array.from(truth, (_, i) => sample(depth.d, depth.w, depth.h, (i % w + 0.5) / w, (Math.floor(i / w) + 0.5) / h));
  const scale = median(Array.from(truth, (t, i) => mask[i] === 1 && t > 0 ? t / prediction[i] : NaN));
  let error = 0, weight = 0, delta = 0;
  for (let i = 0; i < truth.length; i++) if (mask[i] === 1 && truth[i] > 0) {
    const q = Math.sin(Math.PI * (Math.floor(i / w) + 0.5) / h), p = prediction[i] * scale;
    error += q * Math.abs(p - truth[i]) / truth[i]; delta += q * (Math.max(p / truth[i], truth[i] / p) < 1.25 ? 1 : 0); weight += q;
  }
  return { absRel: error / weight, delta1: delta / weight, scale };
}

const results = [];
for (const id of ids) {
  const fixture = await load(id), jpg = jpeg.decode(await fs.readFile(path.join(root, `.cache/pano3d/truth/${id}/pano.jpg`)), { useTArray: true });
  const photo = { w: jpg.width, h: jpg.height, data: jpg.data };
  const tiles = fixture.tiles.map((t, i) => ({ ...t, reliability: tileReliability(perspective(photo, frozen.TILES[i], 294)) }));
  const { cached, w, h } = projections(tiles), scene = { id, reliability: tiles.map((t) => t.reliability), variants: {} };
  for (let index = 0; index < settings.length; index++) {
    const c = settings[index], anchor = c.anchor || 0, order = [anchor, ...tiles.map((_, i) => i).filter((i) => i !== anchor)];
    const aligned = modules[index].alignTiles(order.map((i) => tiles[i]));
    const transforms = tiles.map((_, i) => aligned.transforms[order.indexOf(i)]), alignment = { ...aligned, transforms };
    const depth = fuse(cached, alignment, w, h), scores = scoreDepth(fixture, depth);
    scene.variants[c.id] = { ...scores, supported: depth.supported, nearClipped: depth.nearClipped, overlapDisagreement: alignment.seamMedian, transforms };
    if (c.id === "current") {
      const exact = frozen.fuseDepth(tiles, alignment); let maximumDelta = 0;
      for (let i = 0; i < depth.d.length; i++) maximumDelta = Math.max(maximumDelta, Math.abs(depth.d[i] - exact.d[i]));
      scene.cachedFusionMaxDelta = maximumDelta;
    }
  }
  results.push(scene); console.log(id, Object.fromEntries(Object.entries(scene.variants).map(([key, value]) => [key, value.absRel])));
  await save("calibration-research-results.json", { note: "No true depth enters fitting. Frozen production math at research start, image-only confidence and raw neighbor validity. Research changes residual normalization, priors, iteration count, or a fixed gauge anchor. Fixed relative weights use initial per-pair radial inverse-depth magnitude; dynamic relative weights use current fitted magnitude with0.01 floor. Evaluation uses unchanged truth/mask, area weighting, per-method median scale calibration, and512x256 normalized/clipped fusion. Cached projection fusion is checked against the original baseline implementation by maximumDelta.", settings, scenes: results });
}
const summary = settings.map((c) => ({ id: c.id, meanAbsRel: results.reduce((v, s) => v + s.variants[c.id].absRel, 0) / results.length, worstAbsRel: Math.max(...results.map((s) => s.variants[c.id].absRel)) })).sort((a, b) => a.meanAbsRel - b.meanAbsRel);
console.log("SUMMARY", summary); await save("calibration-research-summary.json", summary);
