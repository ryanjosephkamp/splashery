// Real Chromium/application lifecycle; depth inference and permission resolution are mocked.
import assert from "node:assert/strict";
import path from "node:path";
import { chromium } from "playwright";
import { root, save } from "./common.mjs";
const base = process.env.PANO_REVIEW_URL || "http://127.0.0.1:4190";
const browser = await chromium.launch({ executablePath: process.env.SPLASHERY_CHROMIUM || "/usr/bin/chromium", args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"] });
try {
  const page = await browser.newPage(); page.setDefaultTimeout(120000);
  const errors = []; page.on("pageerror", (e) => errors.push(e.message));
  await page.addInitScript(() => {
    const NativeWorker = window.Worker; window.panoWorkers = [];
    window.Worker = function (url, options) {
      if (String(url).includes("/pano3d/worker.js")) {
        const worker = { postMessage() {}, terminate() { this.dead = true; } };
        window.panoWorkers.push(worker); return worker;
      }
      return new NativeWorker(url, options);
    };
    window.tiltListeners = new Set();
    const add = window.addEventListener.bind(window), remove = window.removeEventListener.bind(window);
    window.addEventListener = (type, fn, ...args) => { if (type === "deviceorientation" && fn.name === "orient") window.tiltListeners.add(fn); return add(type, fn, ...args); };
    window.removeEventListener = (type, fn, ...args) => { if (type === "deviceorientation" && fn.name === "orient") window.tiltListeners.delete(fn); return remove(type, fn, ...args); };
    Object.defineProperty(window, "DeviceOrientationEvent", { value: class { static requestPermission() { return new Promise((resolve) => { window.releaseTilt = () => resolve("granted"); }); } } });
  });
  await page.goto(base + "/?labs=1&renderer=webgl2&profile=low&toy=step-inside-360");
  await page.waitForSelector("body[data-ready=true]");
  await page.evaluate(() => window.__splashery.app.chooseToy("step-inside-360"));
  await page.waitForFunction(() => window.__splashery?.player?.toyInfo?.recipe?.inside);
  const staleRead = await page.evaluate(async () => {
    const { RECIPES } = await import("/src/pano3d/toy.js");
    const file = new File([await (await fetch("/assets/toys/step-inside-360/room.jpg")).blob()], "room.jpg");
    const slice = file.slice.bind(file); let release;
    const hold = new Promise((resolve) => { release = resolve; });
    file.slice = (...args) => ({ async arrayBuffer() { await hold; return slice(...args).arrayBuffer(); } });
    const pending = RECIPES["step-inside-360"].input.read("", "room.jpg", file).then((options) => ({ options }), (e) => ({ error: e.message }));
    await window.__splashery.app.setToyOptions({ source: "room2" });
    release(); return { selected: window.__splashery.player.scene.toy.options.source, result: await pending };
  });
  assert.equal(staleRead.selected, "room2"); assert.match(staleRead.result.error, /canceled/);
  await page.locator("#toy-input-file").setInputFiles(path.join(root, "assets/toys/step-inside-360/room.jpg"));
  await page.waitForFunction(() => window.__splashery.player.scene.toy.options?.source === "custom" && window.panoWorkers.length === 1);
  await page.waitForFunction(() => window.__splashery.player.toyInfo?.options?.source === "custom");
  await page.evaluate(() => window.__splashery.app.setToyOptions({ source: "room" }));
  await page.evaluate(() => window.__splashery.app.setToyOptions({ source: "custom" }));
  await page.waitForFunction(() => window.panoWorkers.length === 2);
  const restart = await page.evaluate(() => window.panoWorkers.map((w) => ({ dead: !!w.dead })));
  assert.deepEqual(restart, [{ dead: true }, { dead: false }]);
  await page.evaluate(() => document.querySelector("#pano-tilt").click());
  await page.evaluate(() => window.__splashery.app.chooseToy("blob"));
  await page.waitForTimeout(350);
  await page.evaluate(() => window.releaseTilt()); await page.waitForTimeout(150);
  const exit = await page.evaluate(() => ({ toy: window.__splashery.player.scene.toy.id, listeners: window.tiltListeners.size, workers: window.panoWorkers.map((w) => !!w.dead) }));
  assert.equal(exit.toy, "blob"); assert.equal(exit.listeners, 0); assert.deepEqual(exit.workers, [true, true]); assert.deepEqual(errors, []);
  const result = { note: "Actual Chromium application and local image decoding. Panorama inference is a hanging mock worker; DeviceOrientation permission is a deferred mock. No physical sensor or actual depth model tested.", staleRead, restart, exit, pageErrors: errors };
  console.log(JSON.stringify(result)); await save("verify-browser-async-results.json", result);
} finally { await browser.close(); }
