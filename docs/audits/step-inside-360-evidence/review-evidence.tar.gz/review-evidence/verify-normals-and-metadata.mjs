import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { root, save } from "./common.mjs";
process.chdir(root);
const { RECIPES } = await import(pathToFileURL(path.join(root, "src/pano3d/toy.js")));
const { buildRecipe, quatRotate } = await import(pathToFileURL(path.join(root, "src/kit.js")));
const { readGPano, validatePanorama } = await import(pathToFileURL(path.join(root, "src/pano3d/input.js")));
const recipe = RECIPES["step-inside-360"];
await recipe.prepare({ source: "room" });
const iterator = buildRecipe(recipe, { seed: 1, count: 9000 }); let next;
do { next = iterator.next(); } while (!next.done);
const b = next.value.buf; let minimumNormalDot = 1;
for (let i = 0; i < b.count; i++) {
  const p = b.pos.subarray(3 * i, 3 * i + 3), n = quatRotate(b.rot.subarray(4 * i, 4 * i + 4), [0, 0, 1]);
  const radius = Math.hypot(...p);
  minimumNormalDot = Math.min(minimumNormalDot, n.reduce((sum, v, j) => sum - v * p[j] / radius, 0));
}
assert.ok(minimumNormalDot > 0.999999);
const headings = [];
for (const [pose, initial, expected] of [[90, 90, 0], [90, 120, 30], [350, 10, 20], [90, undefined, 0]]) {
  const xml = `<x GPano:PoseHeadingDegrees="${pose}" ${initial === undefined ? "" : `GPano:InitialViewHeadingDegrees="${initial}"`}/>`;
  const actual = validatePanorama(4000, 2000, readGPano(xml)).heading;
  assert.equal(actual, expected); headings.push({ pose, initial, actual });
}
const rejected = [];
for (const xml of ['<x GPano:FullPanoWidthPixels="0" GPano:FullPanoHeightPixels="2000"/>', '<x GPano:CroppedAreaImageWidthPixels="0"/>', '<x GPano:ProjectionType="cylindrical"/>']) {
  assert.throws(() => readGPano(xml)); rejected.push(xml);
}
const result = { note: "Real Node recipe build and parser, no renderer or depth inference. Current production source; source hashes archived separately.", splats: b.count, minimumNormalDot, headings, rejected };
console.log(JSON.stringify(result)); await save("verify-normals-and-metadata-results.json", result);
