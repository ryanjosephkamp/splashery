// Actual toy closures/DOM/decoder in Chromium; app, inference, and near-wall depth are fixtures.
import assert from "node:assert/strict";
import { chromium } from "playwright";
import { save } from "./common.mjs";
const base = process.env.PANO_REVIEW_URL || "http://127.0.0.1:4190";
const browser = await chromium.launch({ executablePath: process.env.SPLASHERY_CHROMIUM || "/usr/bin/chromium", args: ["--no-sandbox"] });
try {
  const page = await browser.newPage();
  await page.goto(base + "/docs/codex/107-step-inside-360.md");
  const result = await page.evaluate(async () => {
    const NativeWorker = window.Worker; let worker;
    window.Worker = function (url, options) { return String(url).includes("/pano3d/worker.js") ? worker = { postMessage() {}, terminate() {} } : new NativeWorker(url, options); };
    const { RECIPES } = await import("/src/pano3d/toy.js"), recipe = RECIPES["step-inside-360"];
    const camera = { cur: { yaw: 0, pitch: 0 }, tgt: { yaw: 0, pitch: 0 } };
    window.__splashery = { player: { scene: { toy: { id: "step-inside-360" } }, camera }, app: { setToyOptions: () => recipe.prepare({ source: "custom" }) } };
    const file = new File([await (await fetch("/assets/toys/step-inside-360/room.jpg")).blob()], "room.jpg");
    await recipe.input.read("", "room.jpg", file); await recipe.prepare({ source: "custom" });
    const d = new Float32Array(32).fill(3);
    for (let y = 0; y < 4; y++) { d[y * 8 + 5] = 0.6; d[y * 8 + 6] = 0.6; }
    worker.onmessage({ data: { result: { depth: { w: 8, h: 4, d }, alignment: {} } } });
    await Promise.resolve(); document.body.append(recipe.input.live[0].render());
    document.querySelector("#pano-right").click(); let out = { parts: {} };
    for (let i = 0; i < 200; i++) recipe.drive(0, { lean: 0 }, out);
    const before = { offset: out.parts.shell.offset, warning: out.legend.items.at(-1).text };
    camera.cur.yaw = camera.tgt.yaw = Math.PI; out = { parts: {} }; recipe.drive(0, { lean: 0 }, out);
    const after = { offset: out.parts.shell.offset, warning: out.legend.items.at(-1).text };
    camera.cur.yaw = camera.tgt.yaw = 0;
    for (let i = 0; i < 10; i++) document.querySelector("#pano-right").click();
    for (let i = 0; i < 200; i++) recipe.drive(0, { lean: 0.5 }, out);
    const pulseRadius = Math.hypot(...out.parts.shell.offset);
    window.__splashery.player.scene.toy.id = "blob";
    return { before, after, pulseRadius };
  });
  assert.match(result.before.warning, /Stretch warning/); assert.equal(result.before.warning, result.after.warning);
  assert.ok(Math.abs(result.before.offset[0] - result.after.offset[0]) < 1e-8); assert.ok(result.pulseRadius <= 1.000001);
  console.log(JSON.stringify(result)); await save("verify-displacement-results.json", { note: "Actual drive function invoked deterministically200times so the result does not depend on SwiftShader frame rate. App/inference/depth are fixtures; this is behavior verification, not visual or physical-phone evidence.", ...result });
} finally { await browser.close(); }
