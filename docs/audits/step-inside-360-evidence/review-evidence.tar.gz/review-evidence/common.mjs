// Evidence-only helpers. Run from any directory; inputs remain outside the code branch.
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { TILES, direction, project, sample, median } from "./review-baseline-core.mjs";

export const directory = path.dirname(fileURLToPath(import.meta.url));
export const root = path.resolve(directory, "../../..");
export const ids = ["room", "desk", "stairs", "arches", "steps", "lattice"];
export { TILES, direction, project, sample, median };
export async function load(id) {
  const inference = JSON.parse(await fs.readFile(path.join(root, `.cache/pano3d/evidence/${id}-inference.json`), "utf8"));
  const bytes = await fs.readFile(path.join(root, `.cache/pano3d/truth/${id}/radial.f32`));
  const truth = new Float32Array(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
  const mask = await fs.readFile(path.join(root, `.cache/pano3d/truth/${id}/mask.u8`));
  const tiles = inference.tiles.map((t, i) => ({ ...TILES[i], ...t, d: Float32Array.from(t.d) }));
  return { id, truth, mask, tiles, w: 384, h: 192 };
}
export function score(fixture, depth) {
  const { truth, mask, w, h } = fixture;
  const predicted = Float32Array.from(truth, (_, i) => sample(depth.d, depth.w, depth.h, (i % w + 0.5) / w, (Math.floor(i / w) + 0.5) / h));
  const scale = median(Array.from(truth, (t, i) => mask[i] === 1 && t > 0 ? t / predicted[i] : NaN));
  let error = 0, weight = 0;
  for (let i = 0; i < truth.length; i++) if (mask[i] === 1 && truth[i] > 0) {
    const q = Math.sin(Math.PI * (Math.floor(i / w) + 0.5) / h);
    error += q * Math.abs(predicted[i] * scale - truth[i]) / truth[i]; weight += q;
  }
  return { absRel: error / weight, scale };
}
export async function save(name, data) {
  await fs.writeFile(path.join(directory, name), JSON.stringify(data, null, 2) + "\n");
}
export async function mathVariant({ positive = true, cutoff = 0, fallback = 3 } = {}) {
  let source = await fs.readFile(path.join(directory, "review-baseline-core.mjs"), "utf8");
  if (!positive) source = source.replace("Math.max(rhs / m[i][i], -(i ? next[i - 1] : 1) * minima[i / 2] + 0.001)", "rhs / m[i][i]");
  source = source.replace(".filter(Boolean);", `.filter((v) => v && v.d / v.c > ${cutoff});`);
  source = source.replace("weights ? weights / sum : 3", `weights ? weights / sum : ${fallback}`);
  return import("data:text/javascript;base64," + Buffer.from(source).toString("base64"));
}
export function supportedFuse(tiles, alignment, w = 512, h = 256) {
  const d = new Float32Array(w * h); let unsupported = 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const ray = direction((x + 0.5) / w, (y + 0.5) / h); let sum = 0, weights = 0;
    tiles.forEach((t, i) => {
      const p = project(ray, t); if (!p) return;
      const a = alignment.transforms[i], inv = (a.a * sample(t.d, t.w, t.h, p.u, p.v, 1, 0, false) + a.b) * p.cosine;
      if (inv > 1e-6) { sum += p.weight * inv; weights += p.weight; }
    });
    d[y * w + x] = weights ? weights / sum : NaN;
    if (!weights) unsupported++;
  }
  const scale = 3 / median(d);
  for (let i = 0; i < d.length; i++) d[i] = Number.isFinite(d[i]) ? Math.max(0.6, Math.min(30, d[i] * scale)) : 30;
  return { d, w, h, unsupported };
}
