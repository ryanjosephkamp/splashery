// Read-only product renderer diagnostic: offset packing and camera settling on the first capture.
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { spawn } from "node:child_process";
import { chromium } from "playwright";
import jpeg from "jpeg-js";
import { root, directory, save } from "./common.mjs";
const { packDepth } = await import(pathToFileURL(path.join(root, "src/pano3d/samples.js")));
const { maskedSSIM } = await import(pathToFileURL(path.join(root, "tools/pano-metrics.mjs")));
const base = "http://127.0.0.1:4198"; let server;
try { await fetch(base); } catch {
  server = spawn(process.execPath, ["tools/cdx-mp2-server.mjs", "4198"], { cwd: root, stdio: "ignore" });
  for (let i = 0; i < 100; i++) { try { await fetch(base); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
}
const photo = await fs.readFile(path.join(root, ".cache/pano3d/truth/arches/pano.jpg"));
const bytes = await fs.readFile(path.join(root, ".cache/pano3d/truth/arches/radial.f32"));
const truth = new Float32Array(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
const encoded = Buffer.from(packDepth({ w: 384, h: 192, d: Float32Array.from(truth, (v) => v > 0 ? Math.min(200, v) : 30) }));
const browser = await chromium.launch({ executablePath: process.env.SPLASHERY_CHROMIUM || "/usr/bin/chromium", args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
try {
  const context = await browser.newContext({ viewport: { width: 256, height: 256 }, deviceScaleFactor: 1 });
  await context.route("**/assets/toys/step-inside-360/room.jpg", (r) => r.fulfill({ contentType: "image/jpeg", body: photo }));
  await context.route("**/assets/toys/step-inside-360/room.depth", (r) => r.fulfill({ contentType: "application/octet-stream", body: encoded }));
  const page = await context.newPage(); page.setDefaultTimeout(180000);
  await page.goto(base + "/?labs=1&renderer=webgl2&profile=low&adapt=off");
  await page.waitForSelector("body[data-ready=true]");
  await page.evaluate(() => window.__splashery.app.chooseToy("step-inside-360"));
  await page.waitForFunction(() => window.__splashery.player.toyInfo?.recipe?.inside && !window.__splashery.player.loading);
  const capture = await page.evaluate(async () => {
    const p = window.__splashery.player, camera = p.camera, stage = p.stage;
    const part = p.motion.ctx.parts.findIndex((v) => v.name === "shell");
    const snapshot = () => ({ frame: stage.frames, cur: { ...camera.cur }, target: { ...camera.tgt }, home: { ...camera.home }, pose: camera.pose(), cameraTarget: [...camera.target], cameraOffset: [...camera.offset], cameraRadius: camera.radius, stageFov: stage.cameraEntity.camera.fov, stageHorizontalFov: stage.cameraEntity.camera.horizontalFov, stagePosition: Array.from(stage.cameraEntity.getPosition().toArray()), outOffset: [...(p.motion.out.parts.shell?.offset || [])], packedOffset: Array.from(p.motion.partsData.slice(part * 12 + 8, part * 12 + 11)), uniformOffset: Array.from(stage.sheetUniforms?.["uSpParts[0]"]?.slice(part * 12 + 8, part * 12 + 11) || []), size: [stage.canvas.width, stage.canvas.height] });
    const trace = []; let label = "initial";
    stage.app.on("update", () => trace.push({ event: "afterUpdate", label, state: snapshot() }));
    stage.app.on("postrender", () => trace.push({ event: "postrender", label, state: snapshot() }));
    const before = snapshot(), shots = [];
    const settle = () => { for (let i = 0; i < 160; i++) p.toyInfo.recipe.drive(0, { lean: 0 }, p.motion.out); };
    const shot = async (name) => { label = name; const before = snapshot(); const c = await stage.captureFrame(256, 256); shots.push({ name, before, after: snapshot(), rgba: Array.from(c.getContext("2d").getImageData(0, 0, 256, 256).data) }); };
    stage.setFixedSize([256, 256]); document.querySelector("#pano-home").click(); camera.cur.yaw = camera.tgt.yaw = 0; camera.cur.pitch = camera.tgt.pitch = 0;
    document.querySelector("#pano-right").click(); document.querySelector("#pano-right").click(); settle();
    await shot("tool-first"); await shot("tool-second");
    camera.cur.distance = camera.tgt.distance = camera.home.distance; camera.cur.roll = camera.tgt.roll = 0;
    p.update(0); await shot("fov72-first"); await shot("fov72-second");
    document.querySelector("#pano-home").click(); settle(); await shot("center-first"); await shot("center-second");
    for (let i = 0; i < 4; i++) document.querySelector("#pano-right").click(); camera.cur.yaw = camera.tgt.yaw = -Math.PI / 2; document.querySelector("#pano-step").click(); camera.cur.yaw = camera.tgt.yaw = 0; settle();
    await shot("offset08-first"); await shot("offset08-second");
    return { before, part, trace, shots };
  });
  const ref = jpeg.decode(await fs.readFile(path.join(root, ".cache/pano3d/truth/arches/novel-0.3.jpg")), { useTArray: true });
  const mask = await fs.readFile(path.join(root, ".cache/pano3d/evidence/arches-0.3-mask.u8"));
  const pairs = {};
  for (let i = 0; i < capture.shots.length; i += 2) {
    const a = capture.shots[i], b = capture.shots[i + 1]; let sum = 0, max = 0;
    for (let j = 0; j < a.rgba.length; j++) { const d = Math.abs(a.rgba[j] - b.rgba[j]); sum += d; max = Math.max(max, d); }
    pairs[a.name + "/" + b.name] = { meanAbsoluteByteDifference: sum / a.rgba.length, maximumByteDifference: max };
  }
  const shots = [];
  for (const shot of capture.shots) {
    await fs.writeFile(path.join(directory, "gpu-frame-" + shot.name + ".jpg"), jpeg.encode({ width: 256, height: 256, data: Buffer.from(shot.rgba) }, 95).data);
    const rgb = Float32Array.from({ length: 256 * 256 * 3 }, (_, i) => shot.rgba[Math.floor(i / 3) * 4 + i % 3] / 255);
    shots.push({ name: shot.name, before: shot.before, after: shot.after, ...(shot.name.startsWith("tool-") || shot.name.startsWith("fov72-") ? { score03: maskedSSIM(rgb, ref.data, mask) } : {}) });
  }
  const result = { note: "Actual low-profile WebGL2 product, arches exact radial depth routed through sample caches. No inference. First pair mirrors the measurement tool; the second pair snaps camera distance/home ratio to1 and updates once; final pairs test first-capture part uploads with fixed camera. Photos are cached local inputs; all writes stay in review evidence.", before: capture.before, part: capture.part, pairs, shots, trace: capture.trace };
  await save("gpu-frame-review-results.json", result);
  console.log(JSON.stringify({ before: result.before, pairs, shots: shots.map((s) => ({ name: s.name, beforeFov: s.before.pose.fov, afterFov: s.after.pose.fov, beforePacked: s.before.packedOffset, afterPacked: s.after.packedOffset, score: s.score03?.ssim })) }));
} finally { await browser.close(); server?.kill(); }
