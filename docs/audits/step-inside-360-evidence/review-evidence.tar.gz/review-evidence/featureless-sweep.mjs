// Non-oracle image-variance confidence diagnostic, not a proposed production threshold.
import fs from "node:fs/promises";
import path from "node:path";
import jpeg from "jpeg-js";
import { perspective } from "./review-baseline-core.mjs";
import { ids, root, TILES, load, score, mathVariant, supportedFuse, save } from "./common.mjs";
const rows = [];
for (const id of ids) {
  const fixture = await load(id);
  const jpg = jpeg.decode(await fs.readFile(path.join(root, `.cache/pano3d/truth/${id}/pano.jpg`)), { useTArray: true });
  const photo = { w: jpg.width, h: jpg.height, data: jpg.data };
  const variance = TILES.map((tile) => {
    const p = perspective(photo, tile, 98), sum = [0, 0, 0], squares = [0, 0, 0], n = p.w * p.h;
    for (let i = 0; i < n; i++) for (let c = 0; c < 3; c++) { const v = p.data[4 * i + c] / 255; sum[c] += v; squares[c] += v * v; }
    return sum.reduce((total, v, c) => total + squares[c] / n - (v / n) ** 2, 0) / 3;
  });
  const results = {};
  for (const threshold of [1e-6, 1e-4, 1e-3]) for (const positive of [false, true]) {
    const excluded = variance.map((v, i) => v < threshold ? i : null).filter((v) => v !== null);
    // Zero forward vectors deliberately disable projection in both fit and fusion.
    const tiles = fixture.tiles.map((t, i) => excluded.includes(i) ? { ...t, forward: [0, 0, 0] } : t);
    const m = await mathVariant({ positive, cutoff: 0.1 }), alignment = m.alignTiles(tiles);
    const depth = supportedFuse(tiles, alignment);
    results[(positive ? "positive" : "free") + "-" + threshold] = { absRel: score(fixture, depth).absRel, unsupported: depth.unsupported, excluded };
  }
  rows.push({ id, variance, results }); console.log(id, JSON.stringify(results));
}
await save("featureless-sweep-results.json", { note: "Image-only confidence: mean RGB channel variance over a 98x98 perspective input. Fixed variance thresholds; raw/median overlap cutoff0.1. Excludes featureless faces from fit/fusion, normalizes only positive-supported rays, and assigns unsupported rays radius30 AFTER normalization. positive retains the reviewed all-pixel positivity floor; free permits negative shifts. No true geometry enters fitting or confidence.", scenes: rows });
