# Panorama implementation review evidence

Independent read-only implementation review, Codex (GPT-6), October 17, 2026.
Only this ignored evidence directory was written. No production source or tests were edited by
the reviewer. These files belong on the unmerged evidence branch.

Run from the repository root:

```sh
node .cache/pano3d/review-evidence/oracle-affine.mjs
node .cache/pano3d/review-evidence/cutoff-sweep.mjs
node .cache/pano3d/review-evidence/featureless-sweep.mjs
node .cache/pano3d/review-evidence/verify-normals-and-metadata.mjs
PANO_REVIEW_URL=http://127.0.0.1:4190 node .cache/pano3d/review-evidence/verify-browser-async.mjs
PANO_REVIEW_URL=http://127.0.0.1:4190 node .cache/pano3d/review-evidence/verify-displacement.mjs
node .cache/pano3d/review-evidence/reliability-counterexample.mjs
node .cache/pano3d/review-evidence/calibration-research.mjs
node .cache/pano3d/review-evidence/floor-prior-research.mjs
node .cache/pano3d/review-evidence/gpu-frame-review.mjs
```

The browser scripts need the existing local static server, Playwright, and Chromium. Set
`SPLASHERY_CHROMIUM` when Chromium is not at `/usr/bin/chromium`. No external requests, uploads,
sensor recordings, or physical-phone measurements are made. Scripts create JSON results and
ordinary shell redirection produced the archived `.run.log` files.

## Inputs and frozen math

Depth diagnostics read the six raw `tiles` arrays from
`.cache/pano3d/evidence/*-inference.json`, and the panoramas, true radial depth, and masks from
`.cache/pano3d/truth/`. Preserve those files with this directory. Their cached fused output is
not used. `inputs-and-source-hashes.json` records input and source hashes at archival time.

`review-baseline-core.mjs` is an evidence-only reconstruction of the math reviewed before the
sky fixes. It restores the original all-pixel positivity floor, unfiltered overlaps, and finite
radius-3 unsupported fallback. Geometric helpers are frozen beside it so production changes do
not silently alter these experiments. The newer `readGeometry` and `tileReliability` definitions
remain in that snapshot but are unused by its restored baseline fit and fusion.

The diagnostic scripts modify that snapshot only in memory. They are not proposed production
implementations. Current production has additional neighbor validity checks, image confidence,
negative affine offsets, and supported-only normalization; the old sweep scores do not measure
that final implementation.

## Interpretation

`oracle-affine-results.json` uses true depth in calibration and scoring. Its inverse-Z results
show that the perspective-to-radial cosine conversion is numerically appropriate, and that
individual model tiles contain useful geometry. It cannot establish a production depth gate.

`cutoff-sweep-results.json` uses no true depth during fitting. It tests fixed overlap
raw/median cutoffs from 0.05 to 0.5 with negative offsets. It deliberately retains the problematic
radius-30 fallback before normalization, and reports a separate unclipped result. No threshold
consistently improves the naive baseline.

`featureless-sweep-results.json` detects featurelessness from input RGB variance, excludes those
tiles from fit and fusion, excludes unsupported rays from the scale median, and assigns their
radius after normalization. It compares free offsets and the old positivity floor. The fixed
variance thresholds do not recover the task's 20% depth gate across the scenes.

The three `verify-*` result files distinguish real code paths from mocked inference or app state.
The browser lifecycle check runs the actual application and decoder, but uses hanging panorama
workers and deferred sensor permission. The displacement check invokes the actual recipe drive
function deterministically against a synthetic near-wall depth field; it does not render or run
the model. The normal check builds the actual recipe in Node.

## Review findings and fixes

- Explicit anisotropic scales ignored supplied normals in Kit emission, leaving all 8,586
  panorama discs at identity rotation. Production now supplies explicit quaternions. Minimum
  inward-normal dot product measured after the fix: 0.999999853.
- Canceling custom inference left its started flag set. Returning to custom now starts another
  worker; the prior one is terminated.
- A delayed file decode could override a newer source selection. The real-browser reproduction
  now rejects it as canceled and keeps the newer room selection.
- A delayed tilt permission response could install its listener after exit. The real-browser
  reproduction now leaves zero panorama orientation listeners.
- GPano initial headings must be relative to the panorama pose. Equal pose and initial heading
  now produce zero pixel yaw; dimensions of zero and cylindrical projections are rejected.
- Stretch warning depth previously followed viewing yaw. It now follows actual displacement,
  remains stable when the view turns, and includes pulse motion within the one-meter bound.
- All-pixel positivity floors treated sky model zeros as constraints on real geometry's affine
  offset. Positive hallucinated depth on featureless sky also distorted calibration. Unsupported
  far-background rays could dominate normalization. The production author addressed these
  correctness issues, but the measured real-model depth gate still fails.
- The first tile-confidence implementation used variance of mean RGB. The saved counterexample
  shows why equal-channel-sum colored textures must not be classified as constant color.

SwiftShader performance during concurrent suite runs was too slow for reliable wall-clock
movement settling: one second advanced the smoothing by only about two frames. The deterministic
drive check avoids that timing ambiguity. It does not make a phone latency or memory claim.

The later [calibration research findings](calibration-research-findings.md) summarize additional
no-truth residual, prior, anchor, convergence, and upright-floor experiments. Their frozen
production snapshot, scripts, results, summaries, and logs are also preserved here. Neither
research family establishes a generally useful production change or the depth gate.

The [GPU measurement review](gpu-frame-review-findings.md) reproduces the low first-capture
truth-control score and identifies an unsettled camera FOV. Actual offsets reach packed part
data and GPU uniforms on the first capture. Snapping the full camera gives stable consecutive
captures and raises the arches0.3m truth-control SSIM from approximately0.165 to0.441.
