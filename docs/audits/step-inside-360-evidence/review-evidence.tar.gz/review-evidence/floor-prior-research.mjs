// HEURISTIC, no truth during fitting: assumes the central downward cone sees an upright floor.
// A relative inverse-radial plane prior flattens the downward face toward a plane with free height.
import fs from "node:fs/promises";
import path from "node:path";
import jpeg from "jpeg-js";
import { ids, root, directory, load, score, save } from "./common.mjs";
import * as frozen from "./calibration-start-core.mjs";
const source = await fs.readFile(path.join(directory, "calibration-start-core.mjs"), "utf8");
const settings = [
  ...[0.01, 0.1, 1, 10].map((weight) => ({ id: `floor-${weight}`, weight })),
  { id: "floor-1-scale-prior-1", weight: 1, scalePrior: 1 },
  { id: "floor-1-scale-prior-10", weight: 1, scalePrior: 10 },
];
async function make(c) {
  // The existing eleven parameters gain an unknown inverse floor height at index11.
  // It is a positive scale parameter. The original front-scale gauge remains fixed.
  let s = source.replace(/\b11\b/g, "12");
  const marker = "let fit = Array.from({ length: 12 }, (_, i) => (i % 2 ? 1 : 0));";
  if (!s.includes(marker)) throw new Error("Research snapshot format mismatch");
  s = s.replace(marker, `
  const floor=[];
  if(tiles[5].reliability!==0) for(let y=0;y<16;y++)for(let x=0;x<16;x++) {
    const u=(x+.5)/16,v=(y+.5)/16;
    const {ray,cosine}=tileRay(u,v,tiles[5]);
    if(-ray[1]<Math.cos(Math.PI/6))continue;
    const raw=sample(tiles[5].d,tiles[5].w,tiles[5].h,u,v,1,0,false)/med[5];
    if(raw<=.1)continue;
    const r=new Float64Array(12);r[9]=raw*cosine;r[10]=cosine;r[11]=ray[1];
    floor.push({r,target:0});
  }
  const total=rows.reduce((s,r)=>s+r.weight,0);
  for(const row of floor)rows.push({...row,weight:${c.weight}*total/Math.max(1,floor.length)});
  ${marker}`);
  if (c.scalePrior) {
    s = s.replace("m[i][i] += 0.0001;", `m[i][i] += i%2&&i<11?${c.scalePrior}:0.0001;`);
    s = s.replace("b[i] += 0.0001 * (i % 2 ? 1 : 0);", `b[i] += (i<11?${c.scalePrior}:0.0001)*(i%2?1:0);`);
  }
  return import("data:text/javascript;base64," + Buffer.from(s).toString("base64"));
}
const modules = await Promise.all(settings.map(make)), scenes = [];
for (const id of ids) {
  const f = await load(id), jpg = jpeg.decode(await fs.readFile(path.join(root, `.cache/pano3d/truth/${id}/pano.jpg`)), { useTArray: true });
  const photo = { w: jpg.width, h: jpg.height, data: jpg.data };
  const tiles = f.tiles.map((t, i) => ({ ...t, reliability: frozen.tileReliability(frozen.perspective(photo, frozen.TILES[i], 294)) }));
  const variants = {};
  for (let i = 0; i < modules.length; i++) {
    const m = modules[i], a = m.alignTiles(tiles), depth = m.fuseDepth(tiles, a);
    variants[settings[i].id] = { ...score(f, depth), overlapDisagreement: a.seamMedian, transforms: a.transforms };
  }
  scenes.push({ id, variants }); console.log(id, Object.fromEntries(Object.entries(variants).map(([id, r]) => [id, r.absRel])));
  await save("floor-prior-research-results.json", { note: "HEURISTIC: central30degree cone of the downward face is assumed to be an upright flat floor. No true depth enters fit or prior selection. A free positive inverse floor height preserves the existing global gauge, and fixed prior weights span0.01–10 times the total overlap-row weight. This can be wrong for seated captures, nonlevel panoramas, stairs, nearby objects, or views with no floor. Truth is evaluation only.", settings, scenes });
}
const summary = settings.map((c) => ({ id: c.id, meanAbsRel: scenes.reduce((v, s) => v + s.variants[c.id].absRel, 0) / scenes.length }));
console.log("SUMMARY", summary); await save("floor-prior-research-summary.json", summary);
