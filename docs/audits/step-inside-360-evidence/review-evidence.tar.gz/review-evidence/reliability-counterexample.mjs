// A color-texture counterexample for the first production confidence implementation.
import path from "node:path";
import { pathToFileURL } from "node:url";
import { root, save } from "./common.mjs";
const { tileReliability } = await import(pathToFileURL(path.join(root, "src/pano3d/core.js")));
const w = 294, h = 294, data = new Uint8Array(w * h * 4);
for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
  const i = 4 * (y * w + x); data[i + (x + y) % 2] = 255; data[i + 3] = 255;
}
const result = { note: "Initial implementation used variance of (R+G+B)/3, so red and green cancel despite visible edges. Expected reliability1. A later fixed implementation should return1; this file records the state at execution.", pattern: "Alternating red/green checkerboard", reliability: tileReliability({ w, h, data }) };
console.log(JSON.stringify(result)); await save("reliability-counterexample-results.json", result);
