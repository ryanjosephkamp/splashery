// Same actual Chromium pixels/cached real model tensors after the one-way production port.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {chromium} from "playwright";
import {root,directory,save} from "./common.mjs";
const sha=x=>crypto.createHash("sha256").update(x).digest("hex"),sources={};
for(const file of ["src/pano3d/core.js","src/pano3d/prior.js","src/pano3d/pipeline.js",".cache/pano3d/review-evidence/confidence-one-way-core.mjs",".cache/pano3d/review-evidence/confidence-review-core-unit-fix.mjs"])
 sources[file]=sha(await fs.readFile(path.join(root,file)));
const groups=[
 {name:"development",ids:["room","desk","stairs","arches","steps","lattice"],truth:"truth",cube:"pre-one-way/evidence"},
 {name:"diagnostic-families",ids:["still-life","forest","coast","fur","night","leaves"],truth:"truth-validation",cube:"pre-one-way/final-validation"},
 {name:"diagnostic-interiors",ids:["interior-01","interior-02","interior-03","interior-04","interior-05","interior-06"],truth:"truth-interior",cube:"pre-one-way/final-interior"},
 {name:"fresh-room-assessment",ids:["fresh-room-01","fresh-room-02","fresh-room-03","fresh-room-04","fresh-room-05","fresh-room-06"],truth:"truth-fresh-room",cube:"pre-one-way/final-fresh-room",fresh:true},
];
const browser=await chromium.launch({executablePath:process.env.SPLASHERY_CHROMIUM||"/usr/bin/chromium",args:["--no-sandbox"]}),rows=[];
try{
 const page=await browser.newPage();page.setDefaultTimeout(600000);await page.goto(process.env.PANO_REVIEW_URL||"http://127.0.0.1:4173/docs/codex/107-step-inside-360.md");
 for(const group of groups)for(const id of group.ids){
  const row=await page.evaluate(async({id,group})=>{
   const {decodePhoto}=await import("/src/packs/photo-3d.js"),productionCore=await import("/src/pano3d/core.js"),oneWay=await import("/.cache/pano3d/review-evidence/confidence-one-way-core.mjs"),unitFix=await import("/.cache/pano3d/review-evidence/confidence-review-core-unit-fix.mjs"),{panoramaPrior}=await import("/src/pano3d/prior.js"),{reconstruct}=await import("/src/pano3d/pipeline.js");
   const prefix="/.cache/pano3d/",cached=await(await fetch(prefix+group.cube+"/"+id+"-inference.json")).json();
   const tensors=cached.tiles;
   if(tensors.length!==10)throw new Error("Expected10 real outputs");
   const photo=await decodePhoto(await(await fetch(prefix+group.truth+"/"+id+"/pano.jpg")).blob());
   const perFace=[],tiles=tensors.slice(0,6).map((t,i)=>{
    const pixels=productionCore.perspective(photo,productionCore.TILES[i],294),confidence=productionCore.tileConfidence(pixels),reliability=productionCore.tileReliability(pixels);
    const rgbSupported=Array.from(confidence).reduce((s,v)=>s+v,0),positiveSupported=t.d.reduce((s,v,j)=>s+(v>1e-6&&confidence[j]?1:0),0),positiveModel=t.d.filter(v=>v>1e-6).length,supported=reliability!==0&&positiveSupported>0;
    perFace.push({i,reliability,rgbSupported,positiveSupported,positiveModel,pixels:t.d.length,supported,oneWayEligible:!supported&&reliability!==0&&positiveModel>0});
    return {...productionCore.TILES[i],...t,confidence,reliability};
   }),observations=tensors.slice(6).map((t,j)=>({...t,offset:j/4}));
   const alignments={},depths={};for(const[name,core]of[["production",productionCore],["oneWaySnapshot",oneWay],["unitFixSnapshot",unitFix]]){alignments[name]=core.alignTiles(tiles);depths[name]=panoramaPrior(photo,observations,core.fuseDepth(tiles,alignments[name])).depth;}
   let calls=0;const pipeline=await reconstruct(photo,async(input,options)=>{if(options.side!==294)throw new Error("Unexpected resolution");return tensors[calls++];});if(calls!==10)throw new Error("Unexpected callcount");
   const delta=(a,b)=>{let m=0;if(a.length!==b.length)throw new Error("Mismatched fields");for(let i=0;i<a.length;i++)m=Math.max(m,Math.abs(a[i]-b[i]));return m;};
   let supportedTransformsDelta=0;for(const face of perFace)if(face.supported){const a=alignments.oneWaySnapshot.transforms[face.i],b=alignments.unitFixSnapshot.transforms[face.i];supportedTransformsDelta=Math.max(supportedTransformsDelta,Math.abs(a.a-b.a),Math.abs(a.b-b.b));}
   return {id,group:group.name,perFace,productionOneWayMaxDelta:delta(depths.production.d,depths.oneWaySnapshot.d),pipelineManualMaxDelta:delta(depths.production.d,pipeline.depth.d),oneWayVsUnitFixMaxDelta:delta(depths.oneWaySnapshot.d,depths.unitFixSnapshot.d),supportedTransformsDelta,unitFixCacheMaxDelta:delta(depths.unitFixSnapshot.d,cached.result.depth.d),freshPrototypeMaxDelta:group.fresh?delta(depths.production.d,(await(await fetch(prefix+"confidence-fresh-room/"+id+"-inference.json")).json()).result.depth.d):null};
  },{id,group});
  rows.push(row);console.log(JSON.stringify(row));
  await save("confidence-final-fidelity-review-results.json",{sources,note:"After production one-way port. Actual Chromium RGB and real cached neural tensors; no GT geometry/masks/scores opened. Compares actual pipeline, production core, one-way evidence snapshot, and earlier unit-only sourcepoint, and records every face's RGB/raw-positive support. Every change to a supported transform or prototype depth is explicitly visible.",rows});
  if(row.productionOneWayMaxDelta||row.pipelineManualMaxDelta||row.supportedTransformsDelta||row.unitFixCacheMaxDelta)throw new Error("Fidelity failure "+id);
 }
}finally{await browser.close();}
for(const [file,hash]of Object.entries(sources)){
 const bytes=await fs.readFile(path.join(root,file));if(sha(bytes)!==hash)throw new Error("Source changed during review: "+file);
 const snapshot=path.join(directory,"confidence-final-fidelity-sources",file);await fs.mkdir(path.dirname(snapshot),{recursive:true});await fs.writeFile(snapshot,bytes);
}
