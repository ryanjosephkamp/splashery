// Evidence-only two-stage fallback. Raw unsupported tiles cannot influence supported transforms.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {directory,save} from "./common.mjs";
import * as unit from "./confidence-review-core-unit-fix.mjs";
import * as oneWay from "./confidence-one-way-core.mjs";
const sha=x=>crypto.createHash("sha256").update(x).digest("hex"),W=80,H=40,w=48,h=48;
const smooth=r=>3+.8*r[0]+.5*r[2];
const box=r=>1/Math.max(Math.abs(r[0])/10,Math.abs(r[1])/10,(r[2]>=0?r[2]/3:-r[2]/10));
const results=[];
for(const scenario of ["exact","affine-front","constant-front-plane","zero-front","all-supported"]){
 const truth=scenario==="constant-front-plane"?box:smooth;
 for(const frontReliability of scenario==="all-supported"?[1]:[0,1]){
  const tiles=unit.TILES.map((tile,face)=>({...tile,w,h,reliability:face?1:frontReliability,confidence:new Uint8Array(w*h).fill(face||scenario==="all-supported"?1:0),d:Float32Array.from({length:w*h},(_,i)=>{const{ray,cosine}=unit.tileRay((i%w+.5)/w,(Math.floor(i/w)+.5)/h,tile);const q=1/(truth(ray)*cosine);return face?q:scenario==="affine-front"?q*3+.7:scenario==="constant-front-plane"?2:scenario==="zero-front"?0:q;})}));
  const baseline=unit.alignTiles(tiles),alignment=oneWay.alignTiles(tiles),field=oneWay.fuseDepth(tiles,alignment,W,H);
  const rays=Array.from(field.d,(_,i)=>unit.direction((i%W+.5)/W,(Math.floor(i/W)+.5)/H)),supported=rays.map(ray=>unit.TILES.slice(1).some(tile=>unit.project(ray,tile))),scale=unit.median(Array.from(field.d,(value,i)=>supported[i]?truth(rays[i])/value:NaN));
  const errors=Array.from(field.d,(value,i)=>supported[i]?Math.abs(value*scale-truth(rays[i]))/truth(rays[i]):NaN).filter(Number.isFinite);
  const supportedTransformsUnchanged=JSON.stringify(alignment.transforms.slice(1))===JSON.stringify(baseline.transforms.slice(1));
  if(!supportedTransformsUnchanged)throw new Error("Unsupported data moved supported transforms");
  const row={scenario,frontReliability,supportedTransformsUnchanged,supportedRegionMeanError:errors.reduce((s,v)=>s+v,0)/errors.length,farPixels:Array.from(field.d).filter(v=>v===30).length,totalPixels:field.d.length,allFinitePositive:field.d.every(v=>Number.isFinite(v)&&v>0),transforms:alignment.transforms};
  if(scenario==="all-supported")row.allTransformsUnchanged=JSON.stringify(alignment.transforms)===JSON.stringify(baseline.transforms);
  results.push(row);console.log(JSON.stringify(row));
 }
}
// A supported patch that never overlaps the front cannot identify its transform.
// Check the explicit normalized-unit prior without adding any new fitting rule.
{
 const tiles=unit.TILES.map((tile,face)=>({...tile,w,h,reliability:face===0||face===1?1:0,confidence:Uint8Array.from({length:w*h},(_,i)=>face===1&&i%w>w*.35&&i%w<w*.65&&Math.floor(i/w)>h*.35&&Math.floor(i/w)<h*.65?1:0),d:Float32Array.from({length:w*h},(_,i)=>{const{ray,cosine}=unit.tileRay((i%w+.5)/w,(Math.floor(i/w)+.5)/h,tile);return 1/(smooth(ray)*cosine);})}));
 const base=unit.alignTiles(tiles),alignment=oneWay.alignTiles(tiles),supportedMedian=unit.median(tiles[1].d.filter((v,i)=>v>1e-6&&tiles[1].confidence[i])),privateMedian=unit.median(tiles[0].d.filter(v=>v>1e-6)),expectedA=supportedMedian/privateMedian;
 const supportedTransformsUnchanged=JSON.stringify(base.transforms[1])===JSON.stringify(alignment.transforms[1]);
 if(!supportedTransformsUnchanged||alignment.transforms[0].a!==expectedA||alignment.transforms[0].b!==0)throw new Error("No-overlap prior or supported invariance failure");
 results.push({scenario:"no-supported-overlap",supportedTransformsUnchanged,expectedA,actual:alignment.transforms[0]});
}
await save("confidence-one-way-review-results.json",{sourceSha256:sha(await fs.readFile(path.join(directory,"confidence-one-way-core.mjs"))),unitFixSourceSha256:sha(await fs.readFile(path.join(directory,"confidence-review-core-unit-fix.mjs"))),note:"Minimal one-way affine registration of wholly unsupported reliability1 tile to supported corrected overlaps, using the existing five IRLS passes, .04 normalized Huber residual, .0001 positive-scale/shift priors, .05..20 scale bounds, and300 coordinate sweeps. Unsupported raw median normalizes only its own regression; it cannot set shared global unit or supported transforms. No truth used during fitting. Exact fixture matches the parent regression at48×48 and80×40 output. Constant raw front is tested on a physically planar front wall in a closed box; ridge priors retain identifiability of the corrected a*q+b combination despite collinear raw/constant columns. Production/tests unchanged by reviewer.",results});
