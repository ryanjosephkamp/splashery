export function pixelConfidence(photo) {
 const {w,h,data}=photo;
 return Uint8Array.from({length:w*h},(_,i)=>{
  const x=i%w,y=Math.floor(i/w),s=[0,0,0],ss=[0,0,0];
  for(const dy of [-2,0,2])for(const dx of [-2,0,2])for(let c=0;c<3;c++){
   const xx=Math.max(0,Math.min(w-1,x+dx)),yy=Math.max(0,Math.min(h-1,y+dy));const v=data[(yy*w+xx)*4+c]/255;s[c]+=v;ss[c]+=v*v;
  }
  return s.reduce((v,s,c)=>v+ss[c]/9-(s/9)**2,0)/3>1e-6?1:0;
 });
}
