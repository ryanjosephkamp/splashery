// Read-only regression reproduction and evidence-only global-unit fix experiment.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {root,directory,save} from "./common.mjs";
import * as current from "../../../src/pano3d/core.js";
import * as before from "./confidence-review-core-before-anchor-fix.mjs";
const bytes=await fs.readFile(path.join(directory,"confidence-review-core-before-anchor-fix.mjs"));
let source=bytes.toString();
const needle="  const rows = [];";
if(!source.includes(needle))throw new Error("Unexpected core snapshot");
// Only the arbitrary global inverse-depth unit changes when front is unsupported.
// The fixed a0=1 solver gauge and its weak priors remain byte-for-byte unchanged.
source=source.replace(needle,"  const supportedUnit=tiles.findIndex((t,i)=>t.reliability!==0 && t.d.some((v,j)=>v>1e-6&&(!t.confidence||t.confidence[j]))); if(supportedUnit>=0 && (!tiles[0].d.some((v,j)=>v>1e-6&&(!tiles[0].confidence||tiles[0].confidence[j])) || tiles[0].reliability===0)) med[0]=med[supportedUnit];\n"+needle);
const patched=await import("data:text/javascript;base64,"+Buffer.from(source).toString("base64"));
const w=64,h=64,W=160,H=80,radial=r=>3+.8*r[0]+.5*r[2];
const tiles=before.TILES.map(tile=>({...tile,w,h,reliability:1,confidence:new Uint8Array(w*h).fill(1),d:Float32Array.from({length:w*h},(_,i)=>{const {ray,cosine}=before.tileRay((i%w+.5)/w,(Math.floor(i/w)+.5)/h,tile);return 1/(radial(ray)*cosine);})}));
const results=[];
for(const [name,module] of [["before",before],["unit-only-experiment",patched],["current-production",current]])for(const emptyFront of [false,true])for(const frontReliability of emptyFront?[0,1]:[1]){
 const inputs=tiles.map((tile,i)=>emptyFront&&!i?{...tile,reliability:frontReliability,confidence:new Uint8Array(w*h)}:tile),alignment=module.alignTiles(inputs),field=module.fuseDepth(inputs,alignment,W,H);
 const mask=Uint8Array.from(field.d,(_,i)=>{const ray=before.direction((i%W+.5)/W,(Math.floor(i/W)+.5)/H);return before.TILES.slice(1).some(t=>before.project(ray,t))?1:0;});
 const scale=before.median(Array.from(field.d,(value,i)=>mask[i]?radial(before.direction((i%W+.5)/W,(Math.floor(i/W)+.5)/H))/value:NaN));
 let error=0,weights=0;for(let i=0;i<field.d.length;i++)if(mask[i]){const weight=Math.sin(Math.PI*(Math.floor(i/W)+.5)/H),truth=radial(before.direction((i%W+.5)/W,(Math.floor(i/W)+.5)/H));error+=weight*Math.abs(field.d[i]*scale-truth)/truth;weights+=weight;}
 results.push({name,emptyFront,frontReliability,min:Math.min(...field.d),max:Math.max(...field.d),farPixels:Array.from(field.d).filter(v=>v===30).length,totalPixels:field.d.length,supportedRegionAbsRel:error/weights,alignment});
}
await save("confidence-anchor-review-results.json",{beforeSourceSha256:crypto.createHash("sha256").update(bytes).digest("hex"),currentSourceSha256:crypto.createHash("sha256").update(await fs.readFile(path.join(root,"src/pano3d/core.js"))).digest("hex"),note:"Exact analytic six-view inverse-Z fixture. Only front calibration confidence is removed, leaving five fully supported views. Before-fix med0=1e-6 causes every ray to fail the absolute inverse-depth support test and yields an all30m field. The unit-only experiment retains the original solver anchoring and weak priors; only med0's arbitrary global unit falls back to a supported tile. Evaluation excludes the region not covered by any of the five other views, so a legitimately unreliable front tile is not expected to provide geometry. No actual-scene candidate tuning or production/test edit.",results});
console.log(JSON.stringify(results.map(({alignment,...result})=>result)));
