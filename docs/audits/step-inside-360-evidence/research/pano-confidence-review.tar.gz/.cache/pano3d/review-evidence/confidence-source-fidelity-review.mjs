// Independent, read-only frozen candidate/production fidelity check. No ONNX inference rerun.
// Same cached real tensors are reconstructed with browser pixels and separately with jpeg-js.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import jpeg from "jpeg-js";
import {chromium} from "playwright";
import {root,save} from "./common.mjs";
import {reconstruct as reconstructNode} from "../../../src/pano3d/pipeline.js";
import {pixelConfidence} from "../confidence-pixels.js";
import {tileConfidence} from "../../../src/pano3d/core.js";
const sha=x=>crypto.createHash("sha256").update(x).digest("hex"),sources={};
for(const file of ["src/pano3d/core.js","src/pano3d/prior.js","src/pano3d/pipeline.js",".cache/pano3d/core-confidence-calibration.js",".cache/pano3d/prior-confidence-blend.js",".cache/pano3d/pipeline-confidence-candidate.js",".cache/pano3d/confidence-pixels.js"])
 sources[file]=sha(await fs.readFile(path.join(root,file)));
const groups=[
 {name:"development",ids:["room","desk","stairs","arches","steps","lattice"],truth:"truth",cube:"rejected-cube-evidence",rotations:"rotations"},
 {name:"diagnostic-families",ids:["still-life","forest","coast","fur","night","leaves"],truth:"truth-validation",cube:"validation/evidence",rotations:"validation/rotations"},
 {name:"diagnostic-interiors",ids:["interior-01","interior-02","interior-03","interior-04","interior-05","interior-06"],truth:"truth-interior",cube:"interior/evidence",rotations:"interior/rotations"},
 {name:"fresh-room-assessment",ids:["fresh-room-01","fresh-room-02","fresh-room-03","fresh-room-04","fresh-room-05","fresh-room-06"],truth:"truth-fresh-room",cube:"confidence-fresh-room"},
];
// Independent helper-equivalence cases, including equal-channel-sum texture and edges.
const helperCases=[];
for(const mode of ["flat","checker-rgb","random","gentle-gradient"]){
 const w=37,h=19,data=Uint8ClampedArray.from({length:w*h*4},(_,i)=>{if(i%4===3)return 255;const p=Math.floor(i/4),x=p%w,y=Math.floor(p/w),c=i%4;return mode==="flat"?90:mode==="checker-rgb"?((Math.floor(x/2)+Math.floor(y/2))%2?([180,20,20][c]):([20,20,180][c])):mode==="random"?(p*71+c*103+y*13)%256:90+Math.floor(x/8);});
 const a=tileConfidence({w,h,data}),b=pixelConfidence({w,h,data});
 helperCases.push({mode,different:Array.from(a,(v,i)=>v!==b[i]?1:0).reduce((s,v)=>s+v,0),supported:Array.from(a).reduce((s,v)=>s+v,0)});
}
const browser=await chromium.launch({executablePath:process.env.SPLASHERY_CHROMIUM||"/usr/bin/chromium",args:["--no-sandbox"]}),rows=[];
try{
 const page=await browser.newPage();page.setDefaultTimeout(600000);await page.goto(process.env.PANO_REVIEW_URL||"http://127.0.0.1:4173/docs/codex/107-step-inside-360.md");
 for(const group of groups)for(const id of group.ids){
  const prefix=path.join(root,".cache/pano3d"),cube=JSON.parse(await fs.readFile(path.join(prefix,group.cube,id+"-inference.json"),"utf8"));
  let tensors=cube.tiles.slice(0,6),freshReference;
  if(group.rotations){const rotations=JSON.parse(await fs.readFile(path.join(prefix,group.rotations,id+".json"),"utf8"));tensors=tensors.concat(rotations.outputs);}else{tensors=cube.tiles;freshReference=cube.result.depth;}
  if(tensors.length!==10)throw new Error("Expected exact six cube/four panorama outputs: "+id);
  const browserRow=await page.evaluate(async({id,group,tensors,freshReference})=>{
   const {decodePhoto}=await import("/src/packs/photo-3d.js"),{reconstruct:production}=await import("/src/pano3d/pipeline.js"),{reconstruct:candidate}=await import("/.cache/pano3d/pipeline-confidence-candidate.js");
   const photo=await decodePhoto(await(await fetch("/.cache/pano3d/"+group.truth+"/"+id+"/pano.jpg")).blob());
   const run=async(fn)=>{let calls=0;const result=await fn(photo,async(input,options)=>{if(options.side!==294)throw new Error("Unexpected resolution");if(input.data.length!==input.w*input.h*4)throw new Error("Incomplete input");return tensors[calls++];});if(calls!==10)throw new Error("Unexpected model call count");return result;};
   const p=await run(production),c=await run(candidate);
   const maxDifference=(a,b)=>{if(a.length!==b.length)throw new Error("Mismatched fields");let m=0;for(let i=0;i<a.length;i++)m=Math.max(m,Math.abs(a[i]-b[i]));return m;};
   const confidenceFractions=[];const {TILES,perspective,tileConfidence}=await import("/src/pano3d/core.js");
   for(const tile of TILES){const mask=tileConfidence(perspective(photo,tile,294));confidenceFractions.push(Array.from(mask).reduce((s,v)=>s+v,0)/mask.length);}
   return {productionCandidateMaxDelta:maxDifference(p.depth.d,c.depth.d),freshReferenceMaxDelta:freshReference?maxDifference(p.depth.d,freshReference.d):null,browserPixels:Array.from(photo.data),photo:{w:photo.w,h:photo.h},depth:{...p.depth,d:Array.from(p.depth.d)},confidenceFractions};
  },{id,group,tensors,freshReference});
  // No geometry/masks are read by this fidelity script.
  const jpg=jpeg.decode(await fs.readFile(path.join(prefix,group.truth,id,"pano.jpg")),{useTArray:true}),nodePhoto={w:jpg.width,h:jpg.height,data:jpg.data};
  let calls=0;const node=await reconstructNode(nodePhoto,async()=>tensors[calls++]);
  let rgbaDifferences=0,maxRGBDelta=0,maxDepthDelta=0,meanDepthDelta=0;
  for(let i=0;i<jpg.data.length;i++){const d=Math.abs(jpg.data[i]-browserRow.browserPixels[i]);if(d)rgbaDifferences++;maxRGBDelta=Math.max(maxRGBDelta,d);}
  for(let i=0;i<node.depth.d.length;i++){const d=Math.abs(node.depth.d[i]-browserRow.depth.d[i]);maxDepthDelta=Math.max(maxDepthDelta,d);meanDepthDelta+=d/node.depth.d.length;}
  const {browserPixels,depth,...rest}=browserRow;
  const row={id,group:group.name,...rest,jpegJsVsBrowser:{rgbaDifferences,totalComponents:jpg.data.length,maxRGBDelta,maxDepthDelta,meanDepthDelta}};
  if(row.productionCandidateMaxDelta!==0||row.freshReferenceMaxDelta>1e-7)throw new Error("Production/frozen candidate fidelity failure: "+JSON.stringify(row));
  rows.push(row);console.log(JSON.stringify(row));
  await save("confidence-source-fidelity-review-results.json",{sources,helperCases,note:"Same real model tensors, no GT/masks opened. Browser production and frozen candidate reconstruct the same Chromium-decoded pixels. jpeg-js reconstruction is measured separately; it is not claimed byte-equivalent to browser. Fresh reference is the actual browser-prototype cached field. Source hashes identify the exact review point.",rows});
 }
}finally{await browser.close();}
for(const [file,hash]of Object.entries(sources))if(sha(await fs.readFile(path.join(root,file)))!==hash)throw new Error("Source changed during review: "+file);
