// Independent recomputation of the frozen unit-fix actual-model scores.
// No fitting, threshold changes, omission, or candidate selection occurs here.
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {root,save} from "./common.mjs";
import {sample,median,direction,TILES,project} from "../../../src/pano3d/core.js";
const sha=x=>crypto.createHash("sha256").update(x).digest("hex"),groups=[
 {name:"development",truth:"truth",evidence:"pre-one-way/evidence"},
 {name:"diagnostic-families",truth:"truth-validation",evidence:"pre-one-way/final-validation"},
 {name:"diagnostic-interiors",truth:"truth-interior",evidence:"pre-one-way/final-interior"},
 {name:"fresh-room-assessment",truth:"truth-fresh-room",evidence:"pre-one-way/final-fresh-room"},
],rows=[];
for(const group of groups){
 const prefix=path.join(root,".cache/pano3d"),manifest=JSON.parse(await fs.readFile(path.join(prefix,group.truth,"manifest.json"),"utf8")),published=JSON.parse(await fs.readFile(path.join(prefix,group.evidence,"scores.json"),"utf8"));
 for(const scene of manifest.scenes){
  const id=scene.id,cacheBytes=await fs.readFile(path.join(prefix,group.evidence,id+"-inference.json")),cache=JSON.parse(cacheBytes),truthBytes=await fs.readFile(path.join(prefix,group.truth,id,"radial.f32")),truth=new Float32Array(truthBytes.buffer.slice(truthBytes.byteOffset,truthBytes.byteOffset+truthBytes.byteLength)),mask=await fs.readFile(path.join(prefix,group.truth,id,"mask.u8")),w=scene.width,h=scene.height;
  if(truth.length!==w*h||mask.length!==w*h)throw new Error("Incomplete geometry");
  const evaluate=(input,inverse=false)=>{
   const d=Float32Array.from(truth,(_,i)=>{const v=sample(input.d,input.w,input.h,(i%w+.5)/w,(Math.floor(i/w)+.5)/h);return inverse?1/Math.max(1e-6,v):v;});
   const scale=median(Array.from(d,(v,i)=>mask[i]===1&&truth[i]>0?truth[i]/v:NaN));
   const aligned=Float32Array.from(d,v=>v*scale);let error=0,delta=0,weights=0,pixels=0;
   for(let i=0;i<d.length;i++)if(mask[i]===1&&truth[i]>0){const weight=Math.sin(Math.PI*(Math.floor(i/w)+.5)/h),v=aligned[i],t=truth[i];error+=weight*Math.abs(v-t)/t;delta+=weight*(Math.max(v/t,t/v)<1.25?1:0);weights+=weight;pixels++;}
   return {absRel:error/weights,delta1:delta/weights,pixels,scale,aligned};
  };
  const prediction=evaluate(cache.result.depth),naive=evaluate(cache.naive,true),record=published.scenes.find(r=>r.id===id);
  const ownership=Uint8Array.from(truth,(_,i)=>{const ray=direction((i%w+.5)/w,(Math.floor(i/w)+.5)/h),weights=TILES.map(tile=>project(ray,tile)?.weight||0);return weights.indexOf(Math.max(...weights));}),jumps=[];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;for(const [xx,yy]of[[(x+1)%w,y],[x,y+1]]){if(yy>=h)continue;const j=yy*w+xx;if(mask[i]!==1||mask[j]!==1)continue;if(ownership[i]!==ownership[j]||(x===w-1&&xx===0))jumps.push(Math.abs(prediction.aligned[i]-prediction.aligned[j])/((prediction.aligned[i]+prediction.aligned[j])/2));}}
  const seam={median:jumps.length?median(jumps):null,pairs:jumps.length},deltas={sphericalAbsRel:prediction.absRel-record.spherical.absRel,naiveAbsRel:naive.absRel-record.naive.absRel,delta1:prediction.delta1-record.spherical.delta1,seamMedian:seam.median-record.seam.median,seamPairs:seam.pairs-record.seam.pairs};
  if(Object.values(deltas).some(v=>Math.abs(v)>1e-12))throw new Error("Metric mismatch "+id+" "+JSON.stringify(deltas));
  const {aligned:unused1,...spherical}=prediction,{aligned:unused2,...baseline}=naive;
  rows.push({id,group:group.name,spherical,naive:baseline,seam,improvement:1-prediction.absRel/naive.absRel,deltas,cacheSha256:sha(cacheBytes),pipelineHash:cache.pipelineHash});
 }
}
const summaries=[...groups.map(g=>({name:g.name,rows:rows.filter(r=>r.group===g.name)})),{name:"pooled-development-diagnostic18",rows:rows.filter(r=>r.group!=="fresh-room-assessment")},{name:"all24",rows}].map(({name,rows})=>{const prediction=rows.reduce((s,r)=>s+r.spherical.absRel,0)/rows.length,naive=rows.reduce((s,r)=>s+r.naive.absRel,0)/rows.length;return {name,count:rows.length,meanAbsRel:prediction,meanNaiveAbsRel:naive,improvement:1-prediction/naive,allSeamsPass:rows.every(r=>r.seam.pairs>0&&r.seam.median<.02),regressions:rows.filter(r=>r.improvement<0).map(r=>({id:r.id,relativeRegression:-r.improvement}))};});
await save("confidence-metrics-review-results.json",{note:"Read-only independent numerical replay of actual-model unit-fix sourcepoint. Raw depth tensors/predicted fields are fixed, GT is used only here for evaluation. Same documented pixel-median global scale, spherical-area-weighted AbsRel/delta1, valid-mask boundary/wrap seam pairs. Float32 scale rounding intentionally matches production evaluator. Later one-way source fidelity is recorded separately; final NN runs still identify final source.",rows,summaries});
console.log(JSON.stringify(summaries,null,2));
