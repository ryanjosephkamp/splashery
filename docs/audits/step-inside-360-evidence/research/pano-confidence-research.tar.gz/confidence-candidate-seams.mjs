import fs from 'node:fs/promises';
import jpeg from 'jpeg-js';
import { panoramaPrior } from './prior-confidence-blend.js';
import { median, sample, direction, TILES, project } from '../../src/pano3d/core.js';
const configs=[['0.125',await import('./core-confidence-calibration.js')],['0.25',await import('./core-confidence-calibration.js')],['0.375',await import('./core-confidence-calibration.js')],['0.5',await import('./core-confidence-calibration.js')]];
const allGroups=[{name:'original',ids:['room','desk','stairs','arches','steps','lattice'],truth:'truth',raw:'rotations',cube:'rejected-cube-evidence'},{name:'diagnostic',ids:['still-life','forest','coast','fur','night','leaves'],truth:'truth-validation',raw:'validation/rotations',cube:'validation/evidence'},{name:'interior',ids:['interior-01','interior-02','interior-03','interior-04','interior-05','interior-06'],truth:'truth-interior',raw:'interior/rotations',cube:'interior/evidence'}];
const groups=allGroups;
const rows=[];
for(const group of groups)for(const id of group.ids){
 const prefix='.cache/pano3d/',p=jpeg.decode(await fs.readFile(prefix+group.truth+'/'+id+'/pano.jpg'),{useTArray:true});
 const photo={w:p.width,h:p.height,data:p.data};
 const raw=JSON.parse(await fs.readFile(prefix+group.raw+'/'+id+'.json','utf8'));
 const cached=JSON.parse(await fs.readFile(prefix+group.cube+'/'+id+'-inference.json','utf8'));
 const buffer=await fs.readFile(prefix+group.truth+'/'+id+'/radial.f32');const truth=new Float32Array(buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength));
 const mask=await fs.readFile(prefix+group.truth+'/'+id+'/mask.u8');
 const metric=depth=>{
  const values=Float64Array.from(truth,(_,i)=>sample(depth.d,depth.w,depth.h,(i%384+.5)/384,(Math.floor(i/384)+.5)/192));
  const scale=median(Array.from(values,(v,i)=>mask[i]===1&&truth[i]>0?truth[i]/v:NaN));let a=0,ws=0;
  for(let i=0;i<truth.length;i++)if(mask[i]===1&&truth[i]>0){const weight=Math.sin(Math.PI*(Math.floor(i/384)+.5)/192);a+=Math.abs(values[i]*scale-truth[i])/truth[i]*weight;ws+=weight;}
  return a/ws;
 };
 const scene={width:384,height:192};
    const seamJumps = (d) => {
      const ownership = (x, y) => {
        const ray = direction((x + 0.5) / scene.width, (y + 0.5) / scene.height);
        const ws = TILES.map((t) => project(ray, t)?.weight || 0);
        return ws.indexOf(Math.max(...ws));
      };
      const jumps = [];
      for (let y = 0; y < scene.height; y++)
        for (let x = 0; x < scene.width; x++) {
          const i = y * scene.width + x;
          for (const [xx, yy] of [
            [(x + 1) % scene.width, y],
            [x, y + 1],
          ]) {
            if (yy >= scene.height) continue;
            const j = yy * scene.width + xx;
            if (mask[i] !== 1 || mask[j] !== 1) continue;
            if (ownership(x, y) !== ownership(xx, yy) || (x === scene.width - 1 && xx === 0))
              jumps.push(Math.abs(d[i] - d[j]) / ((d[i] + d[j]) / 2));
          }
        }
      return { median: jumps.length ? median(jumps) : null, pairs: jumps.length };
    };

 const row={group:group.name,id,methods:{}};
 for(const [name,core] of configs.filter(([name])=>!process.env.PANO_BLEND_ASSESS||Number(name)===0.375)){
  const tiles=cached.tiles.slice(0,6).map((t,j)=>{
   const pixels=core.perspective(photo,core.TILES[j],294),{w,h,data}=pixels;
   const confidence=Uint8Array.from({length:w*h},(_,i)=>{
    const x=i%w,y=Math.floor(i/w),s=[0,0,0],ss=[0,0,0];
    for(const dy of [-2,0,2])for(const dx of [-2,0,2])for(let c=0;c<3;c++){
     const xx=Math.max(0,Math.min(w-1,x+dx)),yy=Math.max(0,Math.min(h-1,y+dy));const v=data[(yy*w+xx)*4+c]/255;s[c]+=v;ss[c]+=v*v;
    }
    return s.reduce((v,s,c)=>v+ss[c]/9-(s/9)**2,0)/3>1e-6?1:0;
   });
   return {...core.TILES[j],...t,confidence,reliability:core.tileReliability(pixels)};
  });
  const alignment=core.alignTiles(tiles),cube=core.fuseDepth(tiles,alignment);
  const result=panoramaPrior(photo,raw.outputs.map((d,j)=>({...d,offset:j/4})),cube,Number(name));
  row.methods[name]={cubeAbsRel:metric(cube),hybridAbsRel:metric(result.depth),seam:seamJumps(result.depth.d),alignment};
 }
 rows.push(row);console.log(JSON.stringify(row));
 await fs.writeFile(prefix+(process.env.PANO_BLEND_ASSESS?'confidence-candidate-seams.json':'confidence-blend-development.json'),JSON.stringify({note:'Offline input-RGB confidence study. Originalmodeloutputs reused; no truth used during calibration. All18previously examinedscenes are development/diagnostic for this study.',scenes:rows},null,2)+'\n');
}
