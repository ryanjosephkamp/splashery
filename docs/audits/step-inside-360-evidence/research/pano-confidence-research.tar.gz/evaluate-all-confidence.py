import subprocess,os,json,hashlib
from pathlib import Path
root=Path('.cache/pano3d')
groups=[('truth','evidence'),('truth-validation','final-validation'),('truth-interior','final-interior'),('truth-fresh-room','final-fresh-room')]
for truth,out in groups:
 env=os.environ.copy();env.update({'DISPLAY':':92','SPLASHERY_GL':'llvmpipe','SPLASHERY_CHROMIUM':'/usr/bin/chromium','SPLASHERY_PANO_TRUTH':str(root/truth),'SPLASHERY_PANO_EVIDENCE':str(root/out),'SPLASHERY_PANO_PORT':'4198'})
 print('Actual production run: '+out,flush=True)
 with (root/(out+'-confidence.log')).open('w') as log:subprocess.run(['node','tools/pano-evaluate.mjs'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Completed '+out,flush=True)
