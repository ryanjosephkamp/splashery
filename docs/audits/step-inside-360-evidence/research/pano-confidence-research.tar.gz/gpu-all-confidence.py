import subprocess,os,json,time,hashlib
from pathlib import Path
root=Path('.cache/pano3d');digest=hashlib.sha256(b''.join(Path('src/pano3d/'+f).read_bytes() for f in ['core.js','pipeline.js','prior.js'])).hexdigest()
for truth,out in [('truth','evidence'),('truth-validation','final-validation'),('truth-interior','final-interior'),('truth-fresh-room','final-fresh-room')]:
 for attempt in range(180):
  try:
   s=json.loads((root/out/'scores.json').read_text())
   if s['pipelineHash']==digest and len(s['scenes'])==6:break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(2)
 else:raise RuntimeError('Final model run did not complete '+out)
 env=os.environ.copy();env.update({'DISPLAY':':92','SPLASHERY_GL':'llvmpipe','SPLASHERY_CHROMIUM':'/usr/bin/chromium','SPLASHERY_PANO_TRUTH':str(root/truth),'SPLASHERY_PANO_EVIDENCE':str(root/out),'SPLASHERY_PANO_PORT':'4196'})
 print('Actual final GPU views: '+out,flush=True)
 with (root/(out+'-confidence-gpu.log')).open('w') as log:subprocess.run(['node','tools/pano-gpu-views.mjs'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Completed '+out,flush=True)
