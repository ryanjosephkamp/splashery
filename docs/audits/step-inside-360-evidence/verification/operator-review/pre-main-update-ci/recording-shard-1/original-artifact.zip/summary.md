# Suite run

- 16 of 16 files, 180 tests: 178 passed, 1 failed, 1 skipped.
- Time in files (one after another): 37 min. Wall time of this run: 28 min (2 at once).

## Failed

- `shr:202` 390x844 › the preview sheet after Stop plays the take; Discard asks first and frees it; Save still saves: failed. Error: expect(received).toBe(expected) // Object.is equality

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-pics | 1663 | 51 |
| shr | 136 | 12 |
| ai | 83 | 47 |
| phy-engine | 83 | 8 |
| qrc-build | 61 | 2 |
| fix3 | 47 | 4 |
| cdx-v3d | 41 | 19 |
| sng | 33 | 6 |
| cdx-v3d-calibration | 30 | 12 |
| cdx-v3d-review | 22 | 5 |
| snda-engine | 16 | 5 |
| pdf-engine | 11 | 2 |
| shb-engine | 7 | 1 |
| asc-engine | 5 | 1 |
| qrs-heal | 3 | 3 |
| cdx-v3d-uncapped-stage | 2 | 2 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-pics:119` Split leaf: five-link browser scans, credits, and lazy loading | 95 |
| `cdx-pics:65` every new Studio sample loads and raises into 3D; other new assets stay lazy | 91 |
| `cdx-pics:119` Fern frond: five-link browser scans, credits, and lazy loading | 83 |
| `cdx-pics:119` Green watering can: five-link browser scans, credits, and lazy loading | 76 |
| `cdx-pics:119` Potted cactus: five-link browser scans, credits, and lazy loading | 71 |
| `cdx-pics:119` Clay pitcher: five-link browser scans, credits, and lazy loading | 58 |
| `qrc-build:48` QR from real things: every build ends on a code that reads, the person's own text too | 57 |
| `cdx-pics:119` Wooden rook: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Tulip: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Pumpkin: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Ginkgo leaf: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Paper rainbow: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Scallop shell: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Lotus bloom: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Pinecone: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Clay teapot: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Wooden spinning top: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Stacked stones: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Mushroom: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Autumn squash: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Smooth pebbles: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Wooden stacking rings: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Pear: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Blue vase: five-link browser scans, credits, and lazy loading | 52 |
| `cdx-pics:119` Balloon: five-link browser scans, credits, and lazy loading | 52 |
