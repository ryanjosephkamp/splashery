# Suite run

- 26 of 26 files, 227 tests: 226 passed, 1 failed, 0 skipped.
- Time in files (one after another): 26 min. Wall time of this run: 16 min (2 at once).

## Failed

- `pages-r2:495` opaque tilted PDF faces cover their own paper backing (webgl2): failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wd | 242 | 16 |
| cdx-mp2 | 241 | 16 |
| sndc | 150 | 9 |
| smd-moving | 131 | 16 |
| hh5-ai | 109 | 11 |
| pages-r2 | 100 | 11 |
| scr | 89 | 6 |
| sci | 78 | 23 |
| cdx-pfc | 56 | 10 |
| hea | 53 | 6 |
| arc2 | 49 | 7 |
| chs | 43 | 10 |
| cdx-p3d2-text | 34 | 2 |
| smd-models | 32 | 9 |
| cdx-life | 30 | 5 |
| qrc-barcodes | 27 | 5 |
| abb | 21 | 6 |
| sp4 | 16 | 9 |
| sts-engine | 15 | 2 |
| unit | 7 | 20 |
| cdx-p3d4-worker-preparation | 6 | 1 |
| st4-engine | 6 | 2 |
| cdx-v3d-seed-bounds | 4 | 7 |
| cdx-v3d-extraction-rate | 3 | 5 |
| cdx-v3d-background | 3 | 11 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-mp2:401` upload refinement reduces machine and bridge regressions without losing horse and Sintel s | 132 |
| `wd:187` worlds › each tier stays within its splat budget | 82 |
| `scr:165` lane Screens screenshots at 390x844 and 1440x900 | 56 |
| `wd:210` worlds › screenshots at 390x844 and 1440x900 | 44 |
| `cdx-mp2:317` a real uploaded bunny refines every depth frame and closes the measured low-tier sample ga | 31 |
| `sndc:108` the daisy's petals each tap as they land, and the rose's one does too | 29 |
| `sndc:150` the splatting toy's sorting view clicks once for each splat placed; each view has its own  | 28 |
| `pages-r2:564` a closed album cover hides its picture faces (webgpu) | 25 |
| `cdx-mp2:436` 60 fps input retains its native picture and improves depth in the background at a larger s | 25 |
| `qrc-barcodes:132` Other barcodes in the browser: every kind reads back from the stage | 24 |
| `cdx-pfc:164` all forms fly, the QR encoder loads on demand, and the rendered QR scans at 1440x900 | 23 |
| `sndc:230` screenshot: the periodic table's built atom (1440x900) | 23 |
| `sci:460` in the browser › screenshots of galaxy-box at phone and desktop size | 23 |
| `wd:242` worlds render (r2) › the sharp kernel and the tier's pixel ratio are on, and the URL overr | 22 |
| `hh5-ai:283` screenshots: the difference-engine, hands-on | 20 |
| `wd:138` worlds › walking up to a landmark or tapping its sign opens its card | 20 |
| `wd:40` worlds › the Test island loads without console errors and shows its start screen | 20 |
| `sci:460` in the browser › screenshots of smlm-microscope at phone and desktop size | 19 |
| `scr:124` the Screen switches on with a tap, plays its video, and pauses and plays again | 19 |
| `sndc:175` each splat field and each book style plays its own sound | 19 |
| `pages-r2:134` sharp pages in the real renderer › the requested WebGPU renderer draws masked cards and re | 18 |
| `sndc:128` the periodic table's atom ticks once for each proton and neutron as it packs in | 18 |
| `smd-models:65` the sample models › the toy shows each one | 17 |
| `sci:460` in the browser › screenshots of thermal-ellipsoids at phone and desktop size | 17 |
| `cdx-p3d2-text:10` flattened photo-textured splats retain sans-serif text fidelity | 17 |
