# Suite run

- 25 of 25 files, 206 tests: 205 passed, 1 failed, 0 skipped.
- Time in files (one after another): 19 min. Wall time of this run: 10 min (2 at once).

## Failed

- `hl1:92` Hands-on: lift, toss, land, settle and Reset: failed. Error: Level 1 gaps; full receipts are attached

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wdr3 | 258 | 7 |
| pg6 | 157 | 16 |
| cdx-mp2-r3 | 130 | 16 |
| hl1 | 93 | 2 |
| heb | 73 | 6 |
| fx7 | 71 | 20 |
| cdx-adv-files | 70 | 10 |
| vwr | 45 | 21 |
| lv9 | 45 | 7 |
| fx8 | 41 | 5 |
| fx4 | 41 | 4 |
| cdx-p3d2-text | 30 | 2 |
| man7a | 25 | 16 |
| hh3-pictures | 23 | 2 |
| fx13 | 16 | 3 |
| arc2-engine | 9 | 1 |
| man7b | 8 | 24 |
| cdx-three-bounds | 6 | 9 |
| chs-engine | 5 | 1 |
| cdx-v3d-real-clips | 3 | 9 |
| cdx-pano-prior | 3 | 4 |
| bld | 3 | 7 |
| cdx-mp2-decode | 2 | 7 |
| cdx-p3d4-soften | 2 | 1 |
| cdx-v3d-decoded-frame | 2 | 6 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `wdr3:133` worlds r3 › idle, walk and run play, and the standing foot stays planted while it walks an | 111 |
| `hl1:92` Hands-on: lift, toss, land, settle and Reset | 90 |
| `pg6:567` Pop out (in the app) › Your book: two figures up at once, one laid back; the switch holds  | 82 |
| `wdr3:96` worlds r3 › the realistic character is hybrid mode's default and loads its level in each t | 55 |
| `wdr3:235` worlds r3 › screenshots at 390x844 and 1440x900 | 52 |
| `pg6:646` Pop out (in the app) › a depth saved in a scene comes back when the figure is raised | 33 |
| `wdr3:217` worlds r3 › ?stats=1 shows frames per second, the tier, the mode, splats and draw calls | 25 |
| `vwr:358` the toys › screenshots | 23 |
| `lv9:178` Sound in a box, played to › your audio: each note drives its mode at once, the beads settl | 23 |
| `fx7:462` clothes take flag colors on their cloth | 21 |
| `pg6:618` Pop out (in the app) › the Picture lab pops a PDF figure and a drawn box | 20 |
| `fx8:185` alarm-clock screenshots at 390x844 and 1440x900 | 20 |
| `pg6:681` Pop out (in the app) › old links and saved scenes (v2 and v3) still load; one with Pop out | 17 |
| `cdx-p3d2-text:10` flattened photo-textured splats retain DejaVu Sans text fidelity | 14 |
| `cdx-p3d2-text:10` flattened photo-textured splats retain sans-serif text fidelity | 14 |
| `fx13:193` Pop out with Pop-up layers on (in the app) › the Picture lab's chart rises with Pop-up lay | 14 |
| `fx4:185` marble screenshots at 390x844 and 1440x900 | 14 |
| `fx8:81` on the page, the hands show the page's time, upright, on its side and upside down | 14 |
| `heb:65` chest: the lid lifts on its hinge, drops shut from low, stays open from high | 14 |
| `heb:122` sword in the stone: stuck, then drawn out along its line; stays; clanks back in | 13 |
| `fx4:185` clock screenshots at 390x844 and 1440x900 | 13 |
| `fx7:277` lane Fix7 screenshots at 1440x900 | 13 |
| `cdx-mp2-r3:80` returning to a toy cannot revive its abandoned first upload | 13 |
| `fx7:235` taps that used to miss: the one splat's corners and the sunglasses' lenses | 13 |
| `cdx-mp2-r3:80` changing toys before an upload's first answer releases the paused player | 13 |
