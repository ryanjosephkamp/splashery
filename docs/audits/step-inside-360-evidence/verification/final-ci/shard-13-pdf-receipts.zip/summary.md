# Suite run

- 26 of 26 files, 210 tests: 209 passed, 1 failed, 0 skipped.
- Time in files (one after another): 30 min. Wall time of this run: 19 min (2 at once).

## Failed

- `pages-r2:495` opaque tilted PDF faces cover their own paper backing (webgl2): failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wd | 300 | 16 |
| cdx-mp2 | 296 | 16 |
| sndc | 173 | 9 |
| smd-moving | 152 | 16 |
| fb | 129 | 6 |
| hh5-ai | 127 | 11 |
| pages-r2 | 106 | 11 |
| hh1-balls | 84 | 5 |
| cdx-pfc | 66 | 10 |
| arc2 | 57 | 7 |
| man5 | 47 | 19 |
| fx6 | 45 | 4 |
| live3-engine | 42 | 4 |
| smd-models | 36 | 9 |
| cdx-life | 35 | 5 |
| spg | 31 | 9 |
| abb | 20 | 6 |
| sci3-engine | 16 | 2 |
| stm-engine | 9 | 1 |
| cdx-p3d4-worker-preparation | 6 | 1 |
| cdx-v3d-seed-bounds | 4 | 7 |
| cdx-v3d-extraction-rate | 4 | 5 |
| cdx-v3d-background | 3 | 11 |
| cdx-p3d2-r3-footprint | 3 | 2 |
| hec-engine | 3 | 12 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-mp2:401` upload refinement reduces machine and bridge regressions without losing horse and Sintel s | 162 |
| `wd:187` worlds › each tier stays within its splat budget | 105 |
| `wd:210` worlds › screenshots at 390x844 and 1440x900 | 59 |
| `cdx-mp2:317` a real uploaded bunny refines every depth frame and closes the measured low-tier sample ga | 39 |
| `sndc:150` the splatting toy's sorting view clicks once for each splat placed; each view has its own  | 33 |
| `hh1-balls:34` every ball: its own bounce, room to roll and a landing sound | 33 |
| `cdx-mp2:436` 60 fps input retains its native picture and improves depth in the background at a larger s | 33 |
| `sndc:108` the daisy's petals each tap as they land, and the rose's one does too | 32 |
| `fb:121` the even torus, disc, ellipsoid, tube and rounded box are on their surfaces | 32 |
| `fb:187` every toy the lane changed builds at the phone tier, within its budget | 29 |
| `wd:242` worlds render (r2) › the sharp kernel and the tier's pixel ratio are on, and the URL overr | 27 |
| `sndc:230` screenshot: the periodic table's built atom (1440x900) | 27 |
| `wd:138` worlds › walking up to a landmark or tapping its sign opens its card | 25 |
| `pages-r2:564` a closed album cover hides its picture faces (webgpu) | 25 |
| `live3-engine:57` the Live pill never covers a control, on a phone or a desktop | 24 |
| `sndc:175` each splat field and each book style plays its own sound | 24 |
| `cdx-pfc:164` all forms fly, the QR encoder loads on demand, and the rendered QR scans at 1440x900 | 23 |
| `hh5-ai:283` screenshots: the difference-engine, hands-on | 23 |
| `wd:40` worlds › the Test island loads without console errors and shows its start screen | 22 |
| `sndc:128` the periodic table's atom ticks once for each proton and neutron as it packs in | 22 |
| `pages-r2:134` sharp pages in the real renderer › the requested WebGPU renderer draws masked cards and re | 22 |
| `man5:201` the PDF › the same input and the same Chromium print the same bytes | 21 |
| `fb:221` marble screenshots at 390x844 and 1440x900 | 19 |
| `wd:168` worlds › the list view lists every landmark, and Go there takes you to one | 19 |
| `smd-models:65` the sample models › the toy shows each one | 19 |
