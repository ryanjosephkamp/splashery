import fs from "node:fs/promises";
import { chromium } from "playwright";
const out="/workspace/pano3d-clips/docs/audits/step-inside-360-evidence";
const browser=await chromium.launch({executablePath:"/usr/bin/chromium",headless:true,args:["--no-sandbox","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist","--enable-unsafe-webgpu","--enable-features=Vulkan,WebGPU","--use-webgpu-adapter=swiftshader","--use-vulkan=swiftshader"]});
try {
 const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1});
 const errors=[];page.on("pageerror",e=>errors.push(e.message));
 await page.goto("http://127.0.0.1:4173/?labs=1&renderer=webgpu&profile=low&adapt=off");
 await page.waitForSelector("body[data-ready=true]");
 const start=Date.now();
 await page.evaluate(()=>window.__splashery.app.chooseToy("step-inside-360"));
 await page.waitForFunction(()=>!window.__splashery.player.loading&&window.__splashery.player.toyInfo?.recipe?.inside);
 const stats=await page.evaluate(async()=>{
  const p=window.__splashery.player,c=p.camera;
  c.cur.distance=c.tgt.distance=c.home.distance;
  await p.stage.captureFrame();
  return {webgpu:p.stage.device.isWebGPU,count:p.proc.ctx.buf.count,buffer:[p.stage.canvas.width,p.stage.canvas.height],profile:p.profile,inside:p.camera.inside,legend:p.motion.out.legend};
 });
 await page.screenshot({path:out+"/ui/webgpu-1440x900.png"});
 const record={createdUTC:new Date().toISOString(),profile:"low",viewport:[1440,900],deviceScaleFactor:1,firstLookMs:Date.now()-start,...stats,errors,note:"Actual product and renderer, 90,000 requested splat budget via recipe density, WebGPU/SwiftShader. Measurement during concurrent suite; not a phone latency claim."};
 if(!stats.webgpu||stats.count<80000||stats.count>90000||errors.length)throw new Error(JSON.stringify(record));
 await fs.writeFile(out+"/verification/webgpu.json",JSON.stringify(record,null,2)+"\n");
 console.log(JSON.stringify(record));
} finally {await browser.close();}
