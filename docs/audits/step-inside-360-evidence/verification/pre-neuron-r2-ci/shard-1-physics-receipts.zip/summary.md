# Suite run

- 16 of 16 files, 126 tests: 125 passed, 1 failed, 0 skipped.
- Time in files (one after another): 48 min. Wall time of this run: 40 min (2 at once).

## Failed

- `phy:64` Pebbles: stones pick up and stack into a new cairn; a careless one topples: failed. Error: expect(received).toBeGreaterThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-pics | 1987 | 51 |
| phy | 387 | 6 |
| arc | 72 | 13 |
| hh4-landmarks | 62 | 7 |
| cdx-p3d2-r3-edges | 57 | 3 |
| hh4-tiny | 53 | 6 |
| sky | 53 | 10 |
| live5 | 44 | 5 |
| live4 | 40 | 2 |
| qr4-scan | 33 | 2 |
| ui4-engine | 27 | 2 |
| sky-engine | 15 | 4 |
| e4f | 12 | 5 |
| cmp2-sort | 9 | 6 |
| cdx-v3d-handoff | 3 | 2 |
| cdx-v3d-uncapped-stage | 2 | 2 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-pics:119` Split leaf: five-link browser scans, credits, and lazy loading | 112 |
| `cdx-pics:65` every new Studio sample loads and raises into 3D; other new assets stay lazy | 112 |
| `phy:111` jelly and amoeba stretch and spring back; cherries swing and knock | 108 |
| `cdx-pics:119` Fern frond: five-link browser scans, credits, and lazy loading | 82 |
| `phy:156` the spring toy stretches and settles; the bow shoots; sushi picks the tapped piece | 78 |
| `cdx-pics:119` Paper rainbow: five-link browser scans, credits, and lazy loading | 67 |
| `cdx-pics:119` Mushroom: five-link browser scans, credits, and lazy loading | 67 |
| `cdx-pics:119` Pinecone: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Balloon: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Stacked stones: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Wooden rook: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Clay teapot: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Wooden stacking rings: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Clay pitcher: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Green watering can: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Wooden spinning top: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Lotus bloom: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Ginkgo leaf: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Pear: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Blue vase: five-link browser scans, credits, and lazy loading | 66 |
| `cdx-pics:119` Smooth pebbles: five-link browser scans, credits, and lazy loading | 65 |
| `cdx-pics:119` Tulip: five-link browser scans, credits, and lazy loading | 65 |
| `cdx-pics:119` Scallop shell: five-link browser scans, credits, and lazy loading | 65 |
| `cdx-pics:119` Pumpkin: five-link browser scans, credits, and lazy loading | 65 |
| `cdx-pics:119` Autumn squash: five-link browser scans, credits, and lazy loading | 65 |
