# Suite run

- 26 of 26 files, 195 tests: 194 passed, 1 failed, 0 skipped.
- Time in files (one after another): 25 min. Wall time of this run: 13 min (2 at once).

## Failed

- `hh5-gems:154` quartz cluster: a big point snaps off the rock, rests, and clicks back into its place: failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| lv7 | 394 | 11 |
| fx4-engine | 300 | 4 |
| mt2 | 128 | 19 |
| live2 | 96 | 11 |
| hec | 76 | 9 |
| hh5-math | 72 | 9 |
| arc-engine | 49 | 7 |
| hh5-gems | 47 | 5 |
| stm | 45 | 20 |
| hh3-holidays | 44 | 5 |
| pt2 | 43 | 5 |
| g | 40 | 9 |
| ui5 | 36 | 3 |
| phf2 | 21 | 7 |
| ops-media | 21 | 1 |
| cdx-p3d4-render-hold | 20 | 3 |
| cdx-renderer-diag | 19 | 18 |
| cdx-v3d-tile-size-gpu | 14 | 1 |
| hh3-storybook | 14 | 1 |
| cdx-v3d-older-browser-ui | 8 | 1 |
| cdx-p3d2-core | 7 | 4 |
| hh1-shapes | 7 | 1 |
| chem | 5 | 24 |
| cdx-p3d5-study-state | 3 | 3 |
| cdx-v3d-bench-join | 2 | 12 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `lv7:106` the mirror on a camera (a generated mannequin) › plain: steadier than before, frame to fra | 174 |
| `fx4-engine:79` toys without the rim kind draw as before (webgpu) | 129 |
| `lv7:150` the mirror on a camera (a generated mannequin) › hologram: nothing drawn over the face, an | 122 |
| `fx4-engine:79` toys without the rim kind draw as before (webgl2) | 110 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgpu) | 28 |
| `live2:207` in the browser › the click track: each click is at the now mark within 50 ms of when it is | 26 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgl2) | 26 |
| `lv7:520` screenshots at phone and desktop size: the landscape growing | 26 |
| `hec:217` on its side or upside down, the soft parts hang toward the world's down and Reset still wo | 25 |
| `lv7:393` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new  | 25 |
| `ops-media:8` the web-address box names only what each picture toy opens | 19 |
| `mt2:274` duoprism mid-tap screenshots at 390x844 and 1440x900 | 18 |
| `ui5:41` rotation defaults › the storybook, umbrella, xylophone and upright piano open with the til | 18 |
| `mt2:274` thomas-attractor mid-tap screenshots at 390x844 and 1440x900 | 18 |
| `mt2:274` twenty-four-cell mid-tap screenshots at 390x844 and 1440x900 | 18 |
| `lv7:353` the Chladni plate › a tap bows the plate (the bow shows while it moves the sand) and nothi | 18 |
| `stm:366` the toy in the browser › a sample shows, a tap lifts and settles, opening your own models  | 18 |
| `mt2:274` five-cell mid-tap screenshots at 390x844 and 1440x900 | 18 |
| `pt2:110` taps split and a hold merges where the finger is, at 1440×900 | 17 |
| `mt2:274` sixteen-cell mid-tap screenshots at 390x844 and 1440x900 | 17 |
| `mt2:274` rossler-attractor mid-tap screenshots at 390x844 and 1440x900 | 17 |
| `live2:297` in the browser › ribbons: builds in both views, on paper and alone, and fills in as it pla | 17 |
| `mt2:274` aizawa-attractor mid-tap screenshots at 390x844 and 1440x900 | 17 |
| `hec:275` the soft parts' step time stays small with each demo toy in play | 17 |
| `hh5-math:265` screenshots: the menger-sponge, hands-on | 16 |
