# Suite run

- 26 of 26 files, 195 tests: 194 passed, 1 failed, 0 skipped.
- Time in files (one after another): 38 min. Wall time of this run: 20 min (2 at once).

## Failed

- `fx4-engine:79` toys without the rim kind draw as before (webgpu): timedOut. Test timeout of 240000ms exceeded.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| lv7 | 579 | 11 |
| fx4-engine | 541 | 4 |
| mt2 | 172 | 19 |
| live2 | 122 | 11 |
| hec | 117 | 9 |
| hh5-math | 98 | 9 |
| stm | 74 | 20 |
| arc-engine | 72 | 7 |
| hh3-holidays | 71 | 5 |
| hh5-gems | 60 | 5 |
| g | 57 | 9 |
| ui5 | 55 | 3 |
| pt2 | 51 | 5 |
| phf2 | 34 | 7 |
| cdx-p3d4-render-hold | 31 | 3 |
| ops-media | 28 | 1 |
| cdx-renderer-diag | 25 | 18 |
| cdx-v3d-tile-size-gpu | 24 | 1 |
| hh3-storybook | 19 | 1 |
| cdx-p3d2-core | 14 | 4 |
| cdx-v3d-older-browser-ui | 12 | 1 |
| hh1-shapes | 10 | 1 |
| chem | 10 | 24 |
| cdx-v3d-bench-join | 5 | 12 |
| cdx-p3d5-study-state | 3 | 3 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `lv7:106` the mirror on a camera (a generated mannequin) › plain: steadier than before, frame to fra | 272 |
| `fx4-engine:79` toys without the rim kind draw as before (webgpu) | 247 |
| `fx4-engine:79` toys without the rim kind draw as before (webgl2) | 196 |
| `lv7:150` the mirror on a camera (a generated mannequin) › hologram: nothing drawn over the face, an | 180 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgpu) | 49 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgl2) | 41 |
| `hec:217` on its side or upside down, the soft parts hang toward the world's down and Reset still wo | 39 |
| `lv7:520` screenshots at phone and desktop size: the landscape growing | 31 |
| `stm:366` the toy in the browser › a sample shows, a tap lifts and settles, opening your own models  | 30 |
| `ui5:41` rotation defaults › the storybook, umbrella, xylophone and upright piano open with the til | 29 |
| `lv7:393` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new  | 28 |
| `live2:207` in the browser › the click track: each click is at the now mark within 50 ms of when it is | 28 |
| `stm:426` the toy in the browser › screenshots at phone and desktop size | 27 |
| `ops-media:16` the web-address box names only what each picture toy opens | 25 |
| `hec:275` the soft parts' step time stays small with each demo toy in play | 25 |
| `mt2:274` thomas-attractor mid-tap screenshots at 390x844 and 1440x900 | 25 |
| `phf2:135` screenshots: Photo to 3D in Splats, One color per splat, at phone and desktop size | 25 |
| `mt2:274` duoprism mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `lv7:353` the Chladni plate › a tap bows the plate (the bow shows while it moves the sand) and nothi | 24 |
| `mt2:274` rossler-attractor mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `mt2:274` five-cell mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `mt2:274` twenty-four-cell mid-tap screenshots at 390x844 and 1440x900 | 23 |
| `live2:297` in the browser › ribbons: builds in both views, on paper and alone, and fills in as it pla | 23 |
| `mt2:274` aizawa-attractor mid-tap screenshots at 390x844 and 1440x900 | 23 |
| `mt2:274` sixteen-cell mid-tap screenshots at 390x844 and 1440x900 | 22 |
