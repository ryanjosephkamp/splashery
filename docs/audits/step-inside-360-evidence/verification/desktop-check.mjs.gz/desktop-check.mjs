import fs from "node:fs/promises";
import { chromium } from "playwright";
const out="/workspace/pano3d-clips/docs/audits/step-inside-360-evidence";
const browser=await chromium.launch({executablePath:"/usr/bin/chromium",headless:false,args:["--no-sandbox","--use-gl=angle","--use-angle=gl","--enable-unsafe-swiftshader","--ignore-gpu-blocklist"]});
try {
 const page=await browser.newPage({viewport:{width:1440,height:900},deviceScaleFactor:1});
 const errors=[];page.on("pageerror",e=>errors.push(e.message));
 await page.goto("http://127.0.0.1:4173/?labs=1&renderer=webgl2&profile=high&adapt=off");
 await page.waitForSelector("body[data-ready=true]");
 const start=Date.now();
 await page.evaluate(()=>window.__splashery.app.chooseToy("step-inside-360"));
 await page.waitForFunction(()=>!window.__splashery.player.loading&&window.__splashery.player.toyInfo?.recipe?.inside);
 const stats=await page.evaluate(async()=>{
  const p=window.__splashery.player,c=p.camera;
  c.cur.distance=c.tgt.distance=c.home.distance;
  await p.stage.captureFrame();
  return {count:p.proc.ctx.buf.count,buffer:[p.stage.canvas.width,p.stage.canvas.height],profile:p.profile,inside:p.camera.inside,legend:p.motion.out.legend};
 });
 await page.screenshot({path:out+"/ui/desktop-high-1440x900.png"});
 const record={createdUTC:new Date().toISOString(),profile:"high",viewport:[1440,900],deviceScaleFactor:1,firstLookMs:Date.now()-start,...stats,errors,note:"Actual product and renderer, 300,000 requested splat budget via recipe density, Mesa llvmpipe. Measurement during concurrent suite; not a phone latency claim."};
 if(stats.count<270000||stats.count>300000||errors.length)throw new Error(JSON.stringify(record));
 await fs.writeFile(out+"/verification/desktop-high.json",JSON.stringify(record,null,2)+"\n");
 console.log(JSON.stringify(record));
} finally {await browser.close();}
