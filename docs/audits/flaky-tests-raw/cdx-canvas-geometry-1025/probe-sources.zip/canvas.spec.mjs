import {test,expect} from "@playwright/test";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import config from "../../../playwright.config.mjs";
import {cameras} from "../../../tools/cdx-mir-camera.mjs";
import {fakeCamera,openMirror,measure} from "./measure.mjs";
test("native canvas crop geometry, original still drift",async({playwright,baseURL},info)=>{
 test.setTimeout(600000);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-native-canvas-"));
 cameras(dir,20,["still"]);
 process.env.CANVAS_PROBE_OUT=info.outputPath("native-pngs");
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,"still.y4m"),config.use.launchOptions.args)});
 try {
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  const errors=[],requests=[];page.on("pageerror",e=>errors.push(e.message));page.on("request",r=>requests.push(r.url()));
  await openMirror(page,baseURL+"/");
  const m=await measure(page,{answers:6});console.log("cdx mirror still:",JSON.stringify(m));
  expect(m.heightJitter).toBeLessThan(.00055);expect(m.shownJitter).toBeLessThan(.95);
  expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
  expect(requests.filter(u=>/^https?:/.test(u)&&new URL(u).origin!==new URL(baseURL).origin)).toEqual([]);
 }finally{await browser.close();fs.rmSync(dir,{recursive:true,force:true});}
});
