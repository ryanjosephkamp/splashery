import {test,expect} from "@playwright/test";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import config from "../../../playwright.config.mjs";
import {cameras} from "../../../tools/cdx-mir-camera.mjs";
import {fakeCamera,openMirror,measure,prepareCanvasPair} from "./measure.mjs";
for(const order of ["playwright-first","canvas-first"])for(const [clip,height,shown]of [["still",.00055,.95],["low-light",.0135,2.2]])
test(`${order}: ${clip}: original mirror drift and exact canvas pixels`,async({playwright,baseURL},info)=>{
 test.setTimeout(600000);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-native-canvas-"));cameras(dir,20,[clip]);
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,`${clip}.y4m`),config.use.launchOptions.args)});
 try {
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  const errors=[],requests=[];page.on("pageerror",e=>errors.push(e.message));page.on("request",r=>requests.push(r.url()));
  await openMirror(page,baseURL+"/");prepareCanvasPair(page,{order,directory:info.outputPath("native-pngs")});
  const m=await measure(page,{answers:6});console.log(`cdx mirror ${clip}:`,JSON.stringify(m));
  expect(m.heightJitter).toBeLessThan(height);expect(m.shownJitter).toBeLessThan(shown);
  expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
  expect(requests.filter(u=>/^https?:/.test(u)&&new URL(u).origin!==new URL(baseURL).origin)).toEqual([]);
 }finally{await browser.close();fs.rmSync(dir,{recursive:true,force:true});}
});
