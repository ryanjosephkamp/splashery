import {defineConfig} from "@playwright/test";
import config from "../../../playwright.config.mjs";
export default defineConfig({...config,testDir:new URL("./",import.meta.url).pathname,testMatch:"teddy-camera.spec.mjs",webServer:{...config.webServer,cwd:"/workspace/splashery"}});
