import {test, expect} from "@playwright/test";
import {settleCamera} from "../../../tests/helpers/settled-camera.mjs";
const APP = "/?renderer=webgl2&adapt=off&profile=mid";
async function open(page, id, options) {
  await page.goto(APP);
  await page.waitForSelector("body[data-ready='true']", { timeout: 180_000 });
  await page.evaluate(
    async ({ id, options }) => {
      const { app, player } = window.__splashery;
      await app.chooseToy(id);
      if (options) await app.setToyOptions(options);
      player.opts.idleDelay = 1e9;
      player.handsOn.setOn(true);
    },
    { id, options },
  );
}

for (const mode of ["before", "after"]) {
 for (let i = 90; i <= 130; i++) {
  const factor = i / 100;
  test(`${mode}: camera distance ${factor.toFixed(2)} of its fit target`, async ({page}) => {
   await open(page, "teddy-bear");
   const natural = await page.evaluate(() => {
    const c = window.__splashery.player.camera;
    return {cur: {...c.cur}, tgt: {...c.tgt}, home: {...c.home}};
   });
   // Both arms of the experiment start from the same actual fitted view.
   await settleCamera(page);
   try {
   await page.evaluate(async (factor) => {
    const p = window.__splashery.player;
    p.camera.cur = {...p.camera.home, distance: p.camera.home.distance * factor};
    p.camera.tgt = {...p.camera.home};
    // Render this actual intermediate pose without letting setup RAFs
    // consume the fit residual before the original gesture can begin.
    const nativeUpdate = p.camera.update;
    window.__restoreFitCameraUpdate = nativeUpdate;
    p.camera.update = function(dt) { return nativeUpdate.call(this, 0); };
    await p.stage.captureFrame();
   }, factor);
   if (mode === "after") {
    await page.evaluate(() => {
      const c = window.__splashery.player.camera;
      c.update = window.__restoreFitCameraUpdate;
      window.__restoreFitCameraUpdate = null;
    });
    await settleCamera(page);
   }
   console.log("CAMERA_SETUP " + JSON.stringify({mode, nominalFactor: factor, natural}));
  const s = await page.evaluate(() => {
    const { player } = window.__splashery;
    const h = player.handsOn;
    const c = player.camera;
    if (window.__restoreFitCameraUpdate) {
      c.update = window.__restoreFitCameraUpdate;
      window.__restoreFitCameraUpdate = null;
    }
    const node = player.stage.cameraEntity;
    const pos = node.getPosition(), rot = node.getRotation();
    const inputPose = {cur: {...c.cur}, tgt: {...c.tgt}, home: {...c.home}, actualDistanceRatio: c.cur.distance / c.home.distance, target: [...c.target], offset: [...c.offset], nativePosition:[pos.x,pos.y,pos.z], nativeRotation:[rot.x,rot.y,rot.z,rot.w]};
    const ang = (q) => (q ? 2 * Math.acos(Math.min(1, Math.abs(q[3]))) : 0);
    const P = [0, 0, 0.36];
    const sp = player.screenPoint(P);
    h.pressAt(player.fromRecipe(P), sp[0], sp[1]);
    let swing = 0;
    for (let k = 1; k <= 30; k++) {
      h.moveTo(sp[0] + 8 * k * Math.sin(k / 3), sp[1] - 4 * k);
      player.update(1 / 60);
      const p = player.motion.handsParts || {};
      swing = Math.max(swing, Math.abs(ang(p.armL?.quat) - ang(p.torso?.quat)));
    }
    h.release();
    for (let k = 1; k <= 150; k++) player.update(1 / 60);
    const a = [];
    for (let k = 1; k <= 30; k++) {
      player.update(1 / 60);
      a.push(ang(player.motion.handsParts?.armR?.quat));
    }
    return { swing, settled: Math.max(...a) - Math.min(...a), inputPose };
  });
  console.log(`teddy: ${JSON.stringify(s)}`);
  expect(s.swing).toBeGreaterThan(0.15); // an arm swings on the body
  expect(s.settled).toBeLessThan(0.08); // still, two seconds after it lands
   } finally {
    if (!page.isClosed()) await page.evaluate(() => {
      if (window.__restoreFitCameraUpdate) {
        window.__splashery.player.camera.update = window.__restoreFitCameraUpdate;
        window.__restoreFitCameraUpdate = null;
      }
    });
   }
  });
 }
}
