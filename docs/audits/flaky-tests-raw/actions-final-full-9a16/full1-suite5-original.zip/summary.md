# Suite run

- 25 of 25 files, 161 tests: 159 passed, 1 failed, 1 skipped.
- Time in files (one after another): 27 min. Wall time of this run: 15 min (2 at once).

## Failed

- `pages-r2:495` opaque tilted PDF faces cover their own paper backing (webgl2): failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wdr3 | 327 | 7 |
| pg6 | 201 | 16 |
| fb | 129 | 6 |
| hl1 | 115 | 2 |
| pages-r2 | 107 | 11 |
| heb | 97 | 6 |
| cdx-adv-files | 94 | 10 |
| hh5-math | 93 | 9 |
| hh4-vehicles | 76 | 9 |
| cdx-pfc | 73 | 10 |
| ui5-engine | 70 | 7 |
| hh4-space | 48 | 6 |
| hh5-gems | 47 | 5 |
| cdx-v3d-calibration | 46 | 12 |
| smd-models | 35 | 9 |
| ui4-engine | 27 | 2 |
| hh3-crossbow | 10 | 1 |
| man2 | 10 | 2 |
| an-engine | 9 | 1 |
| qrs-steps | 9 | 5 |
| cdx-v3d-seed-bounds | 3 | 7 |
| cdx-v3d-extraction-rate | 3 | 5 |
| cdx-p3d4-soften | 2 | 1 |
| cdx-v3d-background | 2 | 11 |
| cdx-p3d2-r3-background | 2 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `wdr3:133` worlds r3 › idle, walk and run play, and the standing foot stays planted while it walks an | 144 |
| `hl1:92` Hands-on: lift, toss, land, settle and Reset | 112 |
| `pg6:567` Pop out (in the app) › Your book: two figures up at once, one laid back; the switch holds  | 106 |
| `wdr3:96` worlds r3 › the realistic character is hybrid mode's default and loads its level in each t | 70 |
| `wdr3:235` worlds r3 › screenshots at 390x844 and 1440x900 | 63 |
| `pg6:646` Pop out (in the app) › a depth saved in a scene comes back when the figure is raised | 42 |
| `fb:121` the even torus, disc, ellipsoid, tube and rounded box are on their surfaces | 34 |
| `wdr3:217` worlds r3 › ?stats=1 shows frames per second, the tier, the mode, splats and draw calls | 30 |
| `pages-r2:564` a closed album cover hides its picture faces (webgpu) | 29 |
| `cdx-pfc:164` all forms fly, the QR encoder loads on demand, and the rendered QR scans at 1440x900 | 28 |
| `fb:187` every toy the lane changed builds at the phone tier, within its budget | 28 |
| `pg6:618` Pop out (in the app) › the Picture lab pops a PDF figure and a drawn box | 26 |
| `heb:65` chest: the lid lifts on its hinge, drops shut from low, stays open from high | 25 |
| `pg6:681` Pop out (in the app) › old links and saved scenes (v2 and v3) still load; one with Pop out | 22 |
| `ui5-engine:65` phone › with a song or game bar up, the stage ends above the bar, so the bar never covers  | 21 |
| `hh5-math:265` screenshots: the menger-sponge, hands-on | 21 |
| `smd-models:65` the sample models › the toy shows each one | 20 |
| `fb:221` marble screenshots at 390x844 and 1440x900 | 20 |
| `pages-r2:134` sharp pages in the real renderer › the requested WebGPU renderer draws masked cards and re | 18 |
| `heb:122` sword in the stone: stuck, then drawn out along its line; stays; clanks back in | 16 |
| `fb:221` ocean-liner screenshots at 390x844 and 1440x900 | 16 |
| `fb:221` supertall screenshots at 390x844 and 1440x900 | 15 |
| `heb:95` music box: the crank turns round and round, plays the tune and turns the dancer | 15 |
| `wdr3:189` worlds r3 › the model props switch levels of detail by distance, and scattered stones and  | 15 |
| `heb:156` orange: a wedge pulled out stays out; brought back, it clicks home | 14 |
