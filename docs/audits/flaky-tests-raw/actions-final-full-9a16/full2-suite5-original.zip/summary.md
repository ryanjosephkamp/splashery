# Suite run

- 25 of 25 files, 161 tests: 159 passed, 1 failed, 1 skipped.
- Time in files (one after another): 33 min. Wall time of this run: 18 min (2 at once).

## Failed

- `pages-r2:495` opaque tilted PDF faces cover their own paper backing (webgl2): failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wdr3 | 417 | 7 |
| pg6 | 248 | 16 |
| fb | 157 | 6 |
| hl1 | 139 | 2 |
| pages-r2 | 135 | 11 |
| heb | 122 | 6 |
| cdx-adv-files | 117 | 10 |
| hh5-math | 102 | 9 |
| hh4-vehicles | 96 | 9 |
| cdx-pfc | 88 | 10 |
| ui5-engine | 83 | 7 |
| hh4-space | 62 | 6 |
| hh5-gems | 53 | 5 |
| smd-models | 47 | 9 |
| cdx-v3d-calibration | 35 | 12 |
| ui4-engine | 27 | 2 |
| man2 | 14 | 2 |
| hh3-crossbow | 13 | 1 |
| an-engine | 13 | 1 |
| qrs-steps | 12 | 5 |
| cdx-v3d-background | 4 | 11 |
| cdx-v3d-seed-bounds | 3 | 7 |
| cdx-v3d-extraction-rate | 3 | 5 |
| cdx-p3d4-soften | 3 | 1 |
| cdx-p3d2-r3-background | 2 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `wdr3:133` worlds r3 › idle, walk and run play, and the standing foot stays planted while it walks an | 181 |
| `hl1:92` Hands-on: lift, toss, land, settle and Reset | 135 |
| `pg6:567` Pop out (in the app) › Your book: two figures up at once, one laid back; the switch holds  | 131 |
| `wdr3:96` worlds r3 › the realistic character is hybrid mode's default and loads its level in each t | 93 |
| `wdr3:235` worlds r3 › screenshots at 390x844 and 1440x900 | 81 |
| `pg6:646` Pop out (in the app) › a depth saved in a scene comes back when the figure is raised | 52 |
| `fb:121` the even torus, disc, ellipsoid, tube and rounded box are on their surfaces | 42 |
| `wdr3:217` worlds r3 › ?stats=1 shows frames per second, the tier, the mode, splats and draw calls | 40 |
| `pages-r2:564` a closed album cover hides its picture faces (webgpu) | 38 |
| `fb:187` every toy the lane changed builds at the phone tier, within its budget | 36 |
| `cdx-pfc:164` all forms fly, the QR encoder loads on demand, and the rendered QR scans at 1440x900 | 36 |
| `pg6:618` Pop out (in the app) › the Picture lab pops a PDF figure and a drawn box | 31 |
| `heb:122` sword in the stone: stuck, then drawn out along its line; stays; clanks back in | 30 |
| `pg6:681` Pop out (in the app) › old links and saved scenes (v2 and v3) still load; one with Pop out | 29 |
| `hh5-math:265` screenshots: the menger-sponge, hands-on | 24 |
| `smd-models:65` the sample models › the toy shows each one | 24 |
| `ui5-engine:65` phone › with a song or game bar up, the stage ends above the bar, so the bar never covers  | 23 |
| `pages-r2:134` sharp pages in the real renderer › the requested WebGPU renderer draws masked cards and re | 23 |
| `fb:221` marble screenshots at 390x844 and 1440x900 | 23 |
| `heb:180` candy cane: pulled, the hook bends, snaps off, lands; reset mends it | 20 |
| `heb:65` chest: the lid lifts on its hinge, drops shut from low, stays open from high | 20 |
| `wdr3:189` worlds r3 › the model props switch levels of detail by distance, and scattered stones and  | 19 |
| `fb:221` supertall screenshots at 390x844 and 1440x900 | 18 |
| `heb:95` music box: the crank turns round and round, plays the tune and turns the dancer | 18 |
| `hh5-gems:181` screenshots: the pearl, hands-on | 18 |
