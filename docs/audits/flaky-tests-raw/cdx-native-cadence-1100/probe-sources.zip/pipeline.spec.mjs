import {test,expect} from "@playwright/test";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import config from "../../../playwright.config.mjs";
import {cameras} from "../../../tools/cdx-mir-camera.mjs";
import {fakeCamera,openMirror,measure} from "./measure.mjs";
for(const [clip,height,shown]of [["still",.00055,.95],["low-light",.0135,2.2]])
test(`${clip}: original mirror drift with read-only native pipeline stages`,async({playwright,baseURL},info)=>{
 test.setTimeout(600000);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-depth-pipeline-"));cameras(dir,20,["still","low-light"]);
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,`${clip}.y4m`),config.use.launchOptions.args)});
 let page;
 try {
  page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});
  await page.addInitScript({content:fs.readFileSync(new URL("./observer.js",import.meta.url),"utf8")});
  await page.route("**/src/live/relief.js",route=>route.fulfill({contentType:"text/javascript",body:fs.readFileSync(new URL("./relief-observed.js",import.meta.url),"utf8")}));
  const errors=[],requests=[];page.on("pageerror",e=>errors.push(e.message));page.on("request",r=>requests.push(r.url()));
  await openMirror(page,baseURL+"/");
  await page.evaluate(async()=>{
   const {MIRROR}=await import("/src/live/relief.js"),cam=MIRROR.cam,draw=cam.draw;
   cam.draw=function(g,options={}){const result=draw.call(this,g,options);if(result===true&&this===cam){window.__depthPipeline.draw.frames++;window.__depthPipeline.draw.seconds+=options.dt===undefined?1/60:options.dt;}return result;};
  });
  const m=await measure(page,{answers:6});console.log(`cdx mirror ${clip}:`,JSON.stringify(m));
  expect(m.heightJitter).toBeLessThan(height);expect(m.shownJitter).toBeLessThan(shown);
  expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
  expect(requests.filter(u=>/^https?:/.test(u)&&new URL(u).origin!==new URL(baseURL).origin)).toEqual([]);
 }finally{
  if(page&&!page.isClosed()){
   const receipt=await page.evaluate(()=>window.__depthPipeline),file=info.outputPath("native-depth-pipeline.json");
   fs.writeFileSync(file,JSON.stringify(receipt));await info.attach("native-depth-pipeline",{path:file,contentType:"application/json"});
   console.log("Native depth pipeline receipt:",JSON.stringify({clip,events:receipt.events.length,fineEvents:receipt.fineEvents.length,samples:receipt.samples,frames:receipt.frames.length,omitted:receipt.omitted}));
  }
  await browser.close();fs.rmSync(dir,{recursive:true,force:true});
 }
});
