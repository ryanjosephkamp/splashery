(() => {
 const byCam=new WeakMap();
 const receipt=window.__depthPipeline={events:[],fineEvents:[],samples:[],omitted:0,frames:[],draw:{frames:0,seconds:0}};
 const selected=(cam)=>{
  const cells=[];
  for(let y=Math.max(0,Math.floor(.4*cam.drows)-1);y<=Math.min(cam.drows-1,Math.ceil(.63*cam.drows)+1);y++)
   for(let x=Math.max(0,Math.floor(.44*cam.dcols)-1);x<=Math.min(cam.dcols-1,Math.ceil(.58*cam.dcols)+1);x++)cells.push(y*cam.dcols+x);
  return cells;
 };
 const numbers=(array,cells)=>cells.map(k=>array?.[k]??null);
 const frame=(s)=>({id:s.message.id,input:{w:s.sent.w,h:s.sent.h,crop:s.sent.crop,data:Array.from(s.sent.data)},output:{w:s.message.w,h:s.message.h,ms:s.message.ms,data:Array.from(s.message.d)}});
 window.__observeDepthPipeline=(cam,stage,array,extra)=>{
  if(cam.answers<=2)return;
  let state=byCam.get(cam);if(!state){state={cells:selected(cam),current:null,previous:null};byCam.set(cam,state);}
  const cells=state.cells;
  if(stage==="resampled"){
   state.previous=state.current;
   state.current={answers:cam.answers,message:extra,sent:cam.sent,
    raw:numbers(array,cells),oldCoarse:numbers(cam.smooth,cells),oldFiltered:numbers(cam.filtered,cells),oldColors:cam.depthColors?cells.map(k=>Array.from(cam.depthColors.subarray(k*3,k*3+3))):null};
   return;
  }
  const s=state.current;if(!s||s.answers!==cam.answers)throw Error("Native pipeline stage lost its answer");
  if(stage==="normalized"){
   s.normalized=numbers(array,cells);s.fit=extra.fit;s.range=[cam.lo,cam.hi];
   s.colors=cells.map(k=>Array.from(extra.colors.subarray(k*3,k*3+3)));s.still=numbers(cam.dstill,cells);return;
  }
  if(stage==="filtered"){s.filtered=numbers(array,cells);s.jump=numbers(cam.djump,cells);s.side=numbers(cam.dside,cells);return;}
  if(stage==="coarse"){
   s.coarse=numbers(array,cells);
   const changes=[];
   for(let i=0;i<cells.length;i++)if(s.oldCoarse[i]!==null&&Math.abs(s.coarse[i]-s.oldCoarse[i])>.12)
    changes.push({cell:cells[i],oldCoarse:s.oldCoarse[i],coarse:s.coarse[i],oldFiltered:s.oldFiltered[i],filtered:s.filtered[i],raw:s.raw[i],normalized:s.normalized[i],previousNormalized:state.previous?.normalized?.[i]??null,oldColor:s.oldColors?.[i],color:s.colors[i],still:s.still[i],jump:s.jump[i],side:s.side[i]});
   if(changes.length&&cam.answers>12){
    const event={answers:cam.answers,at:performance.now(),native:{...receipt.draw},fit:s.fit,range:s.range,changes};
    if(receipt.events.length<512)receipt.events.push(event);else receipt.omitted++;
    if(receipt.frames.length<2)receipt.frames.push({answers:cam.answers,current:frame(s),previous:state.previous?frame(state.previous):null});
   }
   return;
  }
  if(stage==="fine"){
   const changes=[];
   for(let y=Math.floor(.4*cam.rows);y<.63*cam.rows;y++)for(let x=Math.floor(.44*cam.cols);x<.58*cam.cols;x++){
    const k=y*cam.cols+x;if(Math.abs(array[k]-cam.target[k])>.12)changes.push({cell:k,oldTarget:cam.target[k],target:array[k],height:cam.heights[k],stillAge:cam.stillT[k],jump:cam.fjump[k],side:cam.fside[k]});
   }
   if(changes.length&&cam.answers>12&&receipt.fineEvents.length<512)receipt.fineEvents.push({answers:cam.answers,at:performance.now(),native:{...receipt.draw},changes});
  }
 };
 window.__recordMirrorSample=(cam,index)=>{
  const ages=[];for(let y=Math.floor(.4*cam.rows);y<.63*cam.rows;y++)for(let x=Math.floor(.44*cam.cols);x<.58*cam.cols;x++)ages.push(cam.stillT[y*cam.cols+x]);
  receipt.samples.push({index,answers:cam.answers,at:performance.now(),native:{...receipt.draw},minStillAge:Math.min(...ages),maxStillAge:Math.max(...ages)});
 };
})();
