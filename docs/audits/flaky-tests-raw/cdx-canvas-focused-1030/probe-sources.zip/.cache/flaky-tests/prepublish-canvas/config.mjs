import {defineConfig} from "@playwright/test";
import base from "../../../playwright.config.mjs";
export default defineConfig({...base,testDir:"/workspace/splashery/tests",testMatch:["cdx-mir.spec.mjs","lv7.spec.mjs"],webServer:{...base.webServer,cwd:"/workspace/splashery"}});
