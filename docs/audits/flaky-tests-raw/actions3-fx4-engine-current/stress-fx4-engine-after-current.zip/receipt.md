<!-- splashery-flaky-fx4-engine-after -->
### fx4-engine: after stress receipt

Source: `23664b6dc4e289b50ea3035346f4a8846379ff13`; 30 repetitions, 4 workers, 2 CPU burners, llvmpipe, v22.23.3, Chromium 141.0.7390.37. [Run](https://github.com/ryanjosephkamp/splashery/actions/runs/39004136389).

| Variant | Passed | Failed | Skipped/interrupted |
| --- | ---: | ---: | ---: |
| fx4-engine.spec.mjs › beach-ball: toys without the rim kind draw as before (webgpu) | 30 | 0 | 0 |
| fx4-engine.spec.mjs › bouncy-ball: toys without the rim kind draw as before (webgpu) | 30 | 0 | 0 |
| fx4-engine.spec.mjs › gift-box: toys without the rim kind draw as before (webgpu) | 30 | 0 | 0 |
