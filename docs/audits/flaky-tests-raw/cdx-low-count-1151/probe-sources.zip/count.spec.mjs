import {test,expect} from "@playwright/test";
import fs from "node:fs";import os from "node:os";import path from "node:path";
import config from "../../../playwright.config.mjs";
import {cameras} from "../../../tools/cdx-mir-camera.mjs";
import {fakeCamera,openMirror,measure} from "./measure.mjs";
for(const trial of [0,1,2,3])for(const [clip,height,shown]of [["low-light",.0135,2.2]])
test(`${trial}: ${clip}: twenty original native observations`,async({playwright,baseURL})=>{
 test.setTimeout(600000);const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-count-control-"));cameras(dir,20,["still","low-light"]);
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,`${clip}.y4m`),config.use.launchOptions.args)});
 try{
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});const errors=[],requests=[];page.on("pageerror",e=>errors.push(e.message));page.on("request",r=>requests.push(r.url()));
  await openMirror(page,baseURL+"/");const m=await measure(page,{answers:20});console.log(`cdx mirror ${clip}:`,JSON.stringify(m));
  expect(m.heightJitter).toBeLessThan(height);expect(m.shownJitter).toBeLessThan(shown);expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
  expect(requests.filter(u=>/^https?:/.test(u)&&new URL(u).origin!==new URL(baseURL).origin)).toEqual([]);
 }finally{await browser.close();fs.rmSync(dir,{recursive:true,force:true});}
});
test("real motion still exceeds both original limits with twenty observations",async({playwright,baseURL})=>{
 test.setTimeout(600000);const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-count-motion-"));cameras(dir,20,["turn"]);
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,"turn.y4m"),config.use.launchOptions.args)});
 try{
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});const errors=[];page.on("pageerror",e=>errors.push(e.message));
  await openMirror(page,baseURL+"/");const m=await measure(page,{answers:20});console.log("Real native twenty-observation motion:",JSON.stringify(m));
  expect(m.heightJitter).toBeGreaterThan(.00055);expect(m.shownJitter).toBeGreaterThan(.95);expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
 }finally{await browser.close();fs.rmSync(dir,{recursive:true,force:true});}
});
