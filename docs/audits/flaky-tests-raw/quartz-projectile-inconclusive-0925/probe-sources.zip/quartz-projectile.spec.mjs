import { test as base, expect } from "@playwright/test";
import fs from "node:fs";

const beforeSource = fs.readFileSync(new URL("./hands-on-before.js", import.meta.url), "utf8");
const test = base.extend({
  guardMode: ["before", { option: true }],
  page: async ({ page, guardMode }, use) => {
    if (guardMode === "before")
      await page.route("**/src/physics/hands-on.js", (route) => route.fulfill({
        status: 200, contentType: "text/javascript", body: beforeSource,
      }));
    // After uses the actual current site module, not an emulated replacement.
    await use(page);
  },
});

async function observeNativeCollisions(page) {
  await page.evaluate(() => {
    const h = window.__splashery.player.handsOn;
    const [target, projectile] = h.pieces.map((piece) => piece.body);
    const nativeHits = new WeakSet();
    const take = h.world.takeHits;
    h.world.takeHits = function (...args) {
      const hits = take.apply(this, args);
      for (const hit of hits) nativeHits.add(hit);
      return hits;
    };
    const snapshot = () => {
      const joint = h.joints.joint(target);
      return { id: target.id, pinned: !!target.pinned, held: !!target.held,
        broken: joint.broken, pos: target.pos.slice(), home: joint.pc.home.pos.slice(),
        jointTime: h.joints.time, simTime: h.simTime };
    };
    window.__quartzProjectile = { phase: "original", target: target.id,
      projectile: projectile.id, hits: [], initial: snapshot() };
    const native = h.onHit;
    h.onHit = function (hit) {
      const a = hit.body, b = hit.other;
      const row = { phase: window.__quartzProjectile.phase, nativeWorldHit: nativeHits.has(hit),
        body: a?.id, other: b?.id, speed: hit.speed / this.R(),
        bodyHeld: !!a?.held, otherHeld: !!b?.held, before: snapshot() };
      const pair = (a === target && b === projectile) || (a === projectile && b === target);
      row.qualifying = row.nativeWorldHit && row.phase === "released" && pair && row.speed > 2.5 &&
        !row.bodyHeld && !row.otherHeld && row.before.pinned && !row.before.broken;
      try {
        return native.call(this, hit);
      } finally {
        row.after = snapshot();
        if (a === target || b === target || a === projectile || b === projectile)
          window.__quartzProjectile.hits.push(row);
      }
    };
  });
}

// UNEXECUTED GEOMETRY SCAFFOLD. This is one predeclared attempt, not an
// adaptive search or a known successful launch. It adds a second real-user
// interaction after the complete original return gesture. Recipe, bodies,
// native collision dispatch, and original final assertions stay unchanged.
async function launchExistingPieceOne(page) {
  return page.evaluate(() => {
    const { player } = window.__splashery;
    const h = player.handsOn;
    const [target, projectile] = h.pieces.map((piece) => piece.body);
    const home = h.pieces[0].home.pos.slice();
    const fromHome = h.pieces[1].home.pos.slice();
    const start = projectile.pos.slice();
    const R = h.R();
    const dx = fromHome[0] - home[0], dz = fromHome[2] - home[2];
    const length = Math.hypot(dx, dz);
    if (!(length > 1e-8)) throw Error("The two actual quartz homes have no horizontal separation");
    const side = [dx / length, 0, dz / length];
    const point = (distance, height) => home.map((v, i) =>
      v + side[i] * distance * R + (i === 1 ? height * R : 0));
    const stages = [
      { to: start.map((v, i) => v + (i === 1 ? 0.8 * R : 0)), steps: 12, dt: 1 / 30 },
      { to: point(1.1, 0.9), steps: 12, dt: 1 / 30 },
      { to: point(0.35, 0.35), steps: 4, dt: 1 / 60 },
    ];
    const receipt = window.__quartzProjectile;
    receipt.phase = "staging";
    receipt.launch = { status: "unvalidated fixed geometry", R, home, fromHome, start, side, stages,
      targetBefore: { pos: target.pos.slice(), pinned: !!target.pinned,
        broken: h.joints.joint(target).broken } };
    if (h.hold) throw Error("Original quartz release still has an active hold before the extra launch");
    // Only public HandsOn input methods and native Player updates modify bodies.
    const screen = player.screenPoint(start);
    h.pressAt(player.fromRecipe(start), ...screen);
    player.update(1 / 30);
    let from = start;
    for (const stage of stages) {
      for (let i = 1; i <= stage.steps; i++) {
        const p = from.map((v, axis) => v + (stage.to[axis] - v) * i / stage.steps);
        h.moveTo(...player.screenPoint(p));
        player.update(stage.dt);
      }
      from = stage.to;
    }
    const held = h.hold;
    receipt.launch.beforeRelease = { heldId: held?.body?.id, place: held?.place,
      ctl: held?.ctl?.name, body: { pos: projectile.pos.slice(), vel: projectile.vel.slice(),
        held: !!projectile.held, broken: h.joints.joint(projectile).broken },
      nativeThrowEstimate: held?.body === projectile ? h.throwSpeed(held) : null };
    if (held?.body !== projectile || held.place || held.ctl)
      throw Error("Unvalidated launch did not retain native free-flight hold of actual quartz piece1");
    h.release();
    receipt.phase = "released";
    receipt.launch.afterRelease = { pos: projectile.pos.slice(), vel: projectile.vel.slice(),
      held: !!projectile.held, targetPinned: !!target.pinned };
    return receipt.launch;
  });
}

async function requireNativeCollision(page) {
  const evidence = await page.evaluate(() => window.__quartzProjectile);
  console.log("QUARTZ_PROJECTILE " + JSON.stringify(evidence));
  expect(evidence.hits.filter((hit) => hit.qualifying),
    "The fixed launch must produce a real unheld piece1→intact pinned piece0 impact above2.5 radii/s").not.toHaveLength(0);
}

test.afterEach(async ({ page, guardMode }, info) => {
  const evidence = await page.evaluate(() => window.__quartzProjectile || null);
  console.log("QUARTZ_PROJECTILE_FINAL " + JSON.stringify({ guardMode, status: info.status, evidence }));
  await info.attach("native-quartz-projectile", {
    body: JSON.stringify({ guardMode, status: info.status, evidence }, null, 2),
    contentType: "application/json",
  });
});

const APP = "/?renderer=webgl2&adapt=off&profile=mid";

// Phone size, where the owner plays (and the clips are made).
test.use({ viewport: { width: 390, height: 844 } });

async function ready(page, id) {
  await page.goto(APP);
  await page.waitForSelector("body[data-ready='true']", { timeout: 180_000 });
  await page.evaluate(async (id) => {
    const { app, player } = window.__splashery;
    await app.chooseToy(id);
    player.opts.idleDelay = 1e9;
    if (player.camera) {
      player.camera.turntable = false;
      player.camera.idleDelay = 1e9;
    }
  }, id);
  await page.waitForTimeout(800);
  if (!(await page.evaluate(() => window.__splashery.player.handsOn.on)))
    await page.click("#hands-toggle");
  await page.evaluate(() => window.__splashery.player.handsOn.ensure());
}

const tick = (page, secs) =>
  page.evaluate(
    (n) => {
      const { player } = window.__splashery;
      for (let i = 0; i < n; i++) player.update(1 / 60);
    },
    Math.round(secs * 60),
  );

// A finger on Hands-on itself, through recipe points: a press at the first
// (as the app's own press does, with the world point under it), then moves
// along the rest, a 30th of a second each step; `up` lets go at the end.
async function finger(page, points, { steps = 10, up = true } = {}) {
  await page.evaluate(
    ([pts, steps, up]) => {
      const { player } = window.__splashery;
      const ho = player.handsOn;
      const sp = (p) => player.screenPoint(p);
      ho.pressAt(player.fromRecipe(pts[0]), ...sp(pts[0]));
      player.update(1 / 30);
      for (let k = 1; k < pts.length; k++)
        for (let i = 1; i <= steps; i++) {
          const p = pts[k - 1].map((v, j) => v + ((pts[k][j] - v) * i) / steps);
          ho.moveTo(...sp(p));
          player.update(1 / 30);
        }
      if (up) ho.release();
    },
    [points, steps, up],
  );
}

const letGo = (page) => page.evaluate(() => window.__splashery.player.handsOn.release());

const joint = (page, n) => page.evaluate((n) => window.__splashery.player.handsOn.joints.state().find((j) => j.name === n).v, n); // prettier-ignore
const parts = (page) => page.evaluate(() => JSON.parse(JSON.stringify(window.__splashery.player.motion.out.parts))); // prettier-ignore
const piece = (page, i = 0) =>
  page.evaluate((i) => {
    const pc = window.__splashery.player.handsOn.pieces[i];
    return { pos: pc.body.pos.slice(), home: pc.home.pos.slice(), pinned: !!pc.body.pinned };
  }, i);
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);


for (const mode of ["before", "after"]) {
  test.describe(mode, () => {
    test.use({ guardMode: mode });
test("quartz cluster: a big point snaps off the rock, rests, and clicks back into its place", async ({
  page,
}) => {
  await ready(page, "quartz-cluster");
  await observeNativeCollisions(page);
  const x = await page.evaluate(() => window.__splashery.player.proc.ctx.kit.data.xtals[0]);
  const state = () => page.evaluate(() => window.__splashery.player.handsOn.joints.state()[0]);
  const tip = x.mid.map((v, i) => v + (i === 1 ? x.half[1] * 0.6 : 0));
  await finger(page, [tip, [tip[0] + 0.3, tip[1] + 0.4, tip[2] + 0.3], [1.3, 0.3, 0.5]], { up: false }); // prettier-ignore
  await tick(page, 0.3);
  await letGo(page);
  await tick(page, 1.5);
  const off = await state();
  expect(off.broken).toBe(true);
  expect(Math.hypot(...off.pos.map((v, i) => v - off.home[i]))).toBeGreaterThan(0.4);
  // The others stay on the rock.
  const others = await page.evaluate(() => window.__splashery.player.handsOn.joints.state().slice(1).map((j) => j.broken)); // prettier-ignore
  expect(others.every((b) => !b)).toBe(true);
  await finger(page, [off.pos, [0.5, 1.2, 0.3], x.mid.map((v, i) => v + (i === 1 ? 0.05 : 0))], { up: false }); // prettier-ignore
  await tick(page, 0.6);
  await letGo(page);
  // Controlled additional interaction, NOT an original-script reproduction.
  await launchExistingPieceOne(page);
  await tick(page, 1.5);
  await requireNativeCollision(page);
  const back = await state();
  expect(back.broken).toBe(false);
  expect(Math.hypot(...back.pos.map((v, i) => v - back.home[i]))).toBeLessThan(0.01);
});

  });
}
