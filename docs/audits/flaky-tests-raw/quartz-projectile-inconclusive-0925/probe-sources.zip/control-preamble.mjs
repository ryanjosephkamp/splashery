import { test as base, expect } from "@playwright/test";
import fs from "node:fs";

const beforeSource = fs.readFileSync(new URL("./hands-on-before.js", import.meta.url), "utf8");
const test = base.extend({
  guardMode: ["before", { option: true }],
  page: async ({ page, guardMode }, use) => {
    if (guardMode === "before")
      await page.route("**/src/physics/hands-on.js", (route) => route.fulfill({
        status: 200, contentType: "text/javascript", body: beforeSource,
      }));
    // After uses the actual current site module, not an emulated replacement.
    await use(page);
  },
});

async function observeNativeCollisions(page) {
  await page.evaluate(() => {
    const h = window.__splashery.player.handsOn;
    const [target, projectile] = h.pieces.map((piece) => piece.body);
    const nativeHits = new WeakSet();
    const take = h.world.takeHits;
    h.world.takeHits = function (...args) {
      const hits = take.apply(this, args);
      for (const hit of hits) nativeHits.add(hit);
      return hits;
    };
    const snapshot = () => {
      const joint = h.joints.joint(target);
      return { id: target.id, pinned: !!target.pinned, held: !!target.held,
        broken: joint.broken, pos: target.pos.slice(), home: joint.pc.home.pos.slice(),
        jointTime: h.joints.time, simTime: h.simTime };
    };
    window.__quartzProjectile = { phase: "original", target: target.id,
      projectile: projectile.id, hits: [], initial: snapshot() };
    const native = h.onHit;
    h.onHit = function (hit) {
      const a = hit.body, b = hit.other;
      const row = { phase: window.__quartzProjectile.phase, nativeWorldHit: nativeHits.has(hit),
        body: a?.id, other: b?.id, speed: hit.speed / this.R(),
        bodyHeld: !!a?.held, otherHeld: !!b?.held, before: snapshot() };
      const pair = (a === target && b === projectile) || (a === projectile && b === target);
      row.qualifying = row.nativeWorldHit && row.phase === "released" && pair && row.speed > 2.5 &&
        !row.bodyHeld && !row.otherHeld && row.before.pinned && !row.before.broken;
      try {
        return native.call(this, hit);
      } finally {
        row.after = snapshot();
        if (a === target || b === target || a === projectile || b === projectile)
          window.__quartzProjectile.hits.push(row);
      }
    };
  });
}

// UNEXECUTED GEOMETRY SCAFFOLD. This is one predeclared attempt, not an
// adaptive search or a known successful launch. It adds a second real-user
// interaction after the complete original return gesture. Recipe, bodies,
// native collision dispatch, and original final assertions stay unchanged.
async function launchExistingPieceOne(page) {
  return page.evaluate(() => {
    const { player } = window.__splashery;
    const h = player.handsOn;
    const [target, projectile] = h.pieces.map((piece) => piece.body);
    const home = h.pieces[0].home.pos.slice();
    const fromHome = h.pieces[1].home.pos.slice();
    const start = projectile.pos.slice();
    const R = h.R();
    const dx = fromHome[0] - home[0], dz = fromHome[2] - home[2];
    const length = Math.hypot(dx, dz);
    if (!(length > 1e-8)) throw Error("The two actual quartz homes have no horizontal separation");
    const side = [dx / length, 0, dz / length];
    const point = (distance, height) => home.map((v, i) =>
      v + side[i] * distance * R + (i === 1 ? height * R : 0));
    const stages = [
      { to: start.map((v, i) => v + (i === 1 ? 0.8 * R : 0)), steps: 12, dt: 1 / 30 },
      { to: point(1.1, 0.9), steps: 12, dt: 1 / 30 },
      { to: point(0.35, 0.35), steps: 4, dt: 1 / 60 },
    ];
    const receipt = window.__quartzProjectile;
    receipt.phase = "staging";
    receipt.launch = { status: "unvalidated fixed geometry", R, home, fromHome, start, side, stages,
      targetBefore: { pos: target.pos.slice(), pinned: !!target.pinned,
        broken: h.joints.joint(target).broken } };
    if (h.hold) throw Error("Original quartz release still has an active hold before the extra launch");
    // Only public HandsOn input methods and native Player updates modify bodies.
    const screen = player.screenPoint(start);
    h.pressAt(player.fromRecipe(start), ...screen);
    player.update(1 / 30);
    let from = start;
    for (const stage of stages) {
      for (let i = 1; i <= stage.steps; i++) {
        const p = from.map((v, axis) => v + (stage.to[axis] - v) * i / stage.steps);
        h.moveTo(...player.screenPoint(p));
        player.update(stage.dt);
      }
      from = stage.to;
    }
    const held = h.hold;
    receipt.launch.beforeRelease = { heldId: held?.body?.id, place: held?.place,
      ctl: held?.ctl?.name, body: { pos: projectile.pos.slice(), vel: projectile.vel.slice(),
        held: !!projectile.held, broken: h.joints.joint(projectile).broken },
      nativeThrowEstimate: held?.body === projectile ? h.throwSpeed(held) : null };
    if (held?.body !== projectile || held.place || held.ctl)
      throw Error("Unvalidated launch did not retain native free-flight hold of actual quartz piece1");
    h.release();
    receipt.phase = "released";
    receipt.launch.afterRelease = { pos: projectile.pos.slice(), vel: projectile.vel.slice(),
      held: !!projectile.held, targetPinned: !!target.pinned };
    return receipt.launch;
  });
}

async function requireNativeCollision(page) {
  const evidence = await page.evaluate(() => window.__quartzProjectile);
  console.log("QUARTZ_PROJECTILE " + JSON.stringify(evidence));
  expect(evidence.hits.filter((hit) => hit.qualifying),
    "The fixed launch must produce a real unheld piece1→intact pinned piece0 impact above2.5 radii/s").not.toHaveLength(0);
}

test.afterEach(async ({ page, guardMode }, info) => {
  const evidence = await page.evaluate(() => window.__quartzProjectile || null);
  console.log("QUARTZ_PROJECTILE_FINAL " + JSON.stringify({ guardMode, status: info.status, evidence }));
  await info.attach("native-quartz-projectile", {
    body: JSON.stringify({ guardMode, status: info.status, evidence }, null, 2),
    contentType: "application/json",
  });
});
