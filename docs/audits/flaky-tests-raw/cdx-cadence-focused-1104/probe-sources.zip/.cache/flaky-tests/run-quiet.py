import sys,os,json,hashlib,subprocess,pathlib,datetime,signal
root=pathlib.Path('/workspace/splashery');os.chdir(root)
family=sys.argv[1];port=sys.argv[2];args=sys.argv[3:]
folder=root/'.cache/flaky-tests'/family
out=folder/('run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S'))
out.mkdir()
env=os.environ.copy();env.update(PATH=str(root/'.cache/runtime/node-v22.20.0-linux-x64/bin')+':'+env['PATH'],PLAYWRIGHT_NODEJS_PATH=str(root/'.cache/runtime/node-v22.20.0-linux-x64/bin/node'),SPLASHERY_CHROMIUM=str(root/'.cache/runtime/chrome-linux/chrome'),SPLASHERY_GL='llvmpipe',DISPLAY=':91',SPLASHERY_PORT=port,PLAYWRIGHT_JSON_OUTPUT_FILE=str(out/'report.json'))
cmd=[str(root/'.cache/runtime/node-v22.20.0-linux-x64/bin/node'),'node_modules/@playwright/test/cli.js','test','--config',str(folder/'config.mjs'),'--reporter=list,json','--retries=0','--output',str(out/'results')]+args
meta=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),command=cmd,environment={k:env[k] for k in ['SPLASHERY_CHROMIUM','SPLASHERY_GL','DISPLAY','SPLASHERY_PORT','PLAYWRIGHT_NODEJS_PATH']},diff=subprocess.check_output(['git','diff','HEAD'],text=True),files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in list(folder.glob('*.mjs'))+list(folder.glob('*.js'))+[root/'.cache/flaky-tests/run-quiet.py',root/'.cache/flaky-tests/rendered-view.mjs']},burners=0,node=subprocess.check_output([cmd[0],'--version'],text=True).strip(),browser=subprocess.check_output([env['SPLASHERY_CHROMIUM'],'--version'],text=True).strip(),cpu=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip())
(out/'recipe.json').write_text(json.dumps(meta,indent=2)+'\n')
print(str(out),flush=True)
with (out/'burner.log').open('w') as bf,(out/'run.log').open('w') as log:
 result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
meta.update(ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=result.returncode)
(out/'recipe.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'exit':result.returncode,'output':str(out)}),flush=True)
sys.exit(result.returncode)
