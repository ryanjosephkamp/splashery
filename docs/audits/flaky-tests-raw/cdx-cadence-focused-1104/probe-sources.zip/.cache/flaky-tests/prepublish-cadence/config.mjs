import {defineConfig} from "@playwright/test";
import base from "../../../playwright.config.mjs";
export default defineConfig({...base,testDir:"/workspace/splashery",testMatch:[/^\/workspace\/splashery\/tests\/(cdx-mir|lv7)\.spec\.mjs$/,/^\/workspace\/splashery\/\.cache\/flaky-tests\/prepublish-cadence\/motion\.spec\.mjs$/],webServer:{...base.webServer,cwd:"/workspace/splashery"}});
