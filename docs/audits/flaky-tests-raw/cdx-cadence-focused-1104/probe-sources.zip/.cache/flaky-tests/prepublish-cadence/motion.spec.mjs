import {test,expect} from "@playwright/test";
import fs from "node:fs";import os from "node:os";import path from "node:path";
import config from "../../../playwright.config.mjs";
import {cameras} from "../../../tools/cdx-mir-camera.mjs";
import {fakeCamera,openMirror,measure} from "../../../tools/lv7-mirror-measure.mjs";
test("native real-motion control exceeds both unchanged still limits",async({playwright,baseURL})=>{
 test.setTimeout(600000);const dir=fs.mkdtempSync(path.join(os.tmpdir(),"splashery-real-motion-"));cameras(dir,20,["turn"]);
 const browser=await playwright.chromium.launch({...config.use.launchOptions,args:fakeCamera(path.join(dir,"turn.y4m"),config.use.launchOptions.args)});
 try{
  const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2});const errors=[];page.on("pageerror",e=>errors.push(e.message));
  await openMirror(page,baseURL+"/");const m=await measure(page,{answers:6});console.log("Real native turn control:",JSON.stringify(m));
  expect(m.heightJitter).toBeGreaterThan(.00055);expect(m.shownJitter).toBeGreaterThan(.95);
  expect(m.grid).toBe("423x317");expect(errors).toEqual([]);
 }finally{await browser.close();fs.rmSync(dir,{recursive:true,force:true});}
});
