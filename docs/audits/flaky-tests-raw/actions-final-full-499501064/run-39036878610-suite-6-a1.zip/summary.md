# Suite run

- 26 of 26 files, 256 tests: 255 passed, 1 failed, 0 skipped.
- Time in files (one after another): 48 min. Wall time of this run: 24 min (2 at once).

## Failed

- `cdx-a11y:196` keyboard focus can keep help open during its dismissal fade: failed. Error: expect(locator).toHaveAttribute(expected) failed

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| ui2 | 738 | 11 |
| kit | 549 | 10 |
| wdh | 339 | 9 |
| man4 | 183 | 34 |
| cdx-a11y | 161 | 12 |
| pot | 142 | 9 |
| mca | 133 | 20 |
| cdx-p3df | 113 | 10 |
| fx7 | 108 | 20 |
| hh3-level1 | 62 | 2 |
| vwr | 61 | 21 |
| fx4 | 60 | 4 |
| cdx-p3d2-text | 51 | 2 |
| snda | 42 | 6 |
| man7a | 33 | 16 |
| fx12-qr-circle-budget | 27 | 2 |
| cdx-p3d4-render-inputs | 25 | 1 |
| sci3-engine | 19 | 2 |
| cdx-p3d2-core | 13 | 4 |
| unit | 10 | 20 |
| st5 | 10 | 5 |
| cdx-v3d-real-clips | 7 | 9 |
| cdx-three-bounds | 5 | 9 |
| tw2-dna | 5 | 8 |
| cdx-v3d-decoded-frame | 4 | 6 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `kit:87` every kit toy has a recipe that builds deterministically and fits the unit ball | 537 |
| `ui2:156` phone › the sheet has five stops: hidden, row, grid, panel and full | 163 |
| `ui2:322` computer › the panel folds to an edge and comes back, and the gallery opens as a page | 156 |
| `cdx-p3df:302` two real inputs render at the phone profile, score truth, and generate a safe offline gall | 105 |
| `ui2:123` phone › focus mode hides the sheet and the top bar; the corner button and a swipe up bring | 88 |
| `ui2:419` computer › Shift-drag moves the toy within reach, Reset centers it, and a link keeps the m | 84 |
| `ui2:365` computer › the pad inks by distance, not by events, and the eraser clears | 67 |
| `wdh:249` worlds hybrid › frames per second, sampled in both modes | 57 |
| `wdh:135` worlds hybrid › splats hide behind the models' depth (splats mode): a bush behind a hill l | 57 |
| `wdh:271` worlds hybrid › screenshots at 390x844 and 1440x900 | 54 |
| `wdh:81` worlds hybrid › ?render= picks the mode; both modes load without errors and draw what they | 52 |
| `pot:163` Powers of ten in the app › the wheel zooms through the stops; the camera never moves | 50 |
| `wdh:135` worlds hybrid › splats hide behind the models' depth (hybrid mode): a bush behind a hill l | 48 |
| `ui2:300` computer › focus mode hides the panel and top bar, and Escape restores them | 47 |
| `hh3-level1:53` the book, the photo album and the one-sided captures stay out | 40 |
| `ui2:218` phone › the CNN opens its settings at the full stop, the pad fits whole, and it reads a dr | 39 |
| `pot:201` Powers of ten in the app › a tap plays the journey: out from the garden first | 38 |
| `mca:273` bombe mid-tap screenshots at 390x844 and 1440x900 | 37 |
| `cdx-a11y:196` keyboard focus can keep help open during its dismissal fade | 36 |
| `fx7:462` clothes take flag colors on their cloth | 33 |
| `vwr:358` the toys › screenshots | 32 |
| `ui2:266` phone › two fingers moving together move the toy; a pinch still zooms; Reset centers it | 31 |
| `mca:273` enigma-machine mid-tap screenshots at 390x844 and 1440x900 | 31 |
| `wdh:198` worlds hybrid › ?character=kenney swaps in a lit, skinned character: it casts shadows, sta | 30 |
| `wdh:198` worlds hybrid › ?character=mesh swaps in a lit, skinned character: it casts shadows, stand | 30 |
