# Suite run

- 25 of 25 files, 286 tests: 285 passed, 1 failed, 0 skipped.
- Time in files (one after another): 41 min. Wall time of this run: 20 min (2 at once).

## Failed

- `hh5-animals:182` pufferfish: puffs while held, any way up; deflates slowly once let go: failed. Error: expect(received).toBeGreaterThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| smoke | 922 | 62 |
| asc | 223 | 5 |
| help | 213 | 14 |
| sndc-engine | 182 | 6 |
| live-engine | 137 | 11 |
| hh5-animals | 136 | 11 |
| man6 | 123 | 18 |
| sci | 105 | 23 |
| hh3-holidays | 73 | 5 |
| hea | 69 | 6 |
| hh3-medieval | 54 | 3 |
| cdx-site-links | 44 | 49 |
| hh3-pictures | 39 | 2 |
| cdx-depth | 30 | 10 |
| live2-engine | 19 | 3 |
| cdx-v3d-bench-supplement | 16 | 9 |
| se1 | 13 | 5 |
| e4f | 10 | 5 |
| opm | 6 | 5 |
| qrs-study | 6 | 3 |
| cdx-p3d5-noise | 5 | 3 |
| cdx-v3d-training-error | 5 | 3 |
| cdx-p3d4-metrics | 4 | 3 |
| heb-engine | 4 | 17 |
| cdx-v3d-pause-view | 3 | 5 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `asc:273` the three presets capture, move and keep their credit; settings change the GIF | 175 |
| `sndc-engine:216` a quiet tap (its sound from cues) pauses and resumes its sound too | 66 |
| `smoke:249` Splashery app (WebGL2) › clay adds and erases blobs on a generated toy and survives a JSON | 54 |
| `help:261` the line stays clear of the toy at 1440x900 | 46 |
| `smoke:761` Splashery v3 engine (WebGL2) › rigs pick splats by colour, run effects and show add-ons; s | 43 |
| `help:261` the line stays clear of the toy at 390x844 | 40 |
| `smoke:1549` Splashery on a phone › dragging the shelf up opens a grid, and picking a toy folds it back | 37 |
| `smoke:1740` Splashery on WebGPU › auto picks WebGPU when an adapter exists and effects render | 37 |
| `smoke:367` Splashery app (WebGL2) › the embed page loads a scene from the hash | 35 |
| `smoke:618` Splashery v3 engine (WebGL2) › patterns and flags recolour any toy and travel in the link | 35 |
| `man6:250` R2-F09 and R2-F10: two demos' states › the windmill's readout says which selected lines tu | 34 |
| `live-engine:48` nothing is asked for or loaded before a tap | 33 |
| `smoke:1118` Settings panel (WebGL2) › the chess game bar plays, pauses, steps and jumps, and a tap aft | 31 |
| `help:102` toy help: the line › shows on a pick, fades, and '?' brings it back | 31 |
| `sci:460` in the browser › screenshots of smlm-microscope at phone and desktop size | 31 |
| `smoke:823` Splashery v3 engine (WebGL2) › the chess set plays the Opera Game, and the laptop types wh | 30 |
| `sndc-engine:109` a paused toy's sound comes back when another toy opens | 29 |
| `smoke:971` Splashery v3 engine (WebGL2) › v3 screenshots at 1440x900 and 390x844 | 28 |
| `smoke:1467` Splashery on a phone › has no horizontal overflow at 390px and the sheet opens | 27 |
| `live-engine:162` a live stream plays on a picture toy's sheets and Stop puts the sample back | 27 |
| `man6:119` R2-F04: the What Splashery can do page agrees with the manual › no stale claim, and the qu | 27 |
| `smoke:443` Splashery app (WebGL2) › bring-your-own PLY, SPLAT, SPZ and SOG files load in the browser | 27 |
| `sci:460` in the browser › screenshots of galaxy-box at phone and desktop size | 25 |
| `smoke:887` Splashery v3 engine (WebGL2) › a stretchy toy stretches when dragged and springs back; a d | 25 |
| `smoke:590` Splashery v3 engine (WebGL2) › toys move by themselves once motion is on, and any toy can  | 24 |
