# Suite run

- 26 of 26 files, 273 tests: 272 passed, 1 failed, 0 skipped.
- Time in files (one after another): 39 min. Wall time of this run: 23 min (2 at once).

## Failed

- `lv7:393` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new note at once and holds when it stops: failed. Error: expect(received).toBeLessThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| lv7 | 445 | 11 |
| fx4-engine | 389 | 8 |
| phy | 360 | 6 |
| cdx-t2 | 162 | 74 |
| live2 | 120 | 11 |
| hec | 119 | 9 |
| psv | 114 | 8 |
| mol | 84 | 27 |
| phy-engine | 78 | 8 |
| stm | 76 | 20 |
| lat | 63 | 13 |
| cdx-v3d-samples | 57 | 5 |
| e5 | 53 | 7 |
| live3-engine | 49 | 4 |
| cdx-v3d-render-engine | 49 | 6 |
| cdx-p3d4-render-hold | 29 | 3 |
| sci-engine | 25 | 2 |
| man7b | 14 | 24 |
| scr-engine | 11 | 1 |
| cdx-p3d2-r3-compact | 8 | 4 |
| bld | 5 | 7 |
| pr2 | 4 | 4 |
| cdx-p3d5-study-state | 4 | 3 |
| cdx-v3d-uncapped-stage | 3 | 2 |
| cdx-v3d-deadline | 3 | 4 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `lv7:106` the mirror on a camera (a generated mannequin) › plain: steadier than before, frame to fra | 170 |
| `lv7:150` the mirror on a camera (a generated mannequin) › hologram: nothing drawn over the face, an | 145 |
| `phy:114` jelly and amoeba stretch and spring back; cherries swing and knock | 105 |
| `fx4-engine:88` gift-box: toys without the rim kind draw as before (webgpu) | 83 |
| `phy:159` the spring toy stretches and settles; the bow shoots; sushi picks the tapped piece | 79 |
| `fx4-engine:88` bouncy-ball: toys without the rim kind draw as before (webgpu) | 75 |
| `phy:93` bricks and macarons stack; a brick snaps onto the studs | 74 |
| `fx4-engine:88` beach-ball: toys without the rim kind draw as before (webgpu) | 73 |
| `mol:285` the toy › every sample builds in every style, inside the budget, with finite splats | 47 |
| `phy:218` screenshots: the Hands-on buttons on Pebbles at 390x844 | 44 |
| `hec:217` on its side or upside down, the soft parts hang toward the world's down and Reset still wo | 41 |
| `fx4-engine:88` gift-box: toys without the rim kind draw as before (webgl2) | 39 |
| `fx4-engine:88` beach-ball: toys without the rim kind draw as before (webgl2) | 37 |
| `fx4-engine:88` bouncy-ball: toys without the rim kind draw as before (webgl2) | 35 |
| `phy:218` screenshots: the Hands-on buttons on Pebbles at 1440x900 | 33 |
| `psv:70` Photo to 3D › Sharp picture shows the photo at full size on its relief, and back to the sp | 32 |
| `phy-engine:90` Hands-on is off on a scan: a drag turns the view; on, it picks the toy up | 32 |
| `lv7:520` screenshots at phone and desktop size: the landscape growing | 31 |
| `live3-engine:57` the Live pill never covers a control, on a phone or a desktop | 29 |
| `stm:366` the toy in the browser › a sample shows, a tap lifts and settles, opening your own models  | 29 |
| `stm:426` the toy in the browser › screenshots at phone and desktop size | 29 |
| `live2:207` in the browser › the click track: each click is at the now mark within 50 ms of when it is | 27 |
| `lv7:393` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new  | 27 |
| `cdx-v3d-samples:113` each selected sample loads in the browser without fetching the trainer | 26 |
| `hec:275` the soft parts' step time stays small with each demo toy in play | 26 |
