# Suite run

- 25 of 25 files, 241 tests: 240 passed, 1 failed, 0 skipped.
- Time in files (one after another): 45 min. Wall time of this run: 24 min (2 at once).

## Failed

- `chs-engine:11` a tap that returns options rebuilds the toy with them, then fires its key: failed. Error: expect(received).toBeGreaterThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-mir | 511 | 11 |
| qr5 | 495 | 5 |
| pages-r2-occlusion | 396 | 6 |
| st4 | 189 | 22 |
| ro | 154 | 4 |
| cmp2-shots | 144 | 5 |
| math | 142 | 22 |
| ai | 103 | 47 |
| cdx-playtest-manual | 83 | 2 |
| pg6-engine | 67 | 8 |
| fix3 | 61 | 4 |
| cdx-circle-lab | 55 | 6 |
| fx6 | 53 | 4 |
| cdx-keys | 45 | 7 |
| ln | 44 | 19 |
| evidence-computing | 37 | 25 |
| hh3-sort | 35 | 2 |
| cdx-v3d-solve-retry | 18 | 4 |
| cdx-v3d-clarity-register | 18 | 2 |
| pdf-engine | 13 | 2 |
| chem | 10 | 24 |
| chs-engine | 10 | 1 |
| cdx-p3d4-weight-release | 6 | 3 |
| cdx-v3d-background-fit-gpu | 5 | 1 |
| cdx-v3d-heldout-selection | 4 | 5 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `qr5:159` the Damage lab: tapped damage lands where the tap says | 314 |
| `cdx-mir:331` matched camera frames keep real feature contrast and improve held-pose stability | 277 |
| `pages-r2-occlusion:155` all bindings and album covers keep full turns inside the sortable volume (webgpu) | 201 |
| `cdx-mir:294` real depth worker with a fake camera › low-light: measured drift stays below the baseline | 144 |
| `qr5:95` Picture QR: the ripple keeps every module's picture colors | 106 |
| `ro:118` Real objects › each toy opens and plays its tap in the app, with screenshots | 103 |
| `pages-r2-occlusion:155` all bindings and album covers keep full turns inside the sortable volume (webgl2) | 84 |
| `cdx-mir:294` real depth worker with a fake camera › still: measured drift stays below the baseline | 76 |
| `st4:554` screenshots › the 404 page (live today) and the staged front door, at phone and desktop si | 68 |
| `qr5:206` three codes in one: each code reads pulled apart, in the colors picked | 67 |
| `cdx-playtest-manual:6` all 108 printed contents numbers share one right edge | 67 |
| `cmp2-shots:35` enigma-barbarossa: mid-tap screenshots at 390x844 and 1440x900 | 48 |
| `pages-r2-occlusion:6` photo-album: the turning cover occludes its pages (webgpu) | 46 |
| `pages-r2-occlusion:6` your-book: the turning cover occludes its pages (webgpu) | 33 |
| `hh3-sort:65` the patterned egg, turned by hand and sorted again, shows no hole at 8 angles | 30 |
| `ai:191` neural-network mid-tap screenshots at 390x844 and 1440x900 | 29 |
| `ro:70` Real objects › taps move the model's pieces as solid parts and end at rest | 27 |
| `ai:191` transformer mid-tap screenshots at 390x844 and 1440x900 | 27 |
| `ai:191` diffusion-model mid-tap screenshots at 390x844 and 1440x900 | 26 |
| `st4:465` the staged service worker › a new deploy replaces the old shell at once, and never mixes o | 26 |
| `cmp2-shots:35` sorting-ring: mid-tap screenshots at 390x844 and 1440x900 | 26 |
| `cmp2-shots:35` sorting-crates: mid-tap screenshots at 390x844 and 1440x900 | 26 |
| `cmp2-shots:35` sorting-dots: mid-tap screenshots at 390x844 and 1440x900 | 25 |
| `st4:266` the staged front door › in the browser › old shared links and options open the Playground  | 24 |
| `fix3:92` banana mid-tap screenshots at 390x844 and 1440x900 | 21 |
