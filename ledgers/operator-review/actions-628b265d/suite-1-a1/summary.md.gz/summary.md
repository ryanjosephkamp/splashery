# Suite run

- 13 of 13 files, 119 tests: 119 passed, 0 failed, 0 skipped.
- Time in files (one after another): 33 min. Wall time of this run: 27 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-pics | 1628 | 51 |
| lv8 | 67 | 7 |
| man | 59 | 12 |
| pot-engine | 56 | 4 |
| cdx-v3d-render-engine | 45 | 6 |
| chs | 43 | 10 |
| cdx-v3d-review | 22 | 5 |
| mol-engine | 17 | 3 |
| hh3-level1-engine | 11 | 2 |
| st3 | 7 | 8 |
| klab | 7 | 6 |
| pr2 | 5 | 4 |
| cdx-p3d2-r3-background | 3 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-pics:65` every new Studio sample loads and raises into 3D; other new assets stay lazy | 95 |
| `cdx-pics:119` Split leaf: five-link browser scans, credits, and lazy loading | 81 |
| `cdx-pics:119` Fern frond: five-link browser scans, credits, and lazy loading | 61 |
| `cdx-pics:119` Clay teapot: five-link browser scans, credits, and lazy loading | 57 |
| `cdx-pics:119` Clay pitcher: five-link browser scans, credits, and lazy loading | 57 |
| `cdx-pics:119` Lotus bloom: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Wooden stacking rings: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Autumn squash: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Wooden blocks: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Green watering can: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Mushroom: five-link browser scans, credits, and lazy loading | 56 |
| `cdx-pics:119` Pinecone: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Ginkgo leaf: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Pumpkin: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Pear: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Paper rainbow: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Balloon: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Tulip: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Blue vase: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Wooden rook: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Scallop shell: five-link browser scans, credits, and lazy loading | 55 |
| `cdx-pics:119` Potted cactus: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Smooth pebbles: five-link browser scans, credits, and lazy loading | 54 |
| `cdx-pics:119` Stacked stones: five-link browser scans, credits, and lazy loading | 53 |
| `cdx-pics:119` Wooden spinning top: five-link browser scans, credits, and lazy loading | 53 |
