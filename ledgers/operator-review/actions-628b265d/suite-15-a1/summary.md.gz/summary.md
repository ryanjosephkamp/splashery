# Suite run

- 22 of 22 files, 255 tests: 255 passed, 0 failed, 0 skipped.
- Time in files (one after another): 36 min. Wall time of this run: 19 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| img-engine | 520 | 4 |
| geo | 361 | 16 |
| p3d-golden | 172 | 77 |
| f | 170 | 8 |
| scr | 144 | 6 |
| an | 132 | 7 |
| shv | 112 | 15 |
| ops-text | 101 | 4 |
| p3d | 94 | 10 |
| arc2 | 70 | 7 |
| sndb | 57 | 9 |
| hea-engine | 53 | 20 |
| hh3-sort | 39 | 2 |
| cdx-site-links | 34 | 49 |
| hh3-music | 30 | 2 |
| cdx-p3d2-core | 14 | 4 |
| scr2-engine | 13 | 1 |
| cmp2-sort | 9 | 6 |
| scr-engine | 9 | 1 |
| qrs-study | 7 | 3 |
| cdx-p3d4-edge-cache | 3 | 1 |
| cdx-p3d5-index-cache | 3 | 3 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `img-engine:85` toys without the volume kind draw as before (webgpu) | 208 |
| `img-engine:85` toys without the volume kind draw as before (webgl2) | 164 |
| `scr:165` lane Screens screenshots at 390x844 and 1440x900 | 95 |
| `img-engine:122` a volume is cut by its plane and shown by its density window (webgl2) | 77 |
| `f:302` Touch and drag (WebGL2) › lane F screenshots at 1440x900 and 390x844 | 73 |
| `img-engine:122` a volume is cut by its plane and shown by its density window (webgpu) | 64 |
| `an:42` the anatomy atlas › each layer builds, with every piece solid and in its own layer | 47 |
| `ops-text:182` a PDF's words in the Toy tab › screenshots of your book with its words open, at 390x844 an | 46 |
| `geo:243` Earth and maps › screenshots of earthquakes at phone and desktop size | 42 |
| `geo:243` Earth and maps › screenshots of living-city at phone and desktop size | 40 |
| `p3d:132` the conversion › each sample builds within every tier's budget, with finite numbers | 37 |
| `geo:60` Earth and maps › each toy builds with finite splats, and its tap's control rests at 0 | 36 |
| `sndb:123` toys that cue their own sounds play the new ones, with no errors | 34 |
| `geo:243` Earth and maps › screenshots of sea-floor at phone and desktop size | 34 |
| `hh3-sort:65` the patterned egg, turned by hand and sorted again, shows no hole at 8 angles | 34 |
| `an:177` the anatomy atlas › screenshots at phone and desktop size | 32 |
| `f:72` Touch and drag (WebGL2) › the puzzle cube turns a layer under a swipe, scrambles and solve | 31 |
| `geo:243` Earth and maps › screenshots of grand-canyon at phone and desktop size | 30 |
| `geo:243` Earth and maps › screenshots of tide-harbor at phone and desktop size | 29 |
| `geo:243` Earth and maps › screenshots of stork-migration at phone and desktop size | 28 |
| `ops-text:41` a PDF's words in the Toy tab › your book: the words of the page on show, following the pag | 28 |
| `scr:124` the Screen switches on with a tap, plays its video, and pauses and plays again | 27 |
| `geo:243` Earth and maps › screenshots of st-helens at phone and desktop size | 27 |
| `p3d:159` in the browser › nothing loads the depth model until a photo is opened; then it builds and | 26 |
| `geo:243` Earth and maps › screenshots of hurricane at phone and desktop size | 25 |
