# Suite run

- 21 of 21 files, 137 tests: 137 passed, 0 failed, 0 skipped.
- Time in files (one after another): 40 min. Wall time of this run: 20 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| scr2 | 717 | 6 |
| live | 286 | 13 |
| live3 | 174 | 11 |
| sndc-engine | 164 | 6 |
| fx6-2 | 153 | 8 |
| cdx-adv | 125 | 9 |
| cdx-pics-hard-cases | 117 | 3 |
| hh1-engine | 111 | 9 |
| cdx-pfc | 88 | 10 |
| qrc-picture | 77 | 5 |
| g | 67 | 9 |
| qr4-flash | 63 | 2 |
| smd-models | 57 | 9 |
| spg | 52 | 9 |
| fx13 | 39 | 3 |
| tp2-engine | 28 | 2 |
| cdx-p3d4-scene-swap | 25 | 1 |
| st5 | 14 | 5 |
| tpg-engine | 12 | 1 |
| cdx-p3d2-r3-depth | 5 | 7 |
| hh5-engine | 3 | 9 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `scr2:127` switched off (or the curtains closed), the screen looks the same whichever sample it holds | 312 |
| `scr2:270` lane Screens r2 screenshots at 390x844 and 1440x900 | 214 |
| `cdx-pics-hard-cases:68` every hard-case choice loads its own files and changes from flat to raised in Chromium | 108 |
| `scr2:224` the flat TV's button, the cinema's curtains and the hologram's base switch them off | 84 |
| `sndc-engine:191` a quiet tap (its sound from cues) pauses and resumes its sound too | 60 |
| `qr4-flash:12` the QR family's scan checks never show on screen | 51 |
| `live:130` before a tap › no toy asks for a device or loads the depth model until its button is tappe | 50 |
| `scr2:163` a GIF holds its frame while the set is off, and plays on when it comes back on | 41 |
| `scr2:195` a tap on the old TV's power knob switches it off; a tap on the picture plays and pauses | 40 |
| `live3:439` the splat mirror, r3 › a big Start camera over the picture, the back camera, a recording t | 40 |
| `qrc-picture:119` Picture QR in the browser: the splats read back, the PNG reads back, and a tap ends on a c | 38 |
| `fx6-2:43` Enigma: a tapped key types its letter in code, and a keyboard types too | 38 |
| `live3:373` the splat mirror, r3 › the still picture holds still face on: nudging the view a hair does | 38 |
| `fx6-2:135` Enigma screenshots at 390x844 and 1440x900, typed on | 37 |
| `cdx-pfc:164` all forms fly, the QR encoder loads on demand, and the rendered QR scans at 1440x900 | 36 |
| `live:240` the camera › a shared screen plays on the Screen toy, which switches itself on | 35 |
| `fx13:193` Pop out with Pop-up layers on (in the app) › the Picture lab's chart rises with Pop-up lay | 33 |
| `fx6-2:191` periodic table: a tap on the empty board tours the elements by number, with no overlay; a  | 31 |
| `smd-models:65` the sample models › the toy shows each one | 28 |
| `live:222` the camera › Photo to 3D's live view takes the picture as a photo in 3D | 28 |
| `fx6-2:216` periodic table: the tour's shuffled order | 28 |
| `g:63` tin-can-real mid-tap screenshots at 390x844 and 1440x900 | 28 |
| `sndc-engine:109` a paused toy's sound comes back when another toy opens | 27 |
| `live:190` the camera › the mirror shows the camera in depth; Stop ends every track and puts the stil | 27 |
| `live:411` the new toys' screenshots on a computer | 26 |
