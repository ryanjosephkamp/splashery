# Suite run

- 21 of 21 files, 119 tests: 119 passed, 0 failed, 0 skipped.
- Time in files (one after another): 33 min. Wall time of this run: 18 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wdr3 | 446 | 7 |
| pg6 | 304 | 16 |
| hl1 | 146 | 2 |
| dsm-samples | 137 | 6 |
| heb | 127 | 6 |
| cdx-adv-files | 120 | 10 |
| smd-compare | 112 | 3 |
| hh1-balls | 104 | 5 |
| lab-engine | 96 | 7 |
| hh3-holidays | 75 | 5 |
| cdx-pfd | 67 | 8 |
| sts | 59 | 18 |
| bkd | 55 | 2 |
| pol | 49 | 6 |
| fx9 | 39 | 5 |
| live2-engine | 20 | 3 |
| cmp2-engine | 19 | 4 |
| cdx-p3d2-input | 15 | 1 |
| st4-engine | 9 | 2 |
| cdx-p3d2-r3-metrics | 4 | 2 |
| cdx-p3d4-soften | 4 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `wdr3:133` worlds r3 › idle, walk and run play, and the standing foot stays planted while it walks an | 195 |
| `pg6:567` Pop out (in the app) › Your book: two figures up at once, one laid back; the switch holds  | 158 |
| `hl1:92` Hands-on: lift, toss, land, settle and Reset | 139 |
| `dsm-samples:74` in the browser › every AI-made sample loads and builds with its picture | 124 |
| `wdr3:96` worlds r3 › the realistic character is hybrid mode's default and loads its level in each t | 101 |
| `wdr3:235` worlds r3 › screenshots at 390x844 and 1440x900 | 82 |
| `smd-compare:41` the original beside the 3D › Moving photo to 3D: the flat clip shows the frame the 3D one  | 82 |
| `pg6:646` Pop out (in the app) › a depth saved in a scene comes back when the figure is raised | 58 |
| `pg6:618` Pop out (in the app) › the Picture lab pops a PDF figure and a drawn box | 51 |
| `wdr3:217` worlds r3 › ?stats=1 shows frames per second, the tier, the mode, splats and draw calls | 42 |
| `hh1-balls:34` every ball: its own bounce, room to roll and a landing sound | 41 |
| `bkd:41` renders at 390×844 and 1440×900, and a tap swings the lid open and shut | 39 |
| `lab-engine:119` the sharp kernel compiles and draws on WebGPU too | 32 |
| `heb:122` sword in the stone: stuck, then drawn out along its line; stays; clanks back in | 32 |
| `cdx-pfd:205` real GPU renders all five actions and a screenshot at 1440×900 | 29 |
| `pg6:681` Pop out (in the app) › old links and saved scenes (v2 and v3) still load; one with Pop out | 27 |
| `lab-engine:85` with labs, ?kernel=sharp draws a different, finite picture, and back again | 23 |
| `hh1-balls:160` upright, on its side and upside down: the football, puck and shuttlecock keep their materi | 23 |
| `heb:65` chest: the lid lifts on its hinge, drops shut from low, stays open from high | 21 |
| `heb:213` tomatoes: each tomato picks up on its own and sets down on the plate | 20 |
| `fx9:83` the Fluid lab warns a phone that can't keep up, and offers a lighter mode | 20 |
| `wdr3:189` worlds r3 › the model props switch levels of detail by distance, and scattered stones and  | 20 |
| `heb:95` music box: the crank turns round and round, plays the tune and turns the dancer | 19 |
| `heb:156` orange: a wedge pulled out stays out; brought back, it clicks home | 18 |
| `cdx-adv-files:186` photo-3d: v2 and v3 scene files and old links retain their loading behavior | 16 |
