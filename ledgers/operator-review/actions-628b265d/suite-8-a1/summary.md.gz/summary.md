# Suite run

- 23 of 23 files, 194 tests: 194 passed, 0 failed, 0 skipped.
- Time in files (one after another): 34 min. Wall time of this run: 21 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-mp2-r4 | 491 | 13 |
| pose | 254 | 3 |
| hh2-food | 252 | 9 |
| sp3 | 162 | 9 |
| vw | 139 | 15 |
| cdx-circle-qr | 130 | 14 |
| hh5-animals | 124 | 11 |
| arc-engine | 74 | 7 |
| hea | 69 | 6 |
| vwr | 68 | 21 |
| hh5-body | 58 | 4 |
| hh4-engine | 57 | 6 |
| snda | 47 | 6 |
| evidence-computing | 40 | 25 |
| asc2 | 29 | 5 |
| cdx-renderer-diag | 24 | 18 |
| cdx-v3d-clarity | 15 | 8 |
| fid | 8 | 5 |
| asc-engine | 7 | 1 |
| cdx-p3d5-frozen-probes | 6 | 1 |
| cdx-p3d4-depth-loading | 4 | 1 |
| sndd | 4 | 4 |
| cdx-v3d-handoff | 3 | 2 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-mp2-r4:141` phone clip switches › every ordered sample pair binds the chosen clip's actual picture | 263 |
| `pose:39` the toys fixed in their recipes play the same on their side and upside down | 141 |
| `pose:16` a sample of toys: the tap plays the same on its side and upside down | 85 |
| `cdx-mp2-r4:85` phone clip switches › MP4, WebM, MOV, GIF, and 60 fps uploads keep their own Sharp picture | 66 |
| `hh2-food:303` bananas: one pulled bends at its neck, then breaks off whole with its skin | 41 |
| `hh2-food:124` burger: the top bun lifts off and goes back on the stack, set level on top | 40 |
| `sp3:129` Space r3: the real worlds zoom in and name the place › a tap on real-earth at 27.988, 86.9 | 39 |
| `sp3:129` Space r3: the real worlds zoom in and name the place › a tap on real-moon at -43.3, -11.22 | 38 |
| `sp3:129` Space r3: the real worlds zoom in and name the place › a tap on real-earth at 48.857, 2.35 | 38 |
| `vwr:358` the toys › screenshots | 37 |
| `sp3:129` Space r3: the real worlds zoom in and name the place › a tap on real-mars at 18.65, -133.8 | 35 |
| `vw:70` whole PDF figures › every kind of embedded picture builds whole splats at every detail wid | 33 |
| `cdx-mp2-r4:207` phone clip playback › a still camera keeps drawing short and long clip pictures | 31 |
| `hh2-food:266` birthday cake: a candle pulled out goes out and lies down; pushed back, it is alight again | 31 |
| `hh2-food:201` kiwi: a half pulled out shows its face; put back face down first, it still clicks home | 29 |
| `hh2-food:331` coffee: a finger drawn round in the cup turns the coffee after it | 25 |
| `hh2-food:166` ice cream: the top scoop lifts off; the cone tipped spills the scoops | 25 |
| `asc2:93` a listed toy captures with its own credit, and the check scores the GIF it makes | 23 |
| `hh5-body:215` screenshots: the lungs, hands-on | 22 |
| `hh2-food:240` popcorn: the bucket tipped on its edge spills the loose kernels onto the table | 21 |
| `hh5-animals:385` screenshots: the owl, hands-on | 21 |
| `cdx-circle-qr:165` Circle QR keeps its shape and text in PNG, GIF, and scene recipe exports | 21 |
| `pose:57` screenshots: the grape lying on its side, peeling (390x844 and 1440x900) | 20 |
| `vw:318` flags per toy › a flag stays with its toy; the next toy shows its own look | 20 |
| `snda:132` the sound lint passes every changed toy (PACKS.md 7e) | 20 |
