# Suite run

- 21 of 21 files, 252 tests: 252 passed, 0 failed, 0 skipped.
- Time in files (one after another): 20 min. Wall time of this run: 13 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| bk | 323 | 36 |
| rel | 165 | 28 |
| cdx-mp2-mobile | 126 | 2 |
| sp2 | 87 | 26 |
| qr4-craft | 85 | 9 |
| sci | 72 | 23 |
| dcl | 45 | 18 |
| man6 | 43 | 18 |
| cdx-manual-pdf | 42 | 10 |
| fx6 | 38 | 4 |
| cdx-a11y-layout | 38 | 11 |
| fx6-engine | 34 | 4 |
| cdx-pfa | 27 | 8 |
| ui4-engine | 21 | 2 |
| sci-engine | 15 | 2 |
| sp4 | 13 | 9 |
| fx12-qr-circle-budget | 13 | 2 |
| hh3-crossbow | 10 | 1 |
| chem | 5 | 24 |
| bkd-format | 5 | 14 |
| cdx-p3d4-resample | 2 | 1 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `rel:321` the toy in the app › the lifted sample is solid from the side | 70 |
| `cdx-mp2-mobile:25` mobile › every sample shows its own texture when switched on a slowed Android profile | 59 |
| `cdx-mp2-mobile:25` desktop site › every sample shows its own texture when switched on a slowed Android profil | 59 |
| `rel:239` the samples › every lifted sample is solid from every direction | 53 |
| `bk:1157` your book, the album and the frame (in the app) › screenshots of the three toys at 1440x90 | 52 |
| `bk:1157` your book, the album and the frame (in the app) › screenshots of the three toys at 390x844 | 34 |
| `qr4-craft:260` Picture QR: the halftone › every sample reads in both styles with the nudge stepped up, an | 33 |
| `bk:1070` your book, the album and the frame (in the app) › a double-tap on a page glides the view t | 32 |
| `dcl:297` in the browser › screenshots at phone and desktop size | 31 |
| `sp2:446` lane Space r2: real worlds › nothing of the real worlds loads before one opens; each then  | 29 |
| `bk:789` your book, the album and the frame (in the app) › a 300-page PDF is as light as a 3-page o | 26 |
| `bk:961` your book, the album and the frame (in the app) › a pointer pulls a page over only when pu | 25 |
| `bk:1108` your book, the album and the frame (in the app) › a zoom out lets a page in view go, and R | 24 |
| `sp2:480` lane Space r2: real worlds › screenshots of real-mars at phone and desktop size | 23 |
| `sp2:480` lane Space r2: real worlds › screenshots of real-moon at phone and desktop size | 20 |
| `bk:890` your book, the album and the frame (in the app) › the frame swings and settles; the digita | 20 |
| `sci:460` in the browser › screenshots of smlm-microscope at phone and desktop size | 19 |
| `sci:460` in the browser › screenshots of thermal-ellipsoids at phone and desktop size | 18 |
| `qr4-craft:156` Other barcodes › raw legacy Circle builds retain main's splats without resolved option def | 16 |
| `sci:460` in the browser › screenshots of galaxy-box at phone and desktop size | 16 |
| `bk:878` your book, the album and the frame (in the app) › the album shows the sample photos mounte | 15 |
| `fx6:178` on a site that gzips the depth model, your own 24 MP photo opens and builds | 14 |
| `qr4-craft:273` Picture QR in the browser: the splats read back from the stage in both styles | 14 |
| `bk:835` your book, the album and the frame (in the app) › a turned page and the open cover are sor | 14 |
| `bk:1014` your book, the album and the frame (in the app) › the digital frame lists its photos in th | 13 |
