# Suite run

- 22 of 22 files, 233 tests: 233 passed, 0 failed, 0 skipped.
- Time in files (one after another): 46 min. Wall time of this run: 28 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-qr-themes | 1113 | 59 |
| qr | 456 | 12 |
| cdx-p3d2-render | 254 | 16 |
| fl | 195 | 14 |
| hh3-engine2 | 138 | 3 |
| cdx-mp2-r3 | 136 | 16 |
| tpg | 80 | 11 |
| arc | 62 | 13 |
| qrc-build | 54 | 2 |
| hh4-tiny | 51 | 6 |
| man9 | 48 | 20 |
| sci3 | 37 | 21 |
| sng | 36 | 6 |
| live5 | 27 | 5 |
| hh3-pictures | 27 | 2 |
| sts-engine | 16 | 2 |
| cdx-p3d2-r3-background-interior | 9 | 4 |
| cdx-mp2-cache | 9 | 5 |
| hec-engine | 5 | 12 |
| cdx-p3d5-fast-metrics | 5 | 1 |
| cdx-p3d4-depth-gather | 4 | 1 |
| cdx-p3d2-r3-footprint | 4 | 2 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `qr:275` Alive: every frame of each style's looping GIF scans | 201 |
| `cdx-qr-themes:111` Seasons: selected backgrounds scan in the browser and load only on selection | 172 |
| `cdx-qr-themes:111` Ocean: selected backgrounds scan in the browser and load only on selection | 132 |
| `cdx-qr-themes:111` Forest: selected backgrounds scan in the browser and load only on selection | 113 |
| `cdx-qr-themes:111` Patterns: selected backgrounds scan in the browser and load only on selection | 112 |
| `cdx-qr-themes:111` Celebrations: selected backgrounds scan in the browser and load only on selection | 111 |
| `cdx-qr-themes:111` Space-art: selected backgrounds scan in the browser and load only on selection | 110 |
| `qr:192` every style at its default settings scans at 1440x900 | 80 |
| `hh3-engine2:129` strings: a drag across the guitar's strings plucks each one, in turn | 69 |
| `qr:192` every style at its default settings scans at 390x844 | 52 |
| `qrc-build:48` QR from real things: every build ends on a code that reads, the person's own text too | 50 |
| `tpg:289` toy pages (browser) › screenshots: two toy pages at both sizes | 47 |
| `hh3-engine2:101` strike pieces: a held stick hits the others, and each hit names both | 47 |
| `fl:379` a tap on the faucet's handle pours | 46 |
| `qr:238` the GIF ends on the code held still, and its last frame scans | 41 |
| `fl:227` the GPU liquid keeps the CPU liquid's volume in a glass and stays stable | 33 |
| `cdx-p3d2-render:320` webgpu: filled Sharp and Splats draw, and their atlas clears for Moving photo | 32 |
| `fl:156` each scene builds within its tier's splat budget and draws its fluid | 29 |
| `cdx-p3d2-render:240` spiral-stairs splats: at least 80% fewer holes and tears at twenty degrees | 28 |
| `cdx-p3d2-render:240` dot-castle splats: at least 80% fewer holes and tears at twenty degrees | 26 |
| `cdx-p3d2-render:240` forest splats: at least 80% fewer holes and tears at twenty degrees | 24 |
| `cdx-p3d2-render:240` dot-castle sharp: at least 80% fewer holes and tears at twenty degrees | 23 |
| `cdx-p3d2-render:240` spiral-stairs sharp: at least 80% fewer holes and tears at twenty degrees | 22 |
| `fl:359` screenshots at phone and desktop size | 21 |
| `cdx-p3d2-render:240` forest sharp: at least 80% fewer holes and tears at twenty degrees | 19 |
