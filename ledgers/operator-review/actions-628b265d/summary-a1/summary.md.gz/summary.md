<!-- splashery-ci -->
## ❌ Test suite on GitHub Actions (`628b265`)

- 345 of 345 spec files, 3051 tests: 3049 passed, 1 failed, 1 skipped.
- 16 shards; the longest took 28 min; the whole run about 50 min so far. [The run](https://github.com/ryanjosephkamp/splashery/actions/runs/38957277226) has the reports and failure screenshots (kept 7 days).

### Failed

| Test | Alone | Error |
| --- | --- | --- |
| `phy:64` (known on main) Pebbles: stones pick up and stack into a new cairn; a careless one topples | **passed alone** | failed: Error: expect(received).toBeGreaterThan(expected) |

A failure that passed alone is likely a flake (a busy runner); it still counts. One that failed alone too is real.

<details><summary>Time per shard</summary>

| Shard | Files | Time |
| --- | ---: | ---: |
| 1/16 | 13 | 27 min |
| 2/16 | 21 | 13 min |
| 3/16 | 21 | 15 min |
| 4/16 | 21 | 20 min |
| 5/16 | 21 | 18 min |
| 6/16 | 23 | 25 min |
| 7/16 | 23 | 22 min |
| 8/16 | 23 | 21 min |
| 9/16 | 22 | 16 min |
| 10/16 | 22 | 28 min |
| 11/16 | 22 | 22 min |
| 12/16 | 22 | 27 min |
| 13/16 | 23 | 22 min |
| 14/16 | 23 | 20 min |
| 15/16 | 22 | 19 min |
| 16/16 | 23 | 13 min |

</details>

<details><summary>Slowest files</summary>

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-pics | 1628 | 51 |
| cdx-qr-themes | 1113 | 59 |
| smoke | 730 | 62 |
| scr2 | 717 | 6 |
| ui2 | 708 | 11 |
| cdx-mp2-r4-raster | 589 | 7 |
| cdx-mir | 576 | 11 |
| kit | 565 | 10 |
| shp | 563 | 8 |
| qrs-toys | 551 | 4 |
| img-engine | 520 | 4 |
| qr5 | 495 | 5 |
| cdx-mp2-r4 | 491 | 13 |
| lv7 | 483 | 11 |
| qr | 456 | 12 |
| wdr3 | 446 | 7 |
| psv3 | 419 | 20 |
| fx4-engine | 415 | 4 |
| phy | 399 | 6 |
| ui3 | 375 | 8 |

</details>
