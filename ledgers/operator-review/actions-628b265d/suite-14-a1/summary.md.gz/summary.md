# Suite run

- 23 of 23 files, 200 tests: 200 passed, 0 failed, 0 skipped.
- Time in files (one after another): 38 min. Wall time of this run: 20 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-mir | 576 | 11 |
| qr5 | 495 | 5 |
| mt2 | 180 | 19 |
| st4 | 178 | 22 |
| math | 143 | 22 |
| cmp2-shots | 142 | 5 |
| hh4-vehicles | 90 | 9 |
| cdx-playtest-small-fixes | 86 | 9 |
| sll | 61 | 16 |
| cdx-v3d | 54 | 19 |
| cdx-p3d2-text | 50 | 2 |
| hh3-medieval | 46 | 3 |
| cdx-keys | 45 | 7 |
| hh4-weather | 42 | 3 |
| qr4-scan | 41 | 2 |
| snda-engine | 24 | 5 |
| pose-engine | 13 | 5 |
| an-engine | 12 | 1 |
| shb-engine | 8 | 1 |
| pol-pages | 7 | 11 |
| cdx-p3d4-weight-release | 5 | 3 |
| cdx-mp2-pixels | 4 | 7 |
| heb-engine | 3 | 13 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `qr5:159` the Damage lab: tapped damage lands where the tap says | 316 |
| `cdx-mir:329` matched camera frames keep real feature contrast and improve held-pose stability | 274 |
| `cdx-mir:294` real depth worker with a fake camera › still: measured drift stays below the baseline | 146 |
| `cdx-mir:294` real depth worker with a fake camera › low-light: measured drift stays below the baseline | 141 |
| `qr5:95` Picture QR: the ripple keeps every module's picture colors | 102 |
| `qr5:206` three codes in one: each code reads pulled apart, in the colors picked | 69 |
| `st4:554` screenshots › the 404 page (live today) and the staged front door, at phone and desktop si | 64 |
| `cmp2-shots:35` enigma-barbarossa: mid-tap screenshots at 390x844 and 1440x900 | 47 |
| `cdx-playtest-small-fixes:171` a dense shared QR explains the low budget and gives steps that recover | 39 |
| `mt2:274` thomas-attractor mid-tap screenshots at 390x844 and 1440x900 | 26 |
| `cmp2-shots:35` sorting-dots: mid-tap screenshots at 390x844 and 1440x900 | 25 |
| `cdx-p3d2-text:10` flattened photo-textured splats retain sans-serif text fidelity | 25 |
| `mt2:274` twenty-four-cell mid-tap screenshots at 390x844 and 1440x900 | 25 |
| `mt2:274` rossler-attractor mid-tap screenshots at 390x844 and 1440x900 | 25 |
| `cmp2-shots:35` sorting-ring: mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `cmp2-shots:35` sorting-crates: mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `mt2:274` five-cell mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `mt2:274` aizawa-attractor mid-tap screenshots at 390x844 and 1440x900 | 24 |
| `st4:266` the staged front door › in the browser › old shared links and options open the Playground  | 23 |
| `mt2:274` sixteen-cell mid-tap screenshots at 390x844 and 1440x900 | 23 |
| `mt2:274` duoprism mid-tap screenshots at 390x844 and 1440x900 | 22 |
| `sll:341` in the page › Light lab: spectra, a prism and a grating rebuilt per lamp by a tap, and the | 21 |
| `cdx-p3d2-text:10` flattened photo-textured splats retain DejaVu Sans text fidelity | 21 |
| `qr4-scan:14` qr-code: the code is scanned behind a labeled still, then shown | 20 |
| `math:404` pythagoras-proof mid-tap screenshots at 390x844 and 1440x900 | 19 |
