# Suite run

- 23 of 23 files, 214 tests: 214 passed, 0 failed, 0 skipped.
- Time in files (one after another): 51 min. Wall time of this run: 25 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| ui2 | 708 | 11 |
| kit | 565 | 10 |
| wdh | 341 | 9 |
| man3-2 | 230 | 15 |
| man4 | 184 | 34 |
| psv | 149 | 8 |
| cdx-a11y | 145 | 12 |
| cdx-three-lines | 136 | 1 |
| cdx-p3df | 130 | 10 |
| pno-engine | 103 | 14 |
| cdx-circle-lab | 60 | 6 |
| opt | 59 | 21 |
| klab-engine | 47 | 6 |
| abb | 28 | 6 |
| cdx-p3d4-render-inputs | 28 | 1 |
| cdx-depth-ui | 27 | 2 |
| cdx-depth | 24 | 10 |
| cdx-v3d-clarity-register | 23 | 2 |
| man7b | 14 | 24 |
| ai-engine | 12 | 1 |
| asc-core | 11 | 4 |
| qrs-heal | 4 | 3 |
| cdx-p3d2-r3-surface | 4 | 4 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `kit:87` every kit toy has a recipe that builds deterministically and fits the unit ball | 553 |
| `ui2:156` phone › the sheet has five stops: hidden, row, grid, panel and full | 159 |
| `ui2:322` computer › the panel folds to an edge and comes back, and the gallery opens as a page | 153 |
| `cdx-three-lines:23` RGB row coverage: webgpu, highp, 391x843, DPR 2.625 | 130 |
| `cdx-p3df:302` two real inputs render at the phone profile, score truth, and generate a safe offline gall | 121 |
| `ui2:123` phone › focus mode hides the sheet and the top bar; the corner button and a swipe up bring | 90 |
| `ui2:419` computer › Shift-drag moves the toy within reach, Reset centers it, and a link keeps the m | 69 |
| `wdh:135` worlds hybrid › splats hide behind the models' depth (splats mode): a bush behind a hill l | 62 |
| `ui2:300` computer › focus mode hides the panel and top bar, and Escape restores them | 61 |
| `ui2:365` computer › the pad inks by distance, not by events, and the eraser clears | 57 |
| `wdh:249` worlds hybrid › frames per second, sampled in both modes | 57 |
| `pno-engine:312` levers move and light their own pieces, and come back | 56 |
| `wdh:271` worlds hybrid › screenshots at 390x844 and 1440x900 | 56 |
| `wdh:81` worlds hybrid › ?render= picks the mode; both modes load without errors and draw what they | 50 |
| `wdh:135` worlds hybrid › splats hide behind the models' depth (hybrid mode): a bush behind a hill l | 47 |
| `psv:70` Photo to 3D › Sharp picture shows the photo at full size on its relief, and back to the sp | 47 |
| `man3-2:414` Level 4's sixty more programs › sixty cards in six folded groups, each with its picture, a | 40 |
| `ui2:218` phone › the CNN opens its settings at the full stop, the pad fits whole, and it reads a dr | 36 |
| `wdh:198` worlds hybrid › ?character=kenney swaps in a lit, skinned character: it casts shadows, sta | 30 |
| `wdh:198` worlds hybrid › ?character=mesh swaps in a lit, skinned character: it casts shadows, stand | 30 |
| `ui2:266` phone › two fingers moving together move the toy; a pinch still zooms; Reset centers it | 27 |
| `man3-2:225` the live demos › they fit a 390 px phone, and the PDF shows each one as a still with its l | 25 |
| `cdx-a11y:100` keyboard play stays collapsed after settings at 390×844 | 25 |
| `man3-2:167` the live demos › each shows its numbers, matching a hand calculation, with no errors | 24 |
| `man3-2:338` the lighter layout › on a phone a tap opens the pop-up and a tap elsewhere closes it, and  | 23 |
