# Suite run

- 23 of 23 files, 134 tests: 134 passed, 0 failed, 0 skipped.
- Time in files (one after another): 43 min. Wall time of this run: 22 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| shp | 563 | 8 |
| ui3 | 375 | 8 |
| psv2 | 357 | 6 |
| shw | 260 | 11 |
| pic | 144 | 13 |
| pno | 124 | 11 |
| e6a | 120 | 7 |
| pot | 119 | 9 |
| man3 | 103 | 8 |
| ui5-engine | 99 | 7 |
| hh5-atoms | 80 | 5 |
| fx5 | 69 | 8 |
| lat | 53 | 13 |
| live4 | 43 | 2 |
| sci3-engine | 22 | 2 |
| arc2-engine | 17 | 1 |
| qr4-2-engine | 14 | 2 |
| cdx-v3d-cpu | 8 | 1 |
| cdx-p3d5-clip-state | 5 | 2 |
| cdx-qr-fit-study | 5 | 2 |
| cdx-p3d4-background-bins | 4 | 1 |
| rel-engine | 3 | 1 |
| cdx-p3d2-r3-anchored | 3 | 6 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `shp:231` adapt drag (the default) drops the resolution only during a drag | 213 |
| `psv2:38` photo-3d › a saved scene remembers each view | 137 |
| `e6a:215` e6a screenshots at 1440x900 and 390x844 | 112 |
| `psv2:38` moving-photo-3d › a saved scene remembers each view | 109 |
| `shp:268` ?aa=1 turns on the engine's anti-aliased splats, and back | 100 |
| `ui3:194` toys that hold still › the listed toys open with the turntable off and the tilt locked; th | 89 |
| `ui3:271` the flag button › 1440x900 › sets flag colors for every toy (1440x900) | 87 |
| `shp:183` ?cull=low draws the far, small splats the default cull drops | 70 |
| `ui3:271` the flag button › 390x844 › sets flag colors for every toy (390x844) | 65 |
| `shp:131` with ?sharp=0 the renderer is exactly as before, labs on or off | 60 |
| `psv2:67` moving-photo-3d › a link remembers Splats, and the Detail choice with it | 54 |
| `shp:160` ?cull= lowers the cull, and a toy without it puts the defaults back | 51 |
| `shw:63` chapter "Real data and real captures": every toy opens and plays | 48 |
| `shp:204` ?dpr= sets the pixel-ratio cap, and the tier's cap comes back without it | 46 |
| `shw:63` chapter "Your own files, turned 3D on your device": every toy opens and plays | 43 |
| `pot:163` Powers of ten in the app › the wheel zooms through the stops; the camera never moves | 43 |
| `man3:135` Figures 2 and 3 are roomier on the web, and the page still fits a phone | 42 |
| `ui3:131` pause and resume › a tune never overlaps itself: a new play stops the old one | 38 |
| `shw:63` chapter "Things that come apart": every toy opens and plays | 37 |
| `ui3:76` pause and resume › the second tap freezes a long effect and its sound, the third resumes i | 35 |
| `shw:63` chapter "Recipes: tiny, editable, any size": every toy opens and plays | 35 |
| `shw:63` chapter "Science you can check": every toy opens and plays | 34 |
| `pot:201` Powers of ten in the app › a tap plays the journey: out from the garden first | 32 |
| `ui5-engine:65` phone › with a song or game bar up, the stage ends above the bar, so the bar never covers  | 32 |
| `shw:63` chapter "Instruments that are played": every toy opens and plays | 31 |
