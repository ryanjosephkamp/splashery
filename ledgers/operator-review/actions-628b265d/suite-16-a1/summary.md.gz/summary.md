# Suite run

- 23 of 23 files, 167 tests: 167 passed, 0 failed, 0 skipped.
- Time in files (one after another): 25 min. Wall time of this run: 13 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| asc-repeat | 282 | 1 |
| chr | 216 | 7 |
| qr3 | 179 | 8 |
| man4-pages | 112 | 14 |
| v3d | 91 | 14 |
| tp2 | 86 | 6 |
| phf | 67 | 7 |
| pdp-engine | 65 | 7 |
| hh4-landmarks | 57 | 7 |
| cdx-playtest-manual | 51 | 2 |
| st2 | 50 | 21 |
| cdx-adv-qr | 47 | 4 |
| ui5 | 40 | 3 |
| ui4 | 38 | 4 |
| man5 | 37 | 19 |
| man7a | 30 | 16 |
| sha-book | 18 | 4 |
| pol-engine | 18 | 5 |
| img | 7 | 9 |
| chs-engine | 7 | 1 |
| asc-unit | 4 | 5 |
| cdx-p3d4-surface-buffers | 3 | 1 |
| lv7-engine | 2 | 2 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `asc-repeat:65` ten jobs in a row and repeated Cancel leave no growing documents or handles | 279 |
| `qr3:129` Alive: every pattern scans on every sampled frame, in a flat and a deep style | 125 |
| `chr:249` character › on the Test island: the renderer turns the joints as the rig says, each tier h | 115 |
| `chr:56` character › the build has every joint's part, and it is sharp: opaque, flat splats | 78 |
| `tp2:105` toy pages round 2 (browser) › screenshots: two toy pages at both sizes | 59 |
| `cdx-playtest-manual:6` all 108 printed contents numbers share one right edge | 42 |
| `phf:130`  › screenshots at phone and desktop size | 35 |
| `man4-pages:316` every page works › each page loads with no error, its demos start, and it does not scroll  | 33 |
| `v3d:158` Splat.js loads only when a video is opened in this toy | 30 |
| `qr3:101` each new motion moves the code and ends on a code that scans | 25 |
| `v3d:215` screenshots at phone and desktop size | 24 |
| `tp2:74` toy pages round 2 (browser) › the toy on its page plays its sound, mutes, and the app link | 22 |
| `ui5:41` rotation defaults › the storybook, umbrella, xylophone and upright piano open with the til | 19 |
| `man5:201` the PDF › the same input and the same Chromium print the same bytes | 18 |
| `pdp-engine:49` at 1440×900 › the slider drags, stays inside the stage, is remembered, and goes back | 16 |
| `man4-pages:193` old addresses, pop-ups, and the whole manual › an old manual/#anchor lands on the page tha | 16 |
| `man4-pages:40` the pages › Next from the cover reaches every page in order, and Previous goes back | 15 |
| `sha-book:67` storybook screenshots at 390x844 and 1440x900 | 14 |
| `v3d:194` without WebGPU the toy says so plainly and keeps going | 13 |
| `phf:87`  › Moving photo to 3D: the sample, a GIF and a short video show their own pixels | 13 |
| `cdx-adv-qr:35` a reader load failure offers JSON and permits an export retry | 13 |
| `pdp-engine:49` at 390×844 › the slider drags, stays inside the stage, is remembered, and goes back | 13 |
| `v3d:325` on a phone the card asks first, with the setting and a rough time | 12 |
| `ui4:48` 1440x900 › a drag along the keys plays each key it crosses, in order, up and back (1440x90 | 12 |
| `qr3:177` themes and flags apply from the panel, show their contrast and scan | 12 |
