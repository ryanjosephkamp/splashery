# Suite run

- 23 of 23 files, 237 tests: 237 passed, 0 failed, 0 skipped.
- Time in files (one after another): 35 min. Wall time of this run: 22 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| wd | 373 | 16 |
| cdx-mp2 | 344 | 16 |
| sndc | 211 | 9 |
| smd-moving | 174 | 16 |
| shr | 167 | 12 |
| hh5-ai | 154 | 11 |
| arc3 | 108 | 10 |
| fx8 | 85 | 5 |
| taps | 74 | 65 |
| fx4 | 55 | 4 |
| pdp | 55 | 6 |
| bk5-engine | 54 | 7 |
| e5 | 51 | 7 |
| cdx-life | 40 | 5 |
| qrc-barcodes | 36 | 5 |
| shb | 35 | 5 |
| sky-engine | 17 | 4 |
| hh1-shapes | 13 | 1 |
| unit | 11 | 20 |
| cdx-p3d4-worker-preparation | 9 | 1 |
| cdx-playtest-small-fixes-engine | 5 | 1 |
| cdx-mp2-decode | 4 | 7 |
| e6b | 4 | 4 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-mp2:401` upload refinement reduces machine and bridge regressions without losing horse and Sintel s | 192 |
| `wd:187` worlds › each tier stays within its splat budget | 132 |
| `wd:210` worlds › screenshots at 390x844 and 1440x900 | 74 |
| `cdx-mp2:317` a real uploaded bunny refines every depth frame and closes the measured low-tier sample ga | 46 |
| `fx8:185` alarm-clock screenshots at 390x844 and 1440x900 | 43 |
| `sndc:150` the splatting toy's sorting view clicks once for each splat placed; each view has its own  | 42 |
| `sndc:108` the daisy's petals each tap as they land, and the rose's one does too | 40 |
| `cdx-mp2:436` 60 fps input retains its native picture and improves depth in the background at a larger s | 39 |
| `shr:202` 1440x900 › the preview sheet after Stop plays the take; Discard asks first and frees it; S | 38 |
| `sndc:230` screenshot: the periodic table's built atom (1440x900) | 33 |
| `wd:242` worlds render (r2) › the sharp kernel and the tier's pixel ratio are on, and the URL overr | 33 |
| `qrc-barcodes:132` Other barcodes in the browser: every kind reads back from the stage | 32 |
| `shr:202` 390x844 › the preview sheet after Stop plays the take; Discard asks first and frees it; Sa | 31 |
| `wd:138` worlds › walking up to a landmark or tapping its sign opens its card | 30 |
| `hh5-ai:256` screenshots: the difference-engine, hands-on | 28 |
| `sndc:175` each splat field and each book style plays its own sound | 28 |
| `fx8:81` on the page, the hands show the page's time, upright, on its side and upside down | 28 |
| `wd:40` worlds › the Test island loads without console errors and shows its start screen | 26 |
| `sndc:128` the periodic table's atom ticks once for each proton and neutron as it packs in | 26 |
| `wd:168` worlds › the list view lists every landmark, and Go there takes you to one | 24 |
| `shr:402` the preview sheet, more › Record again: a second take opens in the sheet, and the first ta | 24 |
| `pdp:216` the Sharp picture, frozen mid-tap › a synthetic portrait: no more backing on show halfway  | 23 |
| `sndc:230` screenshot: the periodic table's built atom (390x844) | 22 |
| `wd:108` worlds › collision stops the character at a prop and at the water | 21 |
| `wd:67` worlds › keys move the character, and it stays on the ground | 21 |
