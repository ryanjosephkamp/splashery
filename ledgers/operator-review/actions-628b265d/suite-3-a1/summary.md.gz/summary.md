# Suite run

- 21 of 21 files, 273 tests: 272 passed, 0 failed, 1 skipped.
- Time in files (one after another): 30 min. Wall time of this run: 15 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| smoke | 730 | 62 |
| asc | 175 | 5 |
| help | 168 | 14 |
| fb | 124 | 6 |
| live-engine | 96 | 11 |
| hh3-open-me | 78 | 9 |
| ai | 77 | 47 |
| lv10 | 69 | 11 |
| cdx-v3d-calibration | 62 | 12 |
| sky | 52 | 10 |
| cdx-v3d-samples | 36 | 5 |
| ln | 34 | 19 |
| hh1-clothing | 30 | 5 |
| phf2 | 17 | 7 |
| vol | 12 | 24 |
| stm-engine | 9 | 1 |
| cdx-stability | 8 | 10 |
| bld | 4 | 7 |
| cdx-p3d5-noise | 3 | 3 |
| fx10 | 3 | 2 |
| cdx-p3d4-metrics | 3 | 3 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `asc:273` the three presets capture, move and keep their credit; settings change the GIF | 128 |
| `smoke:249` Splashery app (WebGL2) › clay adds and erases blobs on a generated toy and survives a JSON | 40 |
| `fb:121` the even torus, disc, ellipsoid, tube and rounded box are on their surfaces | 39 |
| `help:261` the line stays clear of the toy at 1440x900 | 36 |
| `smoke:761` Splashery v3 engine (WebGL2) › rigs pick splats by colour, run effects and show add-ons; s | 35 |
| `help:261` the line stays clear of the toy at 390x844 | 29 |
| `smoke:1549` Splashery on a phone › dragging the shelf up opens a grid, and picking a toy folds it back | 28 |
| `help:102` toy help: the line › shows on a pick, fades, and '?' brings it back | 28 |
| `smoke:618` Splashery v3 engine (WebGL2) › patterns and flags recolour any toy and travel in the link | 28 |
| `smoke:1740` Splashery on WebGPU › auto picks WebGPU when an adapter exists and effects render | 25 |
| `smoke:823` Splashery v3 engine (WebGL2) › the chess set plays the Opera Game, and the laptop types wh | 25 |
| `smoke:367` Splashery app (WebGL2) › the embed page loads a scene from the hash | 24 |
| `ai:191` neural-network mid-tap screenshots at 390x844 and 1440x900 | 23 |
| `smoke:1467` Splashery on a phone › has no horizontal overflow at 390px and the sheet opens | 23 |
| `ai:191` diffusion-model mid-tap screenshots at 390x844 and 1440x900 | 22 |
| `smoke:443` Splashery app (WebGL2) › bring-your-own PLY, SPLAT, SPZ and SOG files load in the browser | 22 |
| `smoke:1118` Settings panel (WebGL2) › the chess game bar plays, pauses, steps and jumps, and a tap aft | 22 |
| `smoke:971` Splashery v3 engine (WebGL2) › v3 screenshots at 1440x900 and 390x844 | 22 |
| `live-engine:48` nothing is asked for or loaded before a tap | 21 |
| `ai:191` transformer mid-tap screenshots at 390x844 and 1440x900 | 21 |
| `smoke:590` Splashery v3 engine (WebGL2) › toys move by themselves once motion is on, and any toy can  | 20 |
| `smoke:1222` Sports balls (WebGL2) › ball screenshots at 1440x900 and 390x844 | 19 |
| `smoke:887` Splashery v3 engine (WebGL2) › a stretchy toy stretches when dragged and springs back; a d | 19 |
| `asc:356` Cancel and a failing renderer leave nothing behind and offer no file | 19 |
| `fb:221` marble screenshots at 390x844 and 1440x900 | 19 |
