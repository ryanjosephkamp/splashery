# Suite run

- 22 of 22 files, 191 tests: 190 passed, 1 failed, 0 skipped.
- Time in files (one after another): 47 min. Wall time of this run: 27 min (2 at once).

## Failed

- `phy:64` Pebbles: stones pick up and stack into a new cairn; a careless one topples: failed. Error: expect(received).toBeGreaterThan(expected)

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| cdx-mp2-r4-raster | 589 | 7 |
| phy | 399 | 6 |
| bk5 | 367 | 9 |
| cdx-playground-links | 218 | 15 |
| cdx-qr-fit | 213 | 21 |
| lab | 188 | 9 |
| tw2-cells | 150 | 6 |
| mca | 118 | 20 |
| fx7 | 103 | 20 |
| mol | 89 | 27 |
| hh5-gems | 64 | 5 |
| sha | 59 | 5 |
| hh3-level1 | 50 | 2 |
| hh4-space | 50 | 6 |
| lv8-dial | 48 | 2 |
| cdx-p3d-status | 47 | 3 |
| lv7-long | 25 | 2 |
| pdf-engine | 15 | 2 |
| fx9-engine | 11 | 1 |
| qrs-steps | 11 | 5 |
| tw2-dna | 5 | 8 |
| cdx-p3d5-acceptance | 5 | 10 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `cdx-mp2-r4-raster:143` desktop: removing faces without raster samples leaves identical pixels | 273 |
| `cdx-mp2-r4-raster:143` phone: removing faces without raster samples leaves identical pixels | 252 |
| `bk5:461` links and pop-out (in the app) › Photo album: a photo pops out with its depth and lies bac | 143 |
| `phy:111` jelly and amoeba stretch and spring back; cherries swing and knock | 109 |
| `bk5:376` links and pop-out (in the app) › Your book: a web link asks first, javascript: is refused, | 99 |
| `bk5:426` links and pop-out (in the app) › Your book: the PDF's picture pops out with its depth and  | 85 |
| `phy:156` the spring toy stretches and settles; the bow shoots; sushi picks the tapped piece | 79 |
| `cdx-playground-links:155` 932×430 landscape › settings have room beside the gallery and can be used | 63 |
| `cdx-playground-links:155` 844×390 landscape › settings have room beside the gallery and can be used | 62 |
| `phy:215` screenshots: the Hands-on buttons on Pebbles at 1440x900 | 56 |
| `mol:285` the toy › every sample builds in every style, inside the budget, with finite splats | 54 |
| `phy:215` screenshots: the Hands-on buttons on Pebbles at 390x844 | 52 |
| `phy:90` bricks and macarons stack; a brick snaps onto the studs | 47 |
| `tw2-cells:65` dna-to-protein mid-tap screenshots at 390x844 and 1440x900 | 46 |
| `lab:62` with labs, every field moves on the GPU, drawing something | 44 |
| `lab:126` a tap on the Splat field fires its pulse, for every field (1440×900) | 37 |
| `tw2-cells:65` mitosis mid-tap screenshots at 390x844 and 1440x900 | 35 |
| `mca:273` bombe mid-tap screenshots at 390x844 and 1440x900 | 35 |
| `tw2-cells:65` apoptosis mid-tap screenshots at 390x844 and 1440x900 | 33 |
| `lab:126` a tap on the Splat field fires its pulse, for every field (390×844) | 31 |
| `cdx-qr-fit:44` own-picture crop responds to touch, zoom, and keyboard and survives a share link without p | 30 |
| `cdx-qr-fit:363` qr-picture: fitted borders and rounded eyes scan from the actual finished render | 30 |
| `fx7:462` clothes take flag colors on their cloth | 30 |
| `mca:273` enigma-machine mid-tap screenshots at 390x844 and 1440x900 | 28 |
| `tw2-cells:65` phagocytosis mid-tap screenshots at 390x844 and 1440x900 | 27 |
