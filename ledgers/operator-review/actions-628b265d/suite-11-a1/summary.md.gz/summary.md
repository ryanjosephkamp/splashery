# Suite run

- 22 of 22 files, 202 tests: 202 passed, 0 failed, 0 skipped.
- Time in files (one after another): 41 min. Wall time of this run: 22 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| qrs-toys | 551 | 4 |
| psv3 | 419 | 20 |
| site | 235 | 11 |
| pdf | 167 | 9 |
| cdx-t2 | 159 | 74 |
| fl7 | 142 | 7 |
| hh2-nature | 122 | 7 |
| hh5-math | 106 | 9 |
| lv9-2 | 100 | 5 |
| hh1-toys | 85 | 9 |
| pg6-engine | 64 | 8 |
| phf-engine | 63 | 5 |
| lv9 | 60 | 7 |
| cdx-p3d2-r3-edges | 53 | 3 |
| qr4-2 | 40 | 3 |
| ops-media | 30 | 1 |
| hh3-storybook | 20 | 1 |
| e4f | 13 | 5 |
| man2 | 13 | 2 |
| opm | 8 | 5 |
| cdx-p3d4-preparation | 7 | 4 |
| cdx-p3d5-projection | 4 | 3 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `qrs-toys:85` the Damage lab's meter agrees with jsQR on a fixed set | 470 |
| `pdf:147` the moving recording: one tap, its frames and size within the estimate | 90 |
| `psv3:82` photo-3d › Sharp picture to Splats (Detail photo) through a rebuild draws with no WebGL er | 68 |
| `fl7:232` WebGPU: switching scenes does not grow the projector buffers | 63 |
| `lv9-2:77` in the browser › each tune plays through the live path: its notes ring their modes and the | 62 |
| `psv3:82` moving-photo-3d › Sharp picture to Splats (Detail photo) through a rebuild draws with no W | 46 |
| `psv3:82` moving-photo-3d › Sharp picture to Splats (Detail splats) through a rebuild draws with no  | 41 |
| `psv3:82` photo-3d › Sharp picture to Splats (Detail splats) through a rebuild draws with no WebGL e | 40 |
| `site:201` site › the service worker stays in site/ and the site works offline after one visit | 35 |
| `qrs-toys:115` healing: a code with a covered finder scans again | 34 |
| `site:395` site › screenshots: the home page and a search at both sizes | 33 |
| `psv3:146` Moving photo to 3D loops a short video without sound | 32 |
| `psv3:146` Moving photo to 3D loops a short video with sound | 31 |
| `qr4-2:79` Share → QR code: the code reads back, as a camera sees it too, and opens the same scene | 30 |
| `site:373` site › the theme button cycles and the home toy follows it; reduced motion holds it still | 30 |
| `qrs-toys:41` How a QR code works: its code is the encoder's, and it scans | 30 |
| `psv3:146` Moving photo to 3D loops a short video without sound at 1.75 times | 29 |
| `psv3:146` Moving photo to 3D loops a GIF | 28 |
| `hh2-nature:184` rose and pinecone: a petal and a scale come off and land on the ground | 28 |
| `phf-engine:266`  › it compiles and draws on WebGPU too | 27 |
| `psv3:146` Moving photo to 3D loops a short video with sound at 1.75 times | 27 |
| `site:128` site › the menu works on a phone, by touch and by keyboard | 26 |
| `ops-media:16` the web-address box names only what each picture toy opens | 26 |
| `lv9:178` Sound in a box, played to › your audio: each note drives its mode at once, the beads settl | 25 |
| `fl7:196` WebGPU: the phone envelope's liquid, and a reused readback that matches a fresh one | 25 |
