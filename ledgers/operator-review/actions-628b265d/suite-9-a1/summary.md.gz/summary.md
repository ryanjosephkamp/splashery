# Suite run

- 22 of 22 files, 124 tests: 124 passed, 0 failed, 0 skipped.
- Time in files (one after another): 30 min. Wall time of this run: 16 min (2 at once).

## Failed

None.

## Slowest files

| File | Seconds | Tests |
| --- | ---: | ---: |
| lv7 | 483 | 11 |
| fx4-engine | 415 | 4 |
| ro | 120 | 4 |
| live2 | 114 | 11 |
| hec | 98 | 9 |
| qrl | 79 | 1 |
| phy-engine | 72 | 8 |
| hh3-engine | 66 | 7 |
| stm | 55 | 20 |
| fix3 | 50 | 4 |
| live3-engine | 48 | 4 |
| live6 | 39 | 3 |
| smd-photo | 37 | 4 |
| hh2-engine | 28 | 2 |
| cdx-p3d4-render-hold | 22 | 3 |
| hta | 16 | 3 |
| cdx-p3d2-r3-input-race | 12 | 1 |
| cdx-gallery | 10 | 1 |
| cdx-p3d2-r3-compact | 7 | 4 |
| cmp2-enigma | 5 | 8 |
| cdx-p3d5-study-state | 3 | 3 |
| cdx-three-bounds | 3 | 9 |

## Slowest tests

| Test | Seconds |
| --- | ---: |
| `lv7:106` the mirror on a camera (a generated mannequin) › plain: steadier than before, frame to fra | 211 |
| `fx4-engine:79` toys without the rim kind draw as before (webgpu) | 194 |
| `lv7:150` the mirror on a camera (a generated mannequin) › hologram: nothing drawn over the face, an | 154 |
| `fx4-engine:79` toys without the rim kind draw as before (webgl2) | 147 |
| `ro:118` Real objects › each toy opens and plays its tap in the app, with screenshots | 88 |
| `qrl:28` every QR style at its defaults scans after simulated phone captures | 75 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgpu) | 38 |
| `hec:217` on its side or upside down, the soft parts hang toward the world's down and Reset still wo | 34 |
| `fx4-engine:122` a thin rim shell is clear face on and solid at its edge (webgl2) | 33 |
| `lv7:520` screenshots at phone and desktop size: the landscape growing | 29 |
| `live2:207` in the browser › the click track: each click is at the now mark within 50 ms of when it is | 28 |
| `lv7:393` the Chladni plate › your audio: no bow ever, no new plate, the sand sets off for each new  | 27 |
| `phy-engine:90` Hands-on is off on a scan: a drag turns the view; on, it picks the toy up | 27 |
| `live3-engine:57` the Live pill never covers a control, on a phone or a desktop | 27 |
| `stm:366` the toy in the browser › a sample shows, a tap lifts and settles, opening your own models  | 24 |
| `hec:275` the soft parts' step time stays small with each demo toy in play | 20 |
| `fix3:92` banana mid-tap screenshots at 390x844 and 1440x900 | 20 |
| `lv7:353` the Chladni plate › a tap bows the plate (the bow shows while it moves the sand) and nothi | 20 |
| `live2:297` in the browser › ribbons: builds in both views, on paper and alone, and fills in as it pla | 20 |
| `stm:426` the toy in the browser › screenshots at phone and desktop size | 19 |
| `live2:297` in the browser › lines: builds in both views, on paper and alone, and fills in as it plays | 19 |
| `live6:116` a clip plays at its source's speed: a video's frame rate and length, a GIF's on its own cl | 19 |
| `hh2-engine:95` a flip piece flicked up turns over and lands upside down; set down, it stays level | 18 |
| `hh3-engine:254` a forgiving press: off the lava lamp's splats, Hands-on still lifts it | 18 |
| `lv7:236` the Song landscape grows with the song › Live opens on an empty plain, the land grows as t | 17 |
