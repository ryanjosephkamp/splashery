import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure, surfaceMetrics } from '../tools/cdx-mp2-measure.mjs';
import { stabilityMetrics } from '../tools/cdx-stability-measure.mjs';

const source = await fs.readFile('src/packs/moving-photo.js','utf8');
const needle = 'job.scores = { fitted: fitScore, whole: wholeScore };';
if (source.split(needle).length!==2) throw new Error('Instrumentation target changed');
const body = source.replace(needle,needle+' globalThis.__r4ScoreCandidates?.({fitted,whole,frames,w:clip.w,h:clip.h,scores:job.scores});');
const browser = await chromium.launch(GRAPHICS_LAUNCH);
try {
  const page = await browser.newPage({viewport:{width:390,height:844}});
  await page.route('**/src/packs/moving-photo.js',r=>r.fulfill({contentType:'text/javascript',body}));
  await page.goto('http://127.0.0.1:4173/LICENSES.md');
  await page.evaluate(({jitter,surface})=>{
    const metrics=(0,eval)(`(${jitter})`),cuts=(0,eval)(`(${surface})`);
    window.__r4Candidates=[];
    window.__r4ScoreCandidates=({fitted,whole,frames,w,h,scores})=>{
      const score=near=>{
        const result={...metrics(near,frames.map(f=>f.data)),...cuts(near,w,h)};
        result.fullScore=result.heightJitter+0.1*result.surfaceCutShare;
        let sum=0,count=0;
        for(let f=1;f<near.length;f++)for(let i=0;i<near[f].length;i++){
          let cd=0;for(let k=0;k<3;k++)cd+=(frames[f].data[i*4+k]-frames[f-1].data[i*4+k])**2;
          if(cd>192)continue;sum+=((near[f][i]-near[f-1][i])/255)**2;count++;
        }
        result.rms=Math.sqrt(sum/Math.max(1,count));
        result.rmsScore=result.rms+0.1*result.surfaceCutShare;
        return result;
      };
      window.__r4Candidates.push({scores,fitted:score(fitted),whole:score(whole)});
    };
  },{jitter:stabilityMetrics.toString(),surface:surfaceMetrics.toString()});
  const id=process.argv[4]||'dragon';
  const sample=await measure(page,{id});
  const result=await measure(page,{id,path:process.argv[2]||'work/r4-ci-inputs/dragon.webm'});
  const candidates=await page.evaluate(()=>window.__r4Candidates);
  const out={note:'Measurement-only route records both unchanged candidates; no production or test bytes changed.',browser:browser.version(),sample,result,candidates};
  await fs.writeFile(process.argv[3]||'work/r4-ci-candidates-probe.json',JSON.stringify(out,null,2)+'\n');
  console.log(JSON.stringify(out));
} finally {
  await browser.close();
}
