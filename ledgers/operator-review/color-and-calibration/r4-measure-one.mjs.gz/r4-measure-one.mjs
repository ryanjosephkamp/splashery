import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure } from '../tools/cdx-mp2-measure.mjs';
const [id,path,out]=process.argv.slice(2);
const browser=await chromium.launch(GRAPHICS_LAUNCH);
try {
  const page=await browser.newPage({viewport:{width:390,height:844}});
  await page.goto('http://127.0.0.1:4173/LICENSES.md');
  const sample=await measure(page,{id});
  const upload=await measure(page,{id,path});
  const report={browser:browser.version(),sample,upload};
  await fs.writeFile(out,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));
} finally { await browser.close(); }
