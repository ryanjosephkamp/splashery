import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure } from '../tools/cdx-mp2-measure.mjs';

const source=await fs.readFile('src/packs/moving-photo.js','utf8');
const needle='job.normalization = wholeScore < fitScore ? "whole-clip" : "range-fit";';
if(source.split(needle).length!==2)throw new Error('Calibration target changed');
const mode=process.argv[2]||'selected', id=process.argv[3]||'dragon', input=process.argv[4]||'work/r4-ci-inputs/dragon.webm';
let body=source.replace(needle,needle+' if(wholeScore<fitScore){anchor=result;coarseRange=depthRange(result.map(d=>d.d));}');
if(mode==='ols')body=body.replace('out[i].d = Float32Array.from(out[i].d, (v) => a + (v - lo) * scale);','const fit=alignDepth(out[i].d,target,colors,colors); out[i].d=fit.some((v,k)=>Math.abs(v-out[i].d[k])>1e-7)?fit:Float32Array.from(out[i].d,(v)=>a+(v-lo)*scale);');
if(mode==='rmsfull'){
  body=body.replace('jitter += Math.abs(d[i] - near[f - 1][i]) / 255;','jitter += ((d[i] - near[f - 1][i]) / 255) ** 2;');
  body=body.replace('return jitter / Math.max(1, still) + (0.1 * cuts) / Math.max(1, triangles);','return Math.sqrt(jitter / Math.max(1, still)) + (0.1 * cuts) / Math.max(1, triangles);');
  body=body.replace('for (let y = 0; y + 1 < h; y += 4)','for (let y = 0; y + 1 < h; y++)').replace('for (let x = 0; x + 1 < w; x += 4)','for (let x = 0; x + 1 < w; x++)');
}
const browser=await chromium.launch(GRAPHICS_LAUNCH);
try {
  const page=await browser.newPage({viewport:{width:390,height:844}});
  await page.route('**/src/packs/moving-photo.js',r=>r.fulfill({contentType:'text/javascript',body}));
  await page.goto('http://127.0.0.1:4173/LICENSES.md');
  const result=await measure(page,{id,path:input});
  const report={note:'Measurement-only accepted-anchor route against exact CI upload. Product remains unchanged.',browser:browser.version(),routeSha256:createHash('sha256').update(body).digest('hex'),result};
  await fs.writeFile(process.argv[5]||`work/r4-ci-selected-${mode}-probe.json`,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));
} finally { await browser.close(); }
