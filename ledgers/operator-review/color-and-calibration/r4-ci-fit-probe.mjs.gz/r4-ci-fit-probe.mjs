import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure } from '../tools/cdx-mp2-measure.mjs';

const source=await fs.readFile('src/packs/moving-photo.js','utf8');
const needle='out[i].d = Float32Array.from(out[i].d, (v) => a + (v - lo) * scale);';
if(source.split(needle).length!==2)throw new Error('Calibration target changed');
const modes=process.argv.slice(2);
const results=[];
for(const mode of modes.length?modes:['ols','variance']) {
  const code=mode==='ols'
    ? 'const fit=alignDepth(out[i].d,target,colors,colors); out[i].d=fit.some((v,k)=>Math.abs(v-out[i].d[k])>1e-7)?fit:Float32Array.from(out[i].d,(v)=>a+(v-lo)*scale);'
    : 'let sx=0,sy=0,sxx=0,syy=0; const n=target.length; for(let k=0;k<n;k++){const x=out[i].d[k],y=target[k];sx+=x;sy+=y;sxx+=x*x;syy+=y*y;} const gain=Math.max(.25,Math.min(4,Math.sqrt(Math.max(0,syy-sy*sy/n)/Math.max(1e-9,sxx-sx*sx/n)))); out[i].d=Float32Array.from(out[i].d,v=>sy/n+(v-sx/n)*gain);';
  const body=source.replace(needle,code);
  const browser=await chromium.launch(GRAPHICS_LAUNCH);
  try {
    const page=await browser.newPage({viewport:{width:390,height:844}});
    await page.route('**/src/packs/moving-photo.js',r=>r.fulfill({contentType:'text/javascript',body}));
    await page.goto('http://127.0.0.1:4173/LICENSES.md');
    const result=await measure(page,{id:'dragon',path:'work/r4-ci-inputs/dragon.webm'});
    results.push({mode,browser:browser.version(),result});
    console.log(JSON.stringify(results.at(-1)));
    await fs.writeFile('work/r4-ci-fit-probe.json',JSON.stringify({note:'Measurement-only calibration routes against exact CI upload; product remains unchanged.',results},null,2)+'\n');
  } finally { await browser.close(); }
}
