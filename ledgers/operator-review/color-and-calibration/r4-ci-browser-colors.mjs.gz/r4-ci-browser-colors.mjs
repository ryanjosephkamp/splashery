import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
const browser=await chromium.launch(GRAPHICS_LAUNCH);
try {
  const page=await browser.newPage();
  await page.goto('http://127.0.0.1:4173/LICENSES.md');
  const results=await page.evaluate(async()=>{
    const {seekClipFrame}=await import('/src/packs/moving-photo.js');
    const canvas=()=>{const c=document.createElement('canvas');c.width=640;c.height=272;return c.getContext('2d',{willReadFrequently:true});};
    const ref=canvas(),actual=canvas(),images=new Map(),results=[];
    for(const path of ['.cache/cdx-mp2/sources/dragon.webm','work/r4-ci-inputs/dragon.webm','work/r4-canonical/dragon.webm']){
      const v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';
      const ready=new Promise((resolve,reject)=>{v.addEventListener('loadeddata',resolve,{once:true});v.addEventListener('error',()=>reject(new Error('Video failed '+path)),{once:true});});
      v.src='/'+path;await ready;
      const rows=[];
      for(const index of [0,16,32,48,64,80]){
        const sheet=1+Math.floor(index/21);
        if(!images.has(sheet)){const im=new Image();im.src=`/assets/toys/moving-photo-3d/sintel-sheet-${sheet}.jpg`;await im.decode();images.set(sheet,im);}
        const tile=index%21;
        ref.drawImage(images.get(sheet),(tile%3)*640,Math.floor(tile/3)*272,640,272,0,0,640,272);
        await seekClipFrame(v,(index+.25)/16);
        const frame=new VideoFrame(v);const colorSpace=frame.colorSpace.toJSON();frame.close();
        actual.drawImage(v,0,0,640,272);
        const a=ref.getImageData(0,0,640,272).data,b=actual.getImageData(0,0,640,272).data;
        let error=0,squared=0,max=0,count=0;
        for(let i=0;i<a.length;i++){if(i%4===3)continue;const d=Math.abs(a[i]-b[i]);error+=d;squared+=d*d;max=Math.max(max,d);count++;}
        rows.push({index,colorSpace,mae:error/count,rmse:Math.sqrt(squared/count),max});
      }
      results.push({path,duration:v.duration,rows});v.removeAttribute('src');v.load();
    }
    return results;
  });
  const out={browser:browser.version(),note:'Actual browser seeks the same six source pictures, inside each coded frame, and compares RGB with the original sheet tiles.',results};
  await fs.writeFile('work/r4-ci-browser-colors.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out));
}finally{await browser.close();}
