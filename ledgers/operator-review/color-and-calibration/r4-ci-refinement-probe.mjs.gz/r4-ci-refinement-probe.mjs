import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure } from '../tools/cdx-mp2-measure.mjs';

const out = process.argv[2] || 'work/r4-ci-refinement-probe.json';
const browser = await chromium.launch(GRAPHICS_LAUNCH);
const results = [];
try {
  const page = await browser.newPage({viewport:{width:390,height:844}});
  await page.goto('http://127.0.0.1:4173/LICENSES.md');
  for (const path of [null,'.cache/cdx-mp2/sources/dragon.webm','work/r4-ci-inputs/dragon.webm']) {
    const result = await measure(page,{id:'dragon',...(path?{path}:{})});
    results.push(result);
    console.log(JSON.stringify(result));
    await fs.writeFile(out,JSON.stringify({browser:browser.version(),results},null,2)+'\n');
  }
} finally {
  await browser.close();
}
