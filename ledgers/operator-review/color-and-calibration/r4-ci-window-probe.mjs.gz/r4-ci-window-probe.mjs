import { chromium } from '@playwright/test';
import fs from 'node:fs/promises';
import { GRAPHICS_LAUNCH } from '../tools/cdx-mp2-render.mjs';
import { measure } from '../tools/cdx-mp2-measure.mjs';

const source=await fs.readFile('src/packs/moving-photo.js','utf8');
const selection='job.normalization = wholeScore < fitScore ? "whole-clip" : "range-fit";';
const needle='const [lo, hi] = depthRange([out[i].d]);\n      const [a, b] = depthRange([target]);';
if(source.split(needle).length!==2)throw new Error('Calibration target changed');
const results=[];
for(const radius of [1,2]) {
  let body=source.replace(selection,selection+' if(wholeScore<fitScore){anchor=result;coarseRange=depthRange(result.map(d=>d.d));}');
  body=body.replace(needle,`const at=keys.indexOf(i); const around=keys.slice(Math.max(0,at-${radius}),at+${radius}+1); const [lo,hi]=depthRange(around.map(k=>raw[k].d)); const [a,b]=depthRange(around.map(k=>reference[k].d));`);
  const browser=await chromium.launch(GRAPHICS_LAUNCH);
  try {
    const page=await browser.newPage({viewport:{width:390,height:844}});
    await page.route('**/src/packs/moving-photo.js',r=>r.fulfill({contentType:'text/javascript',body}));
    await page.goto('http://127.0.0.1:4173/LICENSES.md');
    const result=await measure(page,{id:'dragon',path:'work/r4-ci-inputs/dragon.webm'});
    results.push({radius,browser:browser.version(),result});
    console.log(JSON.stringify(results.at(-1)));
    await fs.writeFile('work/r4-ci-window-probe.json',JSON.stringify({note:'Measurement-only overlapping-range and accepted-anchor routes. Product remains unchanged.',results},null,2)+'\n');
  } finally { await browser.close(); }
}
